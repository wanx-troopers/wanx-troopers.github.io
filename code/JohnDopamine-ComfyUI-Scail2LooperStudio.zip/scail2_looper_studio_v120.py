"""Scail2LooperStudio v1.2.0

Self-contained, all-in-one multi-segment SCAIL-2 looper for NATIVE ComfyUI
(core SCAIL-2 support, Kijai's PR #14373 + the SCAIL-2 multireference PR), in
the same house style as BerniniInfinity / BerniniScailChain: a plain classic
node class with an explicit INPUT_TYPES dict and core-node delegation via the
_invoke reflection shim. It does NOT subclass or import any other custom pack --
the looping engine is inlined here so this pack stands alone.

Runs SAM3 subject masking, SCAIL-2 colored mask construction, per-segment
WanSCAILToVideo conditioning, custom sampling, and image-space overlap
stitching inside a single node with a Bernini-Studio-style DOM GUI
(js/scail2_looper_studio_v120.js).

MULTI-REFERENCE (the feature the older nodes never wired up):
  The native WanSCAILToVideo accepts a BATCH of reference images -- the first is
  the primary reference, the rest are additional VIEWS of the subject (face
  closeup, back/profile view, background plate) -- but each additional view needs
  its OWN per-identity colored mask, batched to match. Earlier looper nodes only
  ever built ONE reference mask (SAM3 on reference_image[:1]), so extra refs
  collapsed onto the primary mask = degenerate identity binding. This node fixes
  that: it assembles [primary frames..., ref_view_2.., ref_view_3.., ref_view_4..]
  into one uniform reference batch, runs SAM3 once on the driving video and once
  per reference frame, renders SCAIL2ColoredMask per frame (sharing the driving
  track so each identity keeps the same palette color across the pose and
  reference masks), and stacks the per-frame reference masks into a batch
  matching the reference set. Hivemind tips baked into tooltips: a face closeup
  with mouth open kills "generic SCAIL teeth" (ucren); a background ref helps
  context windows (Kijai).

  Manual path: wire reference_image_mask yourself (a batch matching the full
  reference set) and the auto-builder steps aside. A SINGLE reference (no extra
  views) behaves exactly like the classic single-mask looper.

Continuation contract (verified against comfy_extras/nodes_scail.py):
  - WanSCAILToVideo slices the FULL pose video internally via video_frame_offset
    and subtracts previous_frame_count when previous_frames are supplied, so each
    chunk re-renders the previous chunk's last P frames as its first P frames
    (pixel-space anchoring via encoded prev frames + noise_mask, WanAnimate-
    style). P=5 is the trained value.
  - Stitching overlaps exactly P frames per seam. The first segment is NEVER
    trimmed.
"""

import gc
import json
import math
import inspect
import logging
import random
from typing import Optional, List, Dict, Any, Tuple

import torch

import comfy.utils
import comfy.samplers
import comfy.model_management as mm

VERSION = "1.2.0"

log = logging.getLogger("Scail2LooperStudio")

_NIGHTLY_HINT = (
    "[Scail2LooperStudio] Could not import the core SCAIL-2 nodes "
    "(comfy_extras.nodes_scail / nodes_sam3). SCAIL-2 support landed in "
    "ComfyUI core in June 2026 (PR #14373); update ComfyUI to a recent "
    "nightly/master build."
)


# ===========================================================================
# Core-node delegation helpers (v1 instance nodes AND v3 io.ComfyNode).
# Our own node is classic v1; the core SCAIL/SAM3 nodes are v3 io.ComfyNode,
# so we reach them through this shim by candidate method name.
# ===========================================================================

def _unwrap_node_output(res):
    """Normalize v1 tuples and v3 io.NodeOutput into a plain tuple."""
    if res is None:
        return ()
    if hasattr(res, "args"):
        return tuple(res.args)
    if isinstance(res, tuple):
        return res
    if isinstance(res, list):
        return tuple(res)
    return (res,)


def _accepted_kwargs(fn) -> set:
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        return set()
    names = set()
    for p in sig.parameters.values():
        if p.kind == inspect.Parameter.VAR_KEYWORD:
            return {"__VARKW__"}
        names.add(p.name)
    return names


def _invoke(node_cls, method_names: Tuple[str, ...], **kwargs):
    """Call a core node class method by candidate names, filtering kwargs to the
    actual signature. Works for v3 classmethod `execute` and v1 instance
    methods. Returns a plain tuple of outputs."""
    inst = None
    for name in method_names:
        fn = getattr(node_cls, name, None)
        if fn is None:
            continue
        accepted = _accepted_kwargs(fn)
        if "__VARKW__" in accepted:
            filtered = dict(kwargs)
        else:
            filtered = {k: v for k, v in kwargs.items() if k in accepted}
        is_bound_classmethod = inspect.ismethod(fn) and getattr(fn, "__self__", None) is node_cls
        if is_bound_classmethod or isinstance(
            inspect.getattr_static(node_cls, name, None), (classmethod, staticmethod)
        ):
            return _unwrap_node_output(fn(**filtered))
        if inst is None:
            inst = node_cls()
        return _unwrap_node_output(getattr(inst, name)(**filtered))
    raise RuntimeError(
        f"[Scail2LooperStudio] No callable from {method_names!r} on "
        f"{getattr(node_cls, '__name__', node_cls)!r}. The installed ComfyUI "
        "core revision may be too old or too new for this pack."
    )


def _lazy_core_imports():
    try:
        from comfy_extras import nodes_scail, nodes_sam3
    except Exception as e:
        raise RuntimeError(_NIGHTLY_HINT) from e
    import nodes as core_nodes
    from comfy_extras import nodes_custom_sampler, nodes_model_advanced
    return core_nodes, nodes_scail, nodes_sam3, nodes_custom_sampler, nodes_model_advanced


# ===========================================================================
# Stitch math (image space). Same semantics as KJNodes
# ImageBatchExtendWithOverlap linear_blend / ease_in_out, implemented internally
# so this native pack has zero custom-node dependencies.
# ===========================================================================

def _crossfade_join(running: torch.Tensor, incoming: torch.Tensor,
                    overlap: int, mode: str) -> torch.Tensor:
    overlap = max(0, min(overlap, running.shape[0], incoming.shape[0]))
    if overlap == 0:
        return torch.cat([running, incoming], dim=0)
    src = running[-overlap:]
    dst = incoming[:overlap]
    alpha = torch.linspace(0, 1, overlap + 2, device=src.device, dtype=src.dtype)[1:-1]
    if mode == "ease_in_out":
        alpha = 0.5 - 0.5 * torch.cos(alpha * math.pi)
    alpha = alpha.view(-1, 1, 1, 1)
    blended = (1.0 - alpha) * src + alpha * dst
    return torch.cat([running[:-overlap], blended, incoming[overlap:]], dim=0)


def _color_match_chunk(incoming: torch.Tensor, prev_tail: torch.Tensor,
                       new_head: torch.Tensor) -> torch.Tensor:
    """Per-channel gain/offset on the whole incoming chunk so its overlap head
    statistically matches the previous tail. Gentle drift killer; OFF by
    default."""
    eps = 1e-6
    pm = prev_tail.mean(dim=(0, 1, 2))
    ps = prev_tail.std(dim=(0, 1, 2)).clamp_min(eps)
    nm = new_head.mean(dim=(0, 1, 2))
    ns = new_head.std(dim=(0, 1, 2)).clamp_min(eps)
    out = (incoming - nm) * (ps / ns) + pm
    return out.clamp(0.0, 1.0)


def _resolve_seed(base_seed: int, policy: str, seg_idx: int,
                  override: Optional[int]) -> int:
    if override is not None:
        return int(override)
    if policy == "increment_per_segment":
        return int(base_seed) + seg_idx
    if policy == "random_per_segment":
        return random.randint(0, 0xFFFFFFFFFFFF) if seg_idx > 0 else int(base_seed)
    return int(base_seed)


def _parse_segments(segments_json: str) -> List[Dict[str, Any]]:
    segs = []
    try:
        raw = json.loads(segments_json) if segments_json and segments_json.strip() else []
    except json.JSONDecodeError as e:
        raise ValueError(f"[Scail2LooperStudio] segments_json is not valid JSON: {e}")
    if not isinstance(raw, list):
        raw = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        frames = int(item.get("frames", 81))
        frames = max(5, ((frames - 1) // 4) * 4 + 1)
        segs.append({
            "frames": frames,
            "prompt": str(item.get("prompt", "") or ""),
            "seed_override": item.get("seed_override", None),
        })
    if not segs:
        segs = [{"frames": 81, "prompt": "", "seed_override": None}]
    return segs


def _snap32(v: int) -> int:
    return max(32, (int(v) // 32) * 32)


def _resize_bhwc(img: torch.Tensor, w: int, h: int, mode: str) -> torch.Tensor:
    """(B,H,W,C) -> (B,H,W,3) resized to (h,w) via common_upscale."""
    return comfy.utils.common_upscale(
        img[:, :, :, :3].movedim(-1, 1), w, h, mode, "center"
    ).movedim(1, -1)


def _emit_progress(unique_id, seg_idx: int, total: int, phase: str):
    try:
        from server import PromptServer
        PromptServer.instance.send_sync(
            "sld_segment_progress",
            {"node_id": str(unique_id) if unique_id is not None else "",
             "seg_idx": int(seg_idx), "total": int(total), "phase": phase},
        )
    except Exception:
        pass


# ===========================================================================
# The node
# ===========================================================================

class Scail2LooperStudio:
    DESCRIPTION = (
        "All-in-one multi-segment SCAIL-2 looper (native ComfyUI core SCAIL-2 "
        "support required) with MULTI-REFERENCE. Handles SAM3 masking, per-"
        "reference colored mask construction, per-segment conditioning/sampling "
        "and seam stitching internally. Wire ref_view_2/3/4 (face closeup, back "
        "view, background plate) for multi-reference identity locking."
    )

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL", {"tooltip": "SCAIL-2 diffusion model (apply LoRAs upstream: SCAIL-2 DPO, lightx2v distill, etc.)."}),
                "clip": ("CLIP", {"tooltip": "Wan umt5-xxl text encoder (CLIPLoader type 'wan')."}),
                "vae": ("VAE", {"tooltip": "Wan 2.1 VAE."}),
                "driving_video": ("IMAGE", {"tooltip": "Full driving/motion source video frames."}),
                "reference_image": ("IMAGE", {"tooltip": "Primary reference character image (composite multiple identities on one frame). A batch here is treated as multiple reference VIEWS (frame 0 = primary)."}),

                "width": ("INT", {"default": 512, "min": 32, "max": 4096, "step": 32}),
                "height": ("INT", {"default": 896, "min": 32, "max": 4096, "step": 32}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xFFFFFFFFFFFFFFFF, "control_after_generate": True}),
                "seed_policy": (["fixed_global", "increment_per_segment", "random_per_segment"], {"default": "increment_per_segment"}),
                "steps": ("INT", {"default": 6, "min": 1, "max": 200, "tooltip": "6 with lightx2v distill LoRA; ~20+ without."}),
                "cfg": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 30.0, "step": 0.1}),
                "shift": ("FLOAT", {"default": 8.0, "min": 0.0, "max": 100.0, "step": 0.01, "tooltip": "ModelSamplingSD3 shift, applied internally."}),
                "sampler_name": (comfy.samplers.KSampler.SAMPLERS, {"default": "er_sde"}),
                "scheduler": (comfy.samplers.KSampler.SCHEDULERS, {"default": "simple"}),

                "replacement_mode": ("BOOLEAN", {"default": False, "tooltip": "False = Animation Mode. True = Replacement Mode (character swap, background preserved). Note: lightx2v helps animation but can degrade replacement (per the SCAIL team)."}),
                "subject_prompt": ("STRING", {"default": "person", "tooltip": "SAM3 text prompt for what to track in the driving video and every reference view."}),
                "previous_frame_count": ("INT", {"default": 5, "min": 1, "max": 81, "step": 4, "tooltip": "Continuation anchor frames per seam. SCAIL-2 was trained at 5. This is also the stitch overlap."}),
                "stitch_policy": (["linear_blend", "ease_in_out", "cut"], {"default": "linear_blend", "tooltip": "How the P re-rendered overlap frames of each non-first segment join the running output. linear_blend mirrors the proven image-space crossfade."}),
                "color_match": ("BOOLEAN", {"default": False, "tooltip": "Per-channel gain/offset of each incoming segment to match the previous tail. Try ON if you see brightness/color stepping at seams."}),

                "segments_json": ("STRING", {"default": "[]", "multiline": False, "tooltip": "GUI-managed. Multiline is deliberately OFF: multiline STRING widgets get a DOM wrapper in the new frontend, and the hidden wrapper becomes an invisible click shield over the timeline."}),
                "global_prompt": ("STRING", {"default": "", "multiline": True, "dynamicPrompts": True}),
                "negative_prompt": ("STRING", {"default": "", "multiline": True, "dynamicPrompts": True}),

                # SAM3 tuning
                "detection_threshold": ("FLOAT", {"default": 0.5, "min": 0.0, "max": 1.0, "step": 0.01}),
                "max_objects": ("INT", {"default": 4, "min": 0, "max": 64}),
                "detect_interval": ("INT", {"default": 1, "min": 1, "max": 100, "tooltip": "Run SAM3 detection every N frames on the driving video. 1 = every frame (needed for occlusion or late-appearing subjects); higher = much faster."}),
                "sort_by": (["left_to_right", "area", "none"], {"default": "left_to_right"}),
                "object_indices": ("STRING", {"default": "", "tooltip": "Comma-separated subject indices to keep (e.g. '0,2'). Empty = all."}),

                "pose_strength": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 10.0, "step": 0.01}),
                "pose_start": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.01}),
                "pose_end": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 1.0, "step": 0.01}),

                # GUI-managed mirrors of the SELECTED timeline segment.
                "selected_segment_prompt": ("STRING", {"default": "", "multiline": True, "tooltip": "Prompt of the segment selected on the timeline. Empty = use global_prompt."}),
                "selected_segment_seed": ("INT", {"default": -1, "min": -1, "max": 0xFFFFFFFFFFFF, "tooltip": "Seed override for the selected segment. -1 = no override."}),
            },
            "optional": {
                "clip_vision": ("CLIP_VISION", {"tooltip": "clip_vision_h. Encoded internally with crop='none' (SCAIL-2 trained with stretch resize). Uses the primary reference."}),
                "sam3_model": ("MODEL", {"tooltip": "SAM3 model from CheckpointLoaderSimple (e.g. sam3.1_multiplex). Required unless masks are wired directly."}),
                "sam3_clip": ("CLIP", {"tooltip": "SAM3 text encoder CLIP from the same CheckpointLoaderSimple."}),
                "pose_video_mask": ("IMAGE", {"tooltip": "Bypass SAM3: pre-made colored driving mask video."}),
                "reference_image_mask": ("IMAGE", {"tooltip": "Bypass SAM3: pre-made colored reference mask. For multi-reference, a BATCH matching the full reference set (frame 0 = primary, rest = each ref view)."}),
                "initial_mask": ("MASK", {"tooltip": "Optional first-frame mask(s) for SAM3 tracking instead of/with the text prompt."}),

                # ---- Multi-reference additional views (Kijai SCAIL-2 multireference) ----
                "ref_view_2": ("IMAGE", {"tooltip": "Multi-reference additional VIEW of the same subject. Classic use: a FACE CLOSEUP with mouth open -- kills 'generic SCAIL teeth' and locks the reference mouth shape (ucren). Its per-identity mask is auto-built from SAM3 (uses subject_prompt); needs sam3_model + sam3_clip."}),
                "ref_view_3": ("IMAGE", {"tooltip": "Multi-reference additional view -- e.g. a back/profile view, or a background plate (Kijai: 'background ref really helps with context windows'). Mask auto-built like ref_view_2."}),
                "ref_view_4": ("IMAGE", {"tooltip": "Multi-reference additional view (4th slot). Mask auto-built like ref_view_2."}),
            },
            "hidden": {"unique_id": "UNIQUE_ID"},
        }

    RETURN_TYPES = ("IMAGE", "IMAGE", "IMAGE", "INT")
    RETURN_NAMES = ("images", "pose_video_mask", "reference_image_mask", "total_frames")
    FUNCTION = "execute"
    CATEGORY = "Scail2LooperStudio"

    # ------------------------------------------------------------------
    def execute(self, model, clip, vae, driving_video, reference_image,
                width, height, seed, seed_policy, steps, cfg, shift,
                sampler_name, scheduler, replacement_mode, subject_prompt,
                previous_frame_count, stitch_policy, color_match,
                segments_json, global_prompt, negative_prompt,
                detection_threshold, max_objects, detect_interval, sort_by,
                object_indices, pose_strength, pose_start, pose_end,
                selected_segment_prompt="", selected_segment_seed=-1,
                clip_vision=None, sam3_model=None, sam3_clip=None,
                pose_video_mask=None, reference_image_mask=None,
                initial_mask=None, ref_view_2=None, ref_view_3=None,
                ref_view_4=None, unique_id=None):

        core_nodes, nodes_scail, nodes_sam3, nodes_cs, nodes_ma = _lazy_core_imports()

        w, h = _snap32(width), _snap32(height)
        if (w, h) != (width, height):
            log.warning(f"[Scail2LooperStudio] width/height snapped to multiples of 32: {width}x{height} -> {w}x{h}")

        segments = _parse_segments(segments_json)
        n_seg = len(segments)
        P = max(1, int(previous_frame_count))

        # ------------------------------------------------------------------
        # Multi-reference assembly: [primary frames..., ref_view_2.., ..] resized
        # to the generation size so they stack into one uniform batch. A single
        # reference with no extra views is left untouched (classic behavior).
        # ------------------------------------------------------------------
        extra_views = [v for v in (ref_view_2, ref_view_3, ref_view_4) if v is not None]
        multi_ref = bool(extra_views) or reference_image.shape[0] > 1
        if multi_ref:
            ref_frames = [_resize_bhwc(reference_image[i:i + 1], w, h, "bicubic")
                          for i in range(reference_image.shape[0])]
            for v in extra_views:
                for i in range(v.shape[0]):
                    ref_frames.append(_resize_bhwc(v[i:i + 1], w, h, "bicubic"))
            reference_image = torch.cat(ref_frames, dim=0)
            log.info("[Scail2LooperStudio] multi-reference: %d reference frames "
                     "in the set.", reference_image.shape[0])

        total_out_frames = segments[0]["frames"] + sum(s["frames"] - P for s in segments[1:])
        drv_len = int(driving_video.shape[0])
        log.info(
            f"[Scail2LooperStudio] {n_seg} segment(s), P={P}, expected output "
            f"{total_out_frames} frames; driving video has {drv_len} frames."
        )
        if drv_len < total_out_frames:
            log.warning(
                f"[Scail2LooperStudio] Driving video shorter than the timeline "
                f"({drv_len} < {total_out_frames}). Later frames generate without "
                "pose conditioning (model freestyles); use 'Fit to driving' in the GUI."
            )

        # ------------------------------------------------------------------
        # 1) SAM3 masking (unless masks wired in directly). For multi-reference,
        #    build ONE colored mask per reference frame -- sharing the driving
        #    track so each identity keeps the same palette color across the pose
        #    mask and every reference mask -- and stack them into a batch
        #    matching the reference set.
        # ------------------------------------------------------------------
        if pose_video_mask is None or reference_image_mask is None:
            if sam3_model is None or sam3_clip is None:
                raise ValueError(
                    "[Scail2LooperStudio] No pre-made masks wired, so sam3_model AND "
                    "sam3_clip are required (both come from CheckpointLoaderSimple "
                    "loading a SAM3 checkpoint, e.g. sam3.1_multiplex_fp16.safetensors)."
                )
            _emit_progress(unique_id, 0, n_seg, "sam3")
            sam3_cond = _invoke(
                core_nodes.CLIPTextEncode, ("encode", "execute"),
                clip=sam3_clip, text=subject_prompt or "person",
            )[0]
            log.info(f"[Scail2LooperStudio] SAM3 tracking driving video ({drv_len} frames, "
                     f"detect_interval={detect_interval})...")
            driving_track = _invoke(
                nodes_sam3.SAM3_VideoTrack, ("execute",),
                images=driving_video, model=sam3_model,
                initial_mask=initial_mask, conditioning=sam3_cond,
                detection_threshold=float(detection_threshold),
                max_objects=int(max_objects), detect_interval=int(detect_interval),
            )[0]

            n_ref = reference_image.shape[0]
            gen_pose_mask = None
            ref_mask_frames = []
            for idx in range(n_ref):
                ref_track = _invoke(
                    nodes_sam3.SAM3_VideoTrack, ("execute",),
                    images=reference_image[idx:idx + 1], model=sam3_model,
                    initial_mask=None, conditioning=sam3_cond,
                    detection_threshold=float(detection_threshold),
                    max_objects=int(max_objects), detect_interval=1,
                )[0]
                masks = _invoke(
                    nodes_scail.SCAIL2ColoredMask, ("execute",),
                    driving_track_data=driving_track, ref_track_data=ref_track,
                    object_indices=object_indices or "", sort_by=sort_by,
                    replacement_mode=bool(replacement_mode),
                )
                if gen_pose_mask is None:
                    gen_pose_mask = masks[0]
                if multi_ref:
                    ref_mask_frames.append(_resize_bhwc(masks[1][:1], w, h, "nearest-exact"))
                else:
                    ref_mask_frames.append(masks[1])
                if multi_ref:
                    log.info("[Scail2LooperStudio] reference mask built for view "
                             "%d/%d", idx + 1, n_ref)
            gen_ref_mask = torch.cat(ref_mask_frames, dim=0) if len(ref_mask_frames) > 1 else ref_mask_frames[0]

            if pose_video_mask is None:
                pose_video_mask = gen_pose_mask
            if reference_image_mask is None:
                reference_image_mask = gen_ref_mask
            mm.soft_empty_cache()

        # ------------------------------------------------------------------
        # 2) One-time prep: clip vision (primary ref), model shift patch, negative
        # ------------------------------------------------------------------
        clip_vision_output = None
        if clip_vision is not None:
            clip_vision_output = _invoke(
                core_nodes.CLIPVisionEncode, ("encode", "execute"),
                clip_vision=clip_vision, image=reference_image[:1], crop="none",
            )[0]

        model_patched = _invoke(
            nodes_ma.ModelSamplingSD3, ("patch", "execute"),
            model=model, shift=float(shift),
        )[0]

        negative = _invoke(
            core_nodes.CLIPTextEncode, ("encode", "execute"),
            clip=clip, text=negative_prompt or "",
        )[0]

        sampler_obj = _invoke(
            nodes_cs.KSamplerSelect, ("get_sampler", "execute"),
            sampler_name=sampler_name,
        )[0]
        sigmas = _invoke(
            nodes_cs.BasicScheduler, ("get_sigmas", "execute"),
            model=model_patched, scheduler=scheduler, steps=int(steps), denoise=1.0,
        )[0]

        # ------------------------------------------------------------------
        # 3) Segment loop
        # ------------------------------------------------------------------
        running: Optional[torch.Tensor] = None
        prev_decoded: Optional[torch.Tensor] = None
        offset = 0
        last_prompt_embed = None
        last_prompt_text = None

        for seg_idx, seg in enumerate(segments):
            seg_len = int(seg["frames"])
            seg_prompt = (seg["prompt"] or global_prompt or "").strip()
            seg_seed = _resolve_seed(seed, seed_policy, seg_idx, seg["seed_override"])

            _emit_progress(unique_id, seg_idx, n_seg, "encode")
            if seg_prompt == last_prompt_text and last_prompt_embed is not None:
                positive = last_prompt_embed
            else:
                positive = _invoke(
                    core_nodes.CLIPTextEncode, ("encode", "execute"),
                    clip=clip, text=seg_prompt,
                )[0]
                last_prompt_embed, last_prompt_text = positive, seg_prompt

            cond = _invoke(
                nodes_scail.WanSCAILToVideo, ("execute",),
                positive=positive, negative=negative, vae=vae,
                width=w, height=h, length=seg_len, batch_size=1,
                pose_strength=float(pose_strength),
                pose_start=float(pose_start), pose_end=float(pose_end),
                video_frame_offset=int(offset),
                previous_frame_count=P,
                replacement_mode=bool(replacement_mode),
                reference_image=reference_image,
                clip_vision_output=clip_vision_output,
                pose_video=driving_video,
                pose_video_mask=pose_video_mask,
                reference_image_mask=reference_image_mask,
                previous_frames=prev_decoded,
            )
            pos2, neg2, latent_dict, offset_next = cond[0], cond[1], cond[2], cond[3]

            log.info(f"[Scail2LooperStudio] Segment {seg_idx + 1}/{n_seg}: "
                     f"{seg_len} frames, driving offset {offset} -> {offset_next}, seed {seg_seed}")
            _emit_progress(unique_id, seg_idx, n_seg, "sample")

            sampled = _invoke(
                nodes_cs.SamplerCustom, ("sample", "execute"),
                model=model_patched, add_noise=True, noise_seed=int(seg_seed),
                cfg=float(cfg), positive=pos2, negative=neg2,
                sampler=sampler_obj, sigmas=sigmas, latent_image=latent_dict,
            )
            out_latent = sampled[0]

            _emit_progress(unique_id, seg_idx, n_seg, "decode")
            decoded = _invoke(
                core_nodes.VAEDecode, ("decode", "execute"),
                vae=vae, samples=out_latent,
            )[0]
            if decoded.dtype != torch.float32:
                decoded = decoded.to(torch.float32)
            decoded = decoded.cpu()

            # ----------------------------------------------------------------
            # Stitch. Chunk k>0 re-renders prev chunk's last P frames as its
            # first P frames. The FIRST segment is never trimmed.
            # ----------------------------------------------------------------
            if running is None:
                running = decoded
            else:
                ov = min(P, running.shape[0], decoded.shape[0])
                try:
                    pt, nh = running[-ov:], decoded[:ov]
                    log.info(
                        "[Scail2LooperStudio] Seam %d->%d: prev tail mean/std %.4f/%.4f "
                        "vs re-rendered overlap %.4f/%.4f over %d frames",
                        seg_idx - 1, seg_idx, float(pt.mean()), float(pt.std()),
                        float(nh.mean()), float(nh.std()), ov,
                    )
                except Exception:
                    pass
                if color_match:
                    decoded = _color_match_chunk(decoded, running[-ov:], decoded[:ov])
                if stitch_policy == "cut":
                    running = torch.cat([running, decoded[ov:]], dim=0)
                else:
                    running = _crossfade_join(running, decoded, ov, stitch_policy)

            prev_decoded = decoded
            offset = int(offset_next)

            del cond, sampled, out_latent, pos2, neg2
            mm.soft_empty_cache()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            gc.collect()
            _emit_progress(unique_id, seg_idx, n_seg, "done")

        _emit_progress(unique_id, n_seg - 1, n_seg, "all_done")

        if pose_video_mask is None:
            pose_video_mask = torch.zeros(1, h, w, 3)
        if reference_image_mask is None:
            reference_image_mask = torch.zeros(1, h, w, 3)

        return (running, pose_video_mask, reference_image_mask, int(running.shape[0]))


NODE_CLASS_MAPPINGS = {"Scail2LooperStudio": Scail2LooperStudio}
NODE_DISPLAY_NAME_MAPPINGS = {"Scail2LooperStudio": "Scail2 Looper Studio"}
WEB_DIRECTORY = "./js"
