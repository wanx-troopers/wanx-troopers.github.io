# ComfyUI-Scail2LooperStudio

A **self-contained** multi-segment SCAIL-2 looper for native ComfyUI, in the
BerniniInfinity house style: one standalone classic node with a Bernini-Studio
DOM GUI. **No dependency on any other custom pack** — the looping engine is
inlined here.

Node: **Scail2 Looper Studio** (category `Scail2LooperStudio`).

## What it does

- SAM3 full-pass subject masking → SCAIL-2 colored masks
- native-core continuation (`video_frame_offset` / `previous_frame_count` /
  `previous_frames`) for true long video
- per-segment `WanSCAILToVideo` conditioning + custom sampling
- Pom-style image-space crossfade stitch at every seam (linear_blend /
  ease_in_out / cut), optional per-channel color match
- a timeline GUI: per-segment frames / seed-override / prompt, add / reorder /
  delete, click-to-select, live total-frame estimate, and a **Fit** button that
  builds the timeline to cover a driving video of N frames at the current
  overlap P
- per-segment progress line during sampling (`sld_segment_progress`)

## Multi-reference (Kijai SCAIL-2 multireference)

The native `WanSCAILToVideo` accepts a **batch** of reference images — the first
is the primary reference, the rest are additional **views** of the subject — but
each additional view needs its own per-identity colored mask, batched to match.
Older looper nodes only ever built one reference mask, so extra refs collapsed
onto the primary identity. This node builds **one colored mask per reference
view** (sharing the driving SAM3 track so each identity keeps the same palette
color across the pose mask and every reference mask).

Wire the extra views into the optional inputs:

- **`ref_view_2`** — e.g. a **face closeup with mouth open**: kills "generic
  SCAIL teeth" and locks the reference mouth shape (per ucren, Banodoco).
- **`ref_view_3`** — e.g. a back/profile view, or a **background plate**
  (Kijai: "background ref really helps with context windows").
- **`ref_view_4`** — a 4th view.

Masks are auto-built from SAM3 using `subject_prompt` (needs `sam3_model` +
`sam3_clip`). A batch wired straight into `reference_image` is also treated as
multiple views (frame 0 = primary). To bypass SAM3, wire `reference_image_mask`
yourself as a batch matching the full reference set. A single reference with no
extra views behaves exactly like the classic single-mask looper.

## Requirements

- Native core SCAIL-2 support (`comfy_extras.nodes_scail`, with the
  multireference PR) and SAM3 (`comfy_extras.nodes_sam3`) — a recent
  ComfyUI nightly/master (June 2026+). The node loads as a clear stub if the
  core SCAIL nodes are missing.
- A SAM3 checkpoint loaded via `CheckpointLoaderSimple` (provides `sam3_model`
  + `sam3_clip`), unless you wire masks directly.

## Safe by design

The DOM panel never holds state — every control binds to a native ComfyUI widget
by name (widgets are visually collapsed, never removed or reordered). Saved
workflows keep loading, tab-switches can't lose values, and the segment editor
reads/writes the exact `segments_json` schema the engine parses:

```json
[{ "frames": 81, "prompt": "", "seed_override": null }]
```

The panel is sized with the proven BerniniInfinity machinery (getHeight + live
computeSize + ResizeObserver + preview-stash), so it grows/shrinks to its real
content instead of cramming into a fixed box.

## Watchable previews (native)

The animated, watchable preview during sampling is **VideoHelperSuite's**
*"Display animated previews when sampling"* setting — enable it and launch
ComfyUI with a preview flag (`--preview-method auto`; `taesd` gives sharper
per-frame quality). If animated previews look broken, update VHS + the frontend.
This is per Austin Mroz (VHS).
