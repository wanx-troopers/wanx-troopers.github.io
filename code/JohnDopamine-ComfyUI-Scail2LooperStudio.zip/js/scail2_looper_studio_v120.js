// Scail2 Looper Studio -- DOM GUI v1.2.0
//
// Bernini-Studio-style panel for the self-contained Scail2LooperStudio node.
//
// v1.2.0 -- multi-reference + Fit-to-driving:
//   - "Fit" button on the segment timeline: builds segments to cover a driving
//     video of N frames at the current overlap P (P-stepped, first segment full).
//   - Multi-reference hint: the ref_view_2/3/4 IMAGE sockets feed the node's
//     auto per-reference masking; no widget needed (they appear as input dots).
//
// v1.1.0 -- SIZING REWORK (the v1.0.0 panel rendered compressed/jumbled):
//   Adopts the proven BerniniInfinity machinery -- an outer Comfy-sized `mount`
//   with the panel as its firstElementChild (so the panel's NATURAL height is
//   measured independently of the height Comfy imposes), addDOMWidget(getHeight)
//   + widget.computeSize reading LIVE scrollHeight, a ResizeObserver that re-fits
//   the node on any content change, a node.computeSize override that stashes
//   node.imgs during measurement so the preview height is not double-counted, and
//   a multi-pass initial fit instead of one early (often zero) reading.
//
// SAFE-BY-DESIGN:
//   - The real, serialized ComfyUI widgets stay the source of truth. Every DOM
//     control binds to a native widget by NAME (reads .value, writes .value +
//     fires .callback). Native widgets are visually collapsed, never removed or
//     reordered -> saved workflows keep loading, tab-switches can't lose data
//     (we re-sync the DOM FROM widgets on visibilitychange), empty-string ->
//     number crashes are caught (defensive parse + fallback).
//   - The segment editor reads/writes the SAME segments_json schema the engine
//     parses: [{ "frames": 4k+1>=5, "prompt": str, "seed_override": int|null }].
//   - Selecting a segment mirrors into selected_segment_prompt / _seed.

import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

const VERSION = "1.2.0";

const OI = {
  orange: "#E69F00", skyblue: "#56B4E9", green: "#009E73", yellow: "#F0E442",
  blue: "#0072B2", vermillion: "#D55E00", purple: "#CC79A7", gray: "#9aa0a6",
  ink: "#1b1e23", panel: "#23272e", row: "#2b3038", text: "#e6e8ea",
  faint: "#8b929b", ok: "#009E73", sel: "#E69F00",
};

// Accordion scalar sections (segment editor is rendered separately).
const SECTIONS = [
  { id: "canvas", title: "Canvas", accent: OI.skyblue, fields: [
    { w: "width", kind: "int", label: "Width" },
    { w: "height", kind: "int", label: "Height" },
  ]},
  { id: "sampler", title: "Sampler", accent: OI.blue, fields: [
    { w: "seed", kind: "int", label: "Seed" },
    { w: "seed_policy", kind: "combo", label: "Seed policy" },
    { w: "steps", kind: "int", label: "Steps" },
    { w: "cfg", kind: "float", label: "CFG" },
    { w: "shift", kind: "float", label: "Shift" },
    { w: "sampler_name", kind: "combo", label: "Sampler" },
    { w: "scheduler", kind: "combo", label: "Scheduler" },
  ]},
  { id: "cont", title: "Continuation & Stitch", accent: OI.green, fields: [
    { w: "previous_frame_count", kind: "int", label: "Overlap P",
      hint: "Continuation anchor + stitch overlap. SCAIL-2 trained at 5 (4k+1)." },
    { w: "stitch_policy", kind: "combo", label: "Stitch" },
    { w: "color_match", kind: "bool", label: "Color match" },
    { w: "replacement_mode", kind: "bool", label: "Replacement mode" },
  ]},
  { id: "pose", title: "SCAIL Pose", accent: OI.orange, fields: [
    { w: "pose_strength", kind: "pct", label: "Strength", max: 10 },
    { w: "pose_start", kind: "pct", label: "Start" },
    { w: "pose_end", kind: "pct", label: "End" },
  ]},
  { id: "sam3", title: "SAM3 Subject Tracking", accent: OI.purple, fields: [
    { w: "subject_prompt", kind: "text", label: "Track" },
    { w: "detection_threshold", kind: "pct", label: "Threshold" },
    { w: "max_objects", kind: "int", label: "Max objects" },
    { w: "detect_interval", kind: "int", label: "Detect every" },
    { w: "sort_by", kind: "combo", label: "Sort by" },
    { w: "object_indices", kind: "text", label: "Keep idx" },
  ]},
  { id: "prompts", title: "Global Prompts", accent: OI.yellow, fields: [
    { w: "global_prompt", kind: "textarea", label: "Global +" },
    { w: "negative_prompt", kind: "textarea", label: "Negative" },
  ]},
];

const MANAGED = new Set(["segments_json", "selected_segment_prompt", "selected_segment_seed"]);
for (const s of SECTIONS) for (const f of s.fields) MANAGED.add(f.w);

// ---------------------------------------------------------------------------
function findWidget(node, name) { return (node.widgets || []).find((w) => w.name === name); }
function collapseNative(w) {
  if (!w || w.__sl_collapsed) return;
  w.__sl_origComputeSize = w.computeSize;
  w.hidden = true;
  w.computeSize = () => [0, -4];
  w.__sl_collapsed = true;
}
function parseNum(raw, fallback, isInt) {
  if (raw === "" || raw == null) return fallback;
  const v = isInt ? parseInt(raw, 10) : parseFloat(raw);
  return isFinite(v) ? v : fallback;
}
function clamp(v, lo, hi) { if (lo != null && v < lo) v = lo; if (hi != null && v > hi) v = hi; return v; }
function snap4k1(n) { n = Math.max(5, Math.floor(n)); return Math.floor((n - 1) / 4) * 4 + 1; }
function el(tag, style, props) {
  const e = document.createElement(tag);
  if (style) Object.assign(e.style, style);
  if (props) Object.assign(e, props);
  return e;
}

// ---------------------------------------------------------------------------
// Node sizing -- keep the node frame matched to the panel's live height.
// Relies on node.computeSize being overridden (in onNodeCreated) to include the
// DOM widget height while stashing node.imgs so the preview is not double-counted.
// ---------------------------------------------------------------------------
function fitNode(node) {
  if (!node) return;
  requestAnimationFrame(() => {
    try {
      if (typeof node.setSize === "function" && node.size) {
        node.setSize([node.size[0], node.computeSize()[1]]);
      }
      if (node.graph) node.graph.setDirtyCanvas(true, true);
    } catch (e) {}
  });
}

// ---------------------------------------------------------------------------
// segment data <-> segments_json widget
// ---------------------------------------------------------------------------
function readSegments(node) {
  const w = findWidget(node, "segments_json");
  let arr = [];
  try { arr = JSON.parse(w && w.value ? w.value : "[]"); } catch (e) { arr = []; }
  if (!Array.isArray(arr)) arr = [];
  const segs = arr.filter((s) => s && typeof s === "object").map((s) => ({
    frames: snap4k1(parseNum(s.frames, 81, true)),
    prompt: String(s.prompt == null ? "" : s.prompt),
    seed_override: (s.seed_override == null || s.seed_override < 0) ? null : parseInt(s.seed_override, 10),
  }));
  if (!segs.length) segs.push({ frames: 81, prompt: "", seed_override: null });
  return segs;
}
function writeSegments(node, segs) {
  const w = findWidget(node, "segments_json");
  if (!w) return;
  w.value = JSON.stringify(segs);
  if (w.callback) w.callback(w.value);
}
function totalFrames(node, segs) {
  const pw = findWidget(node, "previous_frame_count");
  const P = pw ? parseNum(pw.value, 5, true) : 5;
  if (!segs.length) return 0;
  let t = segs[0].frames;
  for (let i = 1; i < segs.length; i++) t += Math.max(0, segs[i].frames - P);
  return t;
}

// Build a segment list that covers `drivingFrames` driving frames at overlap P.
// First segment is full length L (= current first segment's frames); each later
// segment advances by (L - P). Existing per-segment prompts/seeds are preserved
// where they line up. Mirrors the Designer's fit-to-driving behavior.
function fitSegments(node, drivingFrames) {
  const segs = readSegments(node);
  const L = (segs[0] && segs[0].frames) ? segs[0].frames : 81;
  const pw = findWidget(node, "previous_frame_count");
  const P = pw ? parseNum(pw.value, 5, true) : 5;
  const carry = (i) => ({
    prompt: (segs[i] && segs[i].prompt) || "",
    seed_override: (segs[i] && segs[i].seed_override != null) ? segs[i].seed_override : null,
  });
  const out = [];
  if (!drivingFrames || drivingFrames <= L) {
    out.push(Object.assign({ frames: snap4k1(Math.max(5, drivingFrames || L)) }, carry(0)));
  } else {
    const step = Math.max(1, L - P);
    const n = Math.max(1, Math.ceil((drivingFrames - L) / step) + 1);
    for (let i = 0; i < n; i++) out.push(Object.assign({ frames: L }, carry(i)));
  }
  writeSegments(node, out);
}

// ---------------------------------------------------------------------------
function buildPanel(node) {
  const root = el("div", {
    boxSizing: "border-box", width: "100%", fontFamily: "Inter, Segoe UI, sans-serif",
    fontSize: "12px", color: OI.text, background: OI.panel, borderRadius: "8px",
    padding: "6px", display: "flex", flexDirection: "column", gap: "6px",
  });

  // status strip
  const status = el("div", {
    display: "flex", alignItems: "center", gap: "8px", padding: "4px 8px",
    borderRadius: "6px", background: OI.ink, minHeight: "20px",
  });
  const totalEl = el("span", { color: OI.green, fontWeight: "700" });
  const progEl = el("span", { color: OI.faint, marginLeft: "auto" });
  status.appendChild(totalEl);
  status.appendChild(progEl);
  root.appendChild(status);

  // multi-reference hint
  const hint = el("div", { color: OI.faint, fontSize: "10px", opacity: "0.85", padding: "0 4px" },
    { textContent: "Multi-ref: wire ref_view_2/3/4 sockets (face closeup, back view, bg plate) — per-view masks auto-build." });
  root.appendChild(hint);

  const fieldSyncers = [];
  const sectionStates = [];

  // ---- segment editor card (first, it's the star) ----
  const segCard = el("div", { background: OI.row, borderRadius: "7px", border: "1px solid rgba(255,255,255,0.05)" });
  const segHead = el("div", {
    display: "flex", alignItems: "center", gap: "7px", padding: "6px 8px",
    borderLeft: `3px solid ${OI.green}`, fontWeight: "600",
  });
  segHead.appendChild(el("span", { flex: "1" }, { textContent: "Segments (timeline)" }));
  const fitBtn = el("span", {
    cursor: "pointer", fontSize: "11px", fontWeight: "700", color: OI.skyblue,
    border: `1px solid ${OI.skyblue}`, borderRadius: "10px", padding: "1px 9px",
  }, { textContent: "Fit" });
  fitBtn.title = "Build the timeline to cover a driving video of N frames at overlap P";
  segHead.appendChild(fitBtn);
  const addBtn = el("span", {
    cursor: "pointer", fontSize: "11px", fontWeight: "700", color: OI.green,
    border: `1px solid ${OI.green}`, borderRadius: "10px", padding: "1px 9px",
  }, { textContent: "+ add" });
  segHead.appendChild(addBtn);
  segCard.appendChild(segHead);
  const segBody = el("div", { display: "flex", flexDirection: "column", gap: "5px", padding: "6px 8px 8px 8px" });
  segCard.appendChild(segBody);
  root.appendChild(segCard);

  const renderSegments = () => {
    const segs = readSegments(node);
    segBody.innerHTML = "";
    let selected = node.__sl_selected;
    if (selected == null || selected >= segs.length) selected = 0;
    node.__sl_selected = selected;

    segs.forEach((seg, i) => {
      const card = el("div", {
        background: i === selected ? "rgba(230,159,0,0.12)" : OI.ink,
        border: `1px solid ${i === selected ? OI.sel : "rgba(255,255,255,0.08)"}`,
        borderRadius: "6px", padding: "5px 6px", display: "flex", flexDirection: "column", gap: "4px",
        cursor: "pointer",
      });
      card.addEventListener("click", (e) => {
        if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA" || e.target.__sl_btn) return;
        node.__sl_selected = i;
        syncSelectedMirror(node, segs[i]);
        renderSegments();
      });

      const top = el("div", { display: "flex", alignItems: "center", gap: "6px" });
      top.appendChild(el("span", { color: OI.faint, fontWeight: "700", flex: "0 0 22px" }, { textContent: "#" + (i + 1) }));

      top.appendChild(el("span", { color: OI.faint }, { textContent: "frames" }));
      const fIn = el("input", {
        width: "62px", background: OI.panel, color: OI.text, textAlign: "right",
        border: "1px solid rgba(255,255,255,0.12)", borderRadius: "4px", padding: "2px 4px",
      }, { type: "number", value: seg.frames, step: 4, min: 5 });
      fIn.addEventListener("change", () => {
        seg.frames = snap4k1(parseNum(fIn.value, 81, true));
        fIn.value = seg.frames;
        writeSegments(node, segs); refreshTotal();
      });
      top.appendChild(fIn);

      top.appendChild(el("span", { color: OI.faint }, { textContent: "seed" }));
      const sIn = el("input", {
        width: "92px", background: OI.panel, color: OI.text, textAlign: "right",
        border: "1px solid rgba(255,255,255,0.12)", borderRadius: "4px", padding: "2px 4px",
      }, { type: "number", value: seg.seed_override == null ? -1 : seg.seed_override, min: -1,
           title: "-1 = no override (use global seed policy)" });
      sIn.addEventListener("change", () => {
        const v = parseNum(sIn.value, -1, true);
        seg.seed_override = v < 0 ? null : v;
        writeSegments(node, segs);
        if (i === node.__sl_selected) syncSelectedMirror(node, seg);
      });
      top.appendChild(sIn);

      const spacer = el("span", { flex: "1" });
      top.appendChild(spacer);

      const mkBtn = (txt, col, fn) => {
        const b = el("span", {
          cursor: "pointer", color: col, fontWeight: "700", padding: "0 4px", userSelect: "none",
        }, { textContent: txt });
        b.__sl_btn = true;
        b.addEventListener("click", (e) => { e.stopPropagation(); fn(); });
        return b;
      };
      top.appendChild(mkBtn("▲", OI.faint, () => {
        if (i > 0) { const t = segs[i - 1]; segs[i - 1] = segs[i]; segs[i] = t; node.__sl_selected = i - 1; writeSegments(node, segs); renderSegments(); refreshTotal(); }
      }));
      top.appendChild(mkBtn("▼", OI.faint, () => {
        if (i < segs.length - 1) { const t = segs[i + 1]; segs[i + 1] = segs[i]; segs[i] = t; node.__sl_selected = i + 1; writeSegments(node, segs); renderSegments(); refreshTotal(); }
      }));
      top.appendChild(mkBtn("✕", OI.vermillion, () => {
        if (segs.length > 1) { segs.splice(i, 1); node.__sl_selected = Math.max(0, i - 1); writeSegments(node, segs); renderSegments(); refreshTotal(); if (node.__sl_fit) node.__sl_fit(); }
      }));
      card.appendChild(top);

      const pa = el("textarea", {
        width: "100%", boxSizing: "border-box", minHeight: "34px", resize: "vertical",
        background: OI.panel, color: OI.text, fontFamily: "inherit", fontSize: "11px",
        border: "1px solid rgba(255,255,255,0.1)", borderRadius: "4px", padding: "3px 5px",
      });
      pa.value = seg.prompt;
      pa.placeholder = "segment prompt (empty = global prompt)";
      pa.addEventListener("input", () => {
        seg.prompt = pa.value; writeSegments(node, segs);
        if (i === node.__sl_selected) syncSelectedMirror(node, seg);
      });
      card.appendChild(pa);

      segBody.appendChild(card);
    });
  };

  addBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    const segs = readSegments(node);
    segs.push({ frames: 81, prompt: "", seed_override: null });
    node.__sl_selected = segs.length - 1;
    writeSegments(node, segs);
    renderSegments(); refreshTotal();
    if (node.__sl_fit) node.__sl_fit();
  });

  fitBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    const last = node.__sl_lastDriving || 161;
    const raw = window.prompt("Driving video frame count to cover?", String(last));
    if (raw == null) return;
    const fr = parseInt(raw, 10);
    if (!isFinite(fr) || fr < 5) return;
    node.__sl_lastDriving = fr;
    fitSegments(node, fr);
    renderSegments(); refreshTotal();
    if (node.__sl_fit) node.__sl_fit();
  });

  const refreshTotal = () => {
    const segs = readSegments(node);
    totalEl.textContent = `${segs.length} seg → ~${totalFrames(node, segs)} frames`;
  };

  // ---- scalar accordion sections ----
  for (const sec of SECTIONS) {
    const card = el("div", { background: OI.row, borderRadius: "7px", overflow: "hidden", border: "1px solid rgba(255,255,255,0.05)" });
    const header = el("div", {
      display: "flex", alignItems: "center", gap: "7px", padding: "6px 8px",
      cursor: "pointer", userSelect: "none", borderLeft: `3px solid ${sec.accent}`,
    });
    const caret = el("span", { color: OI.faint, width: "10px" }, { textContent: "▾" });
    const titleEl = el("span", { color: OI.text, fontWeight: "600", flex: "1" }, { textContent: sec.title });
    header.appendChild(caret); header.appendChild(titleEl);
    card.appendChild(header);
    const body = el("div", { display: "flex", flexDirection: "column", gap: "5px", padding: "6px 8px 8px 8px" });
    card.appendChild(body);

    const st = { body, caret, collapsed: false };
    sectionStates.push(st);
    for (const f of sec.fields) {
      const w = findWidget(node, f.w);
      if (!w) continue;
      const { rowEl, sync } = buildField(node, f, w, refreshTotal);
      body.appendChild(rowEl);
      fieldSyncers.push({ sync });
    }
    header.addEventListener("click", () => {
      st.collapsed = !st.collapsed;
      body.style.display = st.collapsed ? "none" : "flex";
      caret.style.transform = st.collapsed ? "rotate(-90deg)" : "";
      if (node.__sl_fit) node.__sl_fit();
    });
    root.appendChild(card);
  }

  return { root, fieldSyncers, sectionStates, renderSegments, refreshTotal, progEl };
}

function syncSelectedMirror(node, seg) {
  const pw = findWidget(node, "selected_segment_prompt");
  if (pw) { pw.value = seg.prompt || ""; if (pw.callback) pw.callback(pw.value); }
  const sw = findWidget(node, "selected_segment_seed");
  if (sw) { sw.value = seg.seed_override == null ? -1 : seg.seed_override; if (sw.callback) sw.callback(sw.value); }
}

function buildField(node, f, w, refreshTotal) {
  const isInt = f.kind === "int", isPct = f.kind === "pct";
  const min = f.min != null ? f.min : (w.options && w.options.min);
  const max = f.max != null ? f.max : (w.options && w.options.max);
  const step = (w.options && w.options.step) || (isInt ? 1 : 0.01);

  const row = el("div", { display: "flex", flexDirection: "column", gap: "2px" });
  const top = el("div", { display: "flex", alignItems: "center", gap: "8px" });
  const label = el("span", { color: OI.faint, flex: "0 0 92px" }, { textContent: f.label });
  top.appendChild(label);
  let sync;

  if (f.kind === "bool") {
    const cb = el("input", { accentColor: OI.green, cursor: "pointer" }, { type: "checkbox" });
    cb.addEventListener("change", () => { w.value = cb.checked; if (w.callback) w.callback(w.value); });
    top.appendChild(cb);
    sync = () => { cb.checked = !!w.value; };
  } else if (f.kind === "combo") {
    const sel = el("select", {
      flex: "1", background: OI.ink, color: OI.text,
      border: "1px solid rgba(255,255,255,0.1)", borderRadius: "5px", padding: "3px",
    });
    for (const o of (w.options && w.options.values) || []) sel.appendChild(el("option", null, { value: String(o), textContent: String(o) }));
    sel.addEventListener("change", () => { w.value = sel.value; if (w.callback) w.callback(w.value); });
    top.appendChild(sel);
    sync = () => { sel.value = String(w.value); };
  } else if (f.kind === "text") {
    const inp = el("input", {
      flex: "1", background: OI.ink, color: OI.text,
      border: "1px solid rgba(255,255,255,0.1)", borderRadius: "5px", padding: "3px 5px",
    }, { type: "text" });
    inp.addEventListener("input", () => { w.value = inp.value; if (w.callback) w.callback(w.value); });
    top.appendChild(inp);
    sync = () => { if (document.activeElement !== inp) inp.value = w.value == null ? "" : String(w.value); };
  } else if (f.kind === "textarea") {
    const ta = el("textarea", {
      flex: "1", minHeight: "40px", resize: "vertical", boxSizing: "border-box",
      background: OI.ink, color: OI.text, fontFamily: "inherit", fontSize: "11px",
      border: "1px solid rgba(255,255,255,0.1)", borderRadius: "5px", padding: "4px 5px",
    });
    label.style.flex = "1";
    ta.addEventListener("input", () => { w.value = ta.value; if (w.callback) w.callback(w.value); });
    row.appendChild(top);
    row.appendChild(ta);
    sync = () => { if (document.activeElement !== ta) ta.value = w.value == null ? "" : String(w.value); };
    return { rowEl: row, sync };
  } else {
    let slider = null;
    if (isPct && (max == null || max <= 1.0001)) {
      slider = el("input", { flex: "1", accentColor: OI.skyblue, cursor: "pointer" }, { type: "range", min: 0, max: 1, step: 0.01 });
    }
    const box = el("input", {
      width: slider ? "62px" : "100%", flex: slider ? "0 0 62px" : "1",
      background: OI.ink, color: OI.text, textAlign: "right",
      border: "1px solid rgba(255,255,255,0.1)", borderRadius: "5px", padding: "3px 5px",
    }, { type: "number" });
    if (min != null) box.min = min;
    if (max != null) box.max = max;
    box.step = step;
    const commit = (raw) => {
      let v = clamp(parseNum(raw, w.value, isInt), min, max);
      w.value = v; if (w.callback) w.callback(w.value);
      box.value = v; if (slider) slider.value = v;
      if (f.w === "previous_frame_count" && refreshTotal) refreshTotal();
    };
    box.addEventListener("change", () => commit(box.value));
    if (slider) {
      slider.addEventListener("input", () => { const v = clamp(parseNum(slider.value, w.value, false), min, max); w.value = v; if (w.callback) w.callback(w.value); box.value = v; });
      top.appendChild(slider);
    }
    top.appendChild(box);
    sync = () => { if (document.activeElement !== box) box.value = w.value; if (slider && document.activeElement !== slider) slider.value = w.value; };
  }

  row.appendChild(top);
  if (f.hint) row.appendChild(el("span", { color: OI.faint, fontSize: "10px", opacity: "0.8", paddingLeft: "2px" }, { textContent: f.hint }));
  return { rowEl: row, sync };
}

function syncAll(node) {
  const b = node.__sl_built;
  if (!b) return;
  for (const fs of b.fieldSyncers) { try { fs.sync(); } catch (e) {} }
}

app.registerExtension({
  name: "Scail2LooperStudio.DOMGUI",
  async beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name !== "Scail2LooperStudio") return;
    // Guard against a stray older copy of this file also registering (ComfyUI
    // auto-loads every .js in WEB_DIRECTORY; two registrations = doubled panel).
    if (window.__scail2StudioGuiLoaded && window.__scail2StudioGuiLoaded !== VERSION) {
      console.warn("[Scail2LooperStudio] another GUI build already registered (" +
        window.__scail2StudioGuiLoaded + "); skipping v" + VERSION + ". Remove the old js/ file.");
      return;
    }
    window.__scail2StudioGuiLoaded = VERSION;

    const onNodeCreated = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      const r = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;
      const node = this;
      for (const name of MANAGED) collapseNative(findWidget(node, name));

      const built = buildPanel(node);
      node.__sl_built = built;
      node.__sl_root = built.root;

      // Comfy-sized outer container; the panel is its firstElementChild so the
      // panel's NATURAL height can be measured independently of the height Comfy
      // imposes on the container (decoupling = no feedback-loop collapse).
      const mount = el("div", { width: "100%", boxSizing: "border-box" });
      mount.appendChild(built.root);
      node.__sl_mount = mount;

      const getPanelHeight = () => {
        const inner = mount.firstElementChild;
        const h = inner ? inner.scrollHeight : mount.scrollHeight;
        return h > 0 ? h + 8 : 420; // +8 breathing room; fallback while unmeasured
      };

      const widget = node.addDOMWidget("scail2looper_panel", "div", mount, {
        serialize: false, hideOnZoom: false, getHeight: getPanelHeight,
      });
      node.__sl_widget = widget;
      if (widget) widget.computeSize = (w) => [w, getPanelHeight()];

      // Keep the node frame sized to the live panel height. Stash node.imgs
      // during measurement so the canvas/TAESD preview height is not added on
      // top of the DOM panel (double-counting pushed the border past the panel).
      const origComputeSize = node.computeSize;
      node.computeSize = function (out) {
        let stash = null, stashAnim = false;
        if (this.imgs) { stash = this.imgs; stashAnim = this.animatedImages; this.imgs = null; this.animatedImages = false; }
        let size;
        if (origComputeSize) size = origComputeSize.apply(this, arguments);
        else if (typeof LiteGraph !== "undefined") size = LiteGraph.LGraphNode.prototype.computeSize.call(this, out);
        else size = [this.size[0], this.size[1]];
        if (stash) { this.imgs = stash; this.animatedImages = stashAnim; }
        return size;
      };
      node.__sl_fit = () => fitNode(node);

      // Re-fit whenever the panel's content size changes (accordion toggle, text
      // wrap, segment add/remove) -- the piece the old GUI was missing entirely.
      if (typeof ResizeObserver !== "undefined") {
        let pending = false;
        const ro = new ResizeObserver(() => {
          if (pending) return;
          pending = true;
          requestAnimationFrame(() => {
            pending = false;
            try {
              if (node.size) node.setSize([node.size[0], node.computeSize()[1]]);
              if (node.graph) node.graph.setDirtyCanvas(true, true);
            } catch (e) {}
          });
        });
        ro.observe(mount);
        if (built.root) ro.observe(built.root);
        node.__sl_ro = ro;
      }

      // keep total live when previous_frame_count changes externally
      const pw = findWidget(node, "previous_frame_count");
      if (pw) { const prev = pw.callback; pw.callback = function () { const ret = prev ? prev.apply(this, arguments) : undefined; built.refreshTotal(); return ret; }; }

      // Initial build + fit. Several passes because Comfy mounts DOM widgets and
      // fonts load on their own schedule; re-measure until it settles instead of
      // caching one (often zero) early reading.
      const initFit = () => {
        try { built.renderSegments(); built.refreshTotal(); syncAll(node); } catch (e) {}
        fitNode(node);
      };
      requestAnimationFrame(() => {
        initFit();
        requestAnimationFrame(initFit);
        setTimeout(initFit, 60);
        setTimeout(initFit, 250);
      });

      const onVis = () => { if (!document.hidden) { syncAll(node); built.renderSegments(); built.refreshTotal(); fitNode(node); } };
      document.addEventListener("visibilitychange", onVis);
      node.__sl_onVis = onVis;

      node.size[0] = Math.max(node.size[0] || 0, 460);
      return r;
    };

    const onRemoved = nodeType.prototype.onRemoved;
    nodeType.prototype.onRemoved = function () {
      try { if (this.__sl_ro) { this.__sl_ro.disconnect(); this.__sl_ro = null; } } catch (e) {}
      if (this.__sl_onVis) document.removeEventListener("visibilitychange", this.__sl_onVis);
      return onRemoved ? onRemoved.apply(this, arguments) : undefined;
    };
  },
});

// per-segment progress from the engine (sld_segment_progress)
api.addEventListener("sld_segment_progress", (e) => {
  const d = e.detail || {};
  const node = app.graph && app.graph.getNodeById ? app.graph.getNodeById(Number(d.node_id)) : null;
  if (!node || !node.__sl_built) return;
  const total = d.total || 0;
  const idx = (d.seg_idx || 0) + 1;
  node.__sl_built.progEl.textContent = `seg ${idx}/${total} · ${d.phase || ""}`;
  node.setDirtyCanvas(true, true);
});

console.log("[Scail2LooperStudio] DOM GUI v" + VERSION + " registered");
