/**
 * Wan Looper Designer - Editor JS v1.2.50
 */

const { app } = window.comfyAPI.app;
const { api } = window.comfyAPI.api;

// Frame snap: Wan segments are 4n+1 frames (1 anchor + 4n motion frames).
function snapFramesToWanGrid(f) {
    f = Math.max(9, Math.round(f));
    const off = (f - 1) % 4;
    if (off === 0) return f;
    return off < 2 ? f - off : f + (4 - off);
}

// ----- Color palette (director theme, matched to LTX) -----
const COLOR_BG_MAIN     = "#18181b";
const COLOR_BG_PANEL    = "#27272a";
const COLOR_BG_DEEP     = "#111113";
const COLOR_BG_INPUT    = "#000000";
const COLOR_BORDER      = "#3f3f46";
const COLOR_BORDER_IN   = "#52525b";
const COLOR_DIVIDER     = "#3f3f46";
const COLOR_TEXT        = "#e4e4e7";
const COLOR_TEXT_MUTED  = "#a1a1aa";
const COLOR_ACCENT      = "#3b82f6";

// Badge colors
const BADGE_PROMPT         = "#56b4e9";
const BADGE_ANCHOR         = "#f0e442";
const BADGE_PROMOTE        = "#e69f00";
const BADGE_MIDDLE         = "#009e73";
const BADGE_END            = "#cc79a7";

// ----- Hidden widgets the editor manages -----
const HIDDEN_WIDGETS = [
    "segments_json", "global_prompt", "negative_prompt", "anchor_image_filename",
    "ollama_model", "ollama_url", "ollama_story_concept", "ollama_custom_direction",
    "ollama_system_prompt", "ollama_temperature", "ollama_ctx", "ollama_use_frame",
    "ollama_unload_after_gen", "ollama_side_panel", "ollama_per_segment", "ollama_enhance",
    "system_prompt_preset_filename", "auto_generate_on_queue", "reroll_on_queue",
    "stitch_policy", "overlap_blend_frames", "overlap_side", "startup_trim",
    "decode_per_segment", "color_correction", "continue_frames_count", "svi_motion_strength",
    "augment_empty_frames", "everanimate_mode", "reference_strength", "anchor_frame_offset", "spill_to_disk",
    "rope_negative_offset", "rope_negative_offset_frames",
    "svipro_motion_latent_count",
    "width", "height", "steps", "split_step", "cfg_high", "cfg_low", "scheduler", "seed_policy",
    "shift", "rope_function",
    "nag_enabled", "nag_scale", "nag_tau", "nag_alpha", "nag_apply_to"
];

const IMAGE_EXT_RE = /\.(png|jpe?g|webp|bmp)$/i;

// =========================================================================
// Helpers
// =========================================================================

function hideWidget(w) {
    if (!w) return;
    w.type = "WANLOOPER_HIDDEN";
    w.computeSize = () => [0, -4];
    w.draw = () => {};
    const elems = [w.inputEl, w.element].filter(Boolean);
    for (const el of elems) {
        el.style.display = "none";
        el.hidden = true;
        let p = el.parentElement;
        let hops = 0;
        while (p && hops < 6) {
            if (p.classList && p.classList.contains("dom-widget")) {
                p.style.display = "none";
                p.style.height = "0px";
                p.style.minHeight = "0px";
                p.style.padding = "0";
                p.style.margin = "0";
                p.dataset.wldHidden = "1";
                break;
            }
            p = p.parentElement;
            hops++;
        }
    }
    if (w.options) w.options.hidden = true;
}

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

function findWidget(node, name) {
    return (node.widgets || []).find(w => w.name === name);
}

function swallowKeys(el) {
    el.addEventListener("keydown", e => e.stopPropagation());
    el.addEventListener("keyup", e => e.stopPropagation());
    el.addEventListener("keypress", e => e.stopPropagation());
}

function parseSegmentsJson(s) {
    if (!s || typeof s !== "string") return [];
    try {
        const arr = JSON.parse(s);
        if (!Array.isArray(arr)) return [];
        return arr.map(normalizeSegment).filter(Boolean);
    } catch (e) {
        return [];
    }
}

function normalizeSegment(s) {
    if (!s || typeof s !== "object") return null;
    return {
        frames: Math.max(9, parseInt(s.frames, 10) || 81),
        prompt: typeof s.prompt === "string" ? s.prompt : "",
        anchor_mode: ["global", "previous_last_frame", "custom_override"].includes(s.anchor_mode) ? s.anchor_mode : "global",
        promote_anchor: !!s.promote_anchor,
        seed_override: (s.seed_override === null || s.seed_override === undefined) ? null : parseInt(s.seed_override, 10),
        cfg_high_override: (s.cfg_high_override === null || s.cfg_high_override === undefined) ? null : parseFloat(s.cfg_high_override),
        cfg_low_override: (s.cfg_low_override === null || s.cfg_low_override === undefined) ? null : parseFloat(s.cfg_low_override),
        width_override: (s.width_override === null || s.width_override === undefined) ? null : parseInt(s.width_override, 10),
        height_override: (s.height_override === null || s.height_override === undefined) ? null : parseInt(s.height_override, 10),
        anchor_image_filename: typeof s.anchor_image_filename === "string" ? s.anchor_image_filename : "",
        middle_image_filename: typeof s.middle_image_filename === "string" ? s.middle_image_filename : "",
        end_image_filename: typeof s.end_image_filename === "string" ? s.end_image_filename : "",
        memory_image_filenames: Array.isArray(s.memory_image_filenames) ? s.memory_image_filenames.slice() : [],
        model_preset: typeof s.model_preset === "string" ? s.model_preset : null,
    };
}

function defaultSegment(frames) {
    return normalizeSegment({ frames: frames || 81 });
}

function extractJsonFromResponse(text) {
    if (!text) return null;
    text = text.replace(/```(?:json)?\s*/gi, "").replace(/```/g, "");
    const start = text.indexOf("{");
    if (start < 0) return null;
    let depth = 0;
    for (let i = start; i < text.length; i++) {
        if (text[i] === "{") depth++;
        else if (text[i] === "}") {
            depth--;
            if (depth === 0) {
                const candidate = text.slice(start, i + 1);
                try { return JSON.parse(candidate); }
                catch { return null; }
            }
        }
    }
    return null;
}

// =========================================================================
// LooperEditor class
// =========================================================================

class LooperEditor {
    constructor(node, mount) {
        this.node = node;
        this.mount = mount;

        this.segmentsWidget        = findWidget(node, "segments_json");
        this.globalPromptWidget    = findWidget(node, "global_prompt");
        this.negativePromptWidget  = findWidget(node, "negative_prompt");
        this.anchorFilenameWidget  = findWidget(node, "anchor_image_filename");
        this.ollamaModelWidget     = findWidget(node, "ollama_model");
        this.ollamaUrlWidget       = findWidget(node, "ollama_url");
        this.ollamaStoryWidget     = findWidget(node, "ollama_story_concept");
        this.ollamaDirectionWidget = findWidget(node, "ollama_custom_direction");
        this.ollamaSystemWidget    = findWidget(node, "ollama_system_prompt");
        this.ollamaTempWidget      = findWidget(node, "ollama_temperature");
        this.ollamaCtxWidget       = findWidget(node, "ollama_ctx");
        this.ollamaUseFrameWidget  = findWidget(node, "ollama_use_frame");
        this.ollamaUnloadWidget    = findWidget(node, "ollama_unload_after_gen");
        this.ollamaPerSegmentWidget= findWidget(node, "ollama_per_segment");
        this.ollamaEnhanceWidget   = findWidget(node, "ollama_enhance");
        this.presetWidget          = findWidget(node, "system_prompt_preset_filename");
        this.autoGenWidget         = findWidget(node, "auto_generate_on_queue");
        this.rerollWidget          = findWidget(node, "reroll_on_queue");

        this.segments = parseSegmentsJson(this.segmentsWidget ? this.segmentsWidget.value : "");
        if (this.segments.length === 0) {
            this.segments.push(defaultSegment());
            this._saveSegments();
        }
        this.selectedIdx = 0;
        this._activeProgressSeg = null;
        this._activeProgressPhase = null;
        
        this._isAllFolded = false;
        this._collapsibles = [];

        this._build();
        this._scheduleRender();
        this._installVisibilityWatchdog();
    }

    _saveSegments() {
        if (!this.segmentsWidget) return;
        this.segmentsWidget.value = JSON.stringify(this.segments, null, 2);
        if (this.segmentsWidget.callback) { try { this.segmentsWidget.callback(this.segmentsWidget.value); } catch (e) { } }
        try { this._refreshAdvancedVisibility(); } catch (e) { }
    }

    _build() {
        for (const name of HIDDEN_WIDGETS) {
            hideWidget(findWidget(this.node, name));
        }

        this.root = document.createElement("div");
        this.root.style.cssText = `
            display: flex; flex-direction: column; gap: 10px;
            background: ${COLOR_BG_MAIN};
            color: ${COLOR_TEXT};
            padding: 10px;
            border-radius: 6px;
            font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
            font-size: 12px;
            width: 100%;
            min-width: 320px;
            max-width: 100%;
            box-sizing: border-box;
            box-shadow: inset 0 2px 5px rgba(0,0,0,0.5);
        `;
        this.mount.appendChild(this.root);

        this.mainCol = document.createElement("div");
        this.mainCol.style.cssText = `
            display: flex; flex-direction: column; gap: 10px;
            flex: 1 1 auto;
            min-width: 0;
            box-sizing: border-box;
        `;
        this.root.appendChild(this.mainCol);

        // --- NATIVE DOM PREVIEW CONTAINER ---
        this.previewContainer = document.createElement("div");
        this.previewContainer.style.cssText = `
            display: none; 
            width: 100%; 
            border-radius: 6px; 
            overflow: hidden; 
            border: 1px solid ${COLOR_BORDER_IN}; 
            background: #000;
            position: relative;
        `;
        
        const previewHeader = document.createElement("div");
        previewHeader.style.cssText = `
            background: rgba(0,0,0,0.6);
            color: rgba(255,255,255,0.8);
            font-size: 10px;
            padding: 4px 8px;
            position: absolute;
            top: 0; left: 0; right: 0;
            z-index: 2;
            font-weight: 600;
            text-transform: uppercase;
            pointer-events: none;
        `;
        previewHeader.textContent = "Live Preview (TAESD)";
        this.previewContainer.appendChild(previewHeader);

        this.previewImage = document.createElement("img");
        this.previewImage.style.cssText = `
            width: 100%; 
            height: auto; 
            display: block; 
            position: relative; 
            z-index: 1;
        `;
        this.previewImage.onload = () => {
            this._updateNodeSize();
        };
        this.previewContainer.appendChild(this.previewImage);
        this.mainCol.appendChild(this.previewContainer);

        this._buildHeader();
        this._buildTimelineRow();
        this._buildSettingsRow(); 
    }

    _updateNodeSize() {
        if (!this.node) return;
        try {
            requestAnimationFrame(() => {
                if (typeof this.node.computeSize === "function") {
                    const sz = this.node.computeSize();
                    if (this.node.size && Array.isArray(this.node.size)) {
                        this.node.size[1] = sz[1];
                    }
                }
                if (this.node.graph && typeof this.node.graph.setDirtyCanvas === "function") {
                    this.node.graph.setDirtyCanvas(true, true);
                }
            });
        } catch (e) { }
    }

    _buildHeader() {
        const bar = document.createElement("div");
        bar.style.cssText = "display: flex; align-items: center; justify-content: space-between; padding: 0 4px;";

        const title = document.createElement("div");
        title.textContent = "Wan Looper Control Center";
        title.style.cssText = "font-weight: 700; font-size: 14px; letter-spacing: 0.5px; color: " + COLOR_TEXT + ";";
        bar.appendChild(title);

        const rightGrp = document.createElement("div");
        rightGrp.style.cssText = "display: flex; align-items: center; gap: 10px;";

        this.segmentCountLabel = document.createElement("span");
        this.segmentCountLabel.style.cssText = "color: " + COLOR_TEXT_MUTED + "; font-size: 11px; font-weight: 500;";
        rightGrp.appendChild(this.segmentCountLabel);

        const collapseAllBtn = document.createElement("button");
        collapseAllBtn.textContent = "Toggle Fold All";
        this._styleButton(collapseAllBtn, "small");
        collapseAllBtn.onclick = (ev) => {
            ev.stopPropagation();
            this._isAllFolded = !this._isAllFolded;
            this._collapsibles.forEach(c => c.setOpen(!this._isAllFolded));
            this._updateNodeSize();
        };
        rightGrp.appendChild(collapseAllBtn);

        const clearPreviewBtn = document.createElement("button");
        clearPreviewBtn.textContent = "Clear preview";
        this._styleButton(clearPreviewBtn, "small");
        clearPreviewBtn.onclick = (ev) => {
            ev.stopPropagation();
            this._clearNodePreview();
        };
        rightGrp.appendChild(clearPreviewBtn);

        bar.appendChild(rightGrp);
        this.mainCol.appendChild(bar);
    }

    _buildTimelineRow() {
        const tlBox = document.createElement("div");
        tlBox.style.cssText = `
            display: flex; flex-direction: column; gap: 6px;
            background: ${COLOR_BG_PANEL}; border: 1px solid ${COLOR_BORDER};
            border-radius: 6px; padding: 8px; width: 100%; box-sizing: border-box; overflow: hidden;
        `;

        const tlHeader = document.createElement("div");
        tlHeader.style.cssText = "display: flex; justify-content: space-between; align-items: center;";

        const tlLabel = document.createElement("div");
        tlLabel.textContent = "Segments Timeline";
        tlLabel.style.cssText = "font-weight: 600; font-size: 11px; color: " + COLOR_TEXT_MUTED + "; text-transform: uppercase;";
        tlHeader.appendChild(tlLabel);

        const addBtn = document.createElement("button");
        addBtn.textContent = "+ Add Segment";
        this._styleButton(addBtn, "small");
        addBtn.style.backgroundColor = COLOR_ACCENT;
        addBtn.style.borderColor = COLOR_ACCENT;
        addBtn.style.color = "#ffffff";
        addBtn.onclick = () => this._addSegment();
        tlHeader.appendChild(addBtn);

        tlBox.appendChild(tlHeader);

        this.segGridContainer = document.createElement("div");
        this.segGridContainer.style.cssText = `
            display: flex; flex-wrap: wrap; gap: 6px;
            background: ${COLOR_BG_DEEP}; border: 1px solid ${COLOR_BORDER_IN};
            border-radius: 4px; padding: 8px; min-height: 38px;
        `;
        this.segGridContainer.oncontextmenu = (e) => {
            if (e.target === this.segGridContainer) {
                e.preventDefault();
                this._showEmptyMenu(e.clientX, e.clientY);
            }
        };

        tlBox.appendChild(this.segGridContainer);
        this.mainCol.appendChild(tlBox);
    }

    _mkInlineCollapsible(title, opts) {
        opts = opts || {};
        const startOpen = opts.startOpen !== false;
        const bodyDirection = opts.bodyDirection || "column";
        const bodyGap = opts.bodyGap || "6px";
        const customTitleEl = opts.titleEl || null;

        const wrap = document.createElement("div");
        wrap.style.cssText = "display: flex; flex-direction: column;";

        const header = document.createElement("div");
        header.style.cssText = `display: flex; align-items: center; gap: 6px; cursor: pointer; user-select: none; padding: 4px 0; transition: 0.2s; border-bottom: 1px solid ${COLOR_DIVIDER};`;
        const chevron = document.createElement("span");
        chevron.textContent = "▶";
        chevron.style.cssText = `color: ${COLOR_TEXT_MUTED}; font-size: 9px; display: inline-block; transition: transform 0.2s;`;
        if (startOpen) chevron.style.transform = "rotate(90deg)";
        header.appendChild(chevron);

        const titleEl = customTitleEl || document.createElement("span");
        if (!customTitleEl) {
            titleEl.textContent = title;
            titleEl.style.cssText = `font-size: 11px; font-weight: 700; color: ${COLOR_TEXT_MUTED}; text-transform: uppercase;`;
        }
        header.appendChild(titleEl);

        wrap.appendChild(header);

        const body = document.createElement("div");
        body.style.cssText = `display: ${startOpen ? "flex" : "none"}; flex-direction: ${bodyDirection}; gap: ${bodyGap}; padding-top: 8px;`;
        wrap.appendChild(body);

        const setOpen = (open) => {
            body.style.display = open ? "flex" : "none";
            chevron.style.transform = open ? "rotate(90deg)" : "";
            this._updateNodeSize();
        };

        header.onclick = () => {
            const isOpen = body.style.display !== "none";
            setOpen(!isOpen);
        };
        header.onmouseover = () => { titleEl.style.color = COLOR_TEXT; titleEl.style.opacity = "0.85"; };
        header.onmouseout  = () => { titleEl.style.color = COLOR_TEXT_MUTED; titleEl.style.opacity = "1"; };

        this._collapsibles.push({ setOpen });
        return { wrap, header, body, setOpen };
    }

    _buildSettingsRow() {
        const row = document.createElement("div");
        row.style.cssText = "display: flex; gap: 10px; align-items: stretch; flex-wrap: wrap; width: 100%; box-sizing: border-box;";

        // ==========================================
        // LEFT COL: SEGMENTS
        // ==========================================
        const segBox = document.createElement("div");
        segBox.style.cssText = `
            flex: 1 1 50%; min-width: 0; max-width: 100%;
            display: flex; flex-direction: column; gap: 10px; background: ${COLOR_BG_PANEL};
            border: 1px solid ${COLOR_BORDER}; border-radius: 6px; padding: 10px; box-sizing: border-box; overflow: hidden;
        `;

        this.segTitleEl = document.createElement("div");
        this.segTitleEl.textContent = "Segments";
        this.segTitleEl.style.cssText = "font-weight: 700; font-size: 12px; color: " + COLOR_TEXT + ";";
        const segCollapse = this._mkInlineCollapsible("Segments", { startOpen: true, titleEl: this.segTitleEl });
        
        // --- Segments Body (Contains list + details so everything folds together) ---
        const segBoxBody = segCollapse.body;

        this.sidebarSegList = document.createElement("div");
        this.sidebarSegList.style.cssText = `display: flex; flex-direction: column; gap: 4px; max-height: 240px; overflow-y: auto; padding-right: 2px;`;
        segBoxBody.appendChild(this.sidebarSegList);

        const sbDivider = document.createElement("div");
        sbDivider.style.cssText = `height: 1px; background: ${COLOR_DIVIDER}; margin: 6px 0;`;
        segBoxBody.appendChild(sbDivider);

        // Details Panel
        this.sidebarDetailWrap = document.createElement("div");
        this.sidebarDetailWrap.style.cssText = "display: flex; flex-direction: column; gap: 8px;";
        
        this.detailHeader = document.createElement("div");
        this.detailHeader.style.cssText = "font-weight: 700; font-size: 11px; color: " + COLOR_TEXT_MUTED + "; text-transform: uppercase;";
        this.sidebarDetailWrap.appendChild(this.detailHeader);

        this.sbPromptArea = document.createElement("textarea");
        this.sbPromptArea.rows = 4;
        this._styleTextarea(this.sbPromptArea);
        swallowKeys(this.sbPromptArea);
        this.sbPromptArea.oninput = () => {
            if (this.selectedIdx < 0) return;
            this.segments[this.selectedIdx].prompt = this.sbPromptArea.value;
            this._saveSegments();
            this._scheduleRender();
        };
        this.sidebarDetailWrap.appendChild(this.sbPromptArea);

        const sGrid = document.createElement("div");
        sGrid.style.cssText = `
            display: grid; gap: 6px 12px; grid-template-columns: minmax(50px, max-content) minmax(0, 1fr);
            align-items: center; background: ${COLOR_BG_DEEP}; padding: 8px; border-radius: 4px; border: 1px solid ${COLOR_BORDER_IN};
            min-width: 0; max-width: 100%; box-sizing: border-box; overflow: hidden;
        `;
        
        const appendCell = (control) => {
            const cell = document.createElement("div");
            cell.style.cssText = "min-width: 0; max-width: 100%; overflow: hidden; box-sizing: border-box;";
            cell.appendChild(control);
            sGrid.appendChild(cell);
        };

        sGrid.appendChild(this._mkLabel("Frames (4n+1)"));
        this.sbFramesInput = document.createElement("input");
        this.sbFramesInput.type = "number";
        this.sbFramesInput.min = "9";
        this.sbFramesInput.step = "4";
        this._styleInput(this.sbFramesInput);
        swallowKeys(this.sbFramesInput);
        this.sbFramesInput.oninput = () => {
            if (this.selectedIdx < 0) return;
            const v = parseInt(this.sbFramesInput.value, 10);
            if (!isFinite(v)) return;
            this.segments[this.selectedIdx].frames = snapFramesToWanGrid(v);
            this._saveSegments();
            this._scheduleRender();
        };
        this.sbFramesInput.onblur = () => {
            if (this.selectedIdx < 0) return;
            this.sbFramesInput.value = String(this.segments[this.selectedIdx].frames);
        };
        appendCell(this.sbFramesInput);

        sGrid.appendChild(this._mkLabel("Anchor Mode"));
        this.sbAnchorSelect = document.createElement("select");
        this._styleInput(this.sbAnchorSelect);
        for (const [v, lbl] of [["global", "Global (Persistent)"], ["previous_last_frame", "Prev Last Frame"], ["custom_override", "Custom Override"]]) {
            const opt = document.createElement("option"); opt.value = v; opt.textContent = lbl; this.sbAnchorSelect.appendChild(opt);
        }
        this.sbAnchorSelect.onchange = () => {
            if (this.selectedIdx < 0) return;
            this.segments[this.selectedIdx].anchor_mode = this.sbAnchorSelect.value;
            this._saveSegments();
            this._scheduleRender();
        };
        appendCell(this.sbAnchorSelect);

        sGrid.appendChild(this._mkLabel("Seed Override"));
        this.sbSeedInput = document.createElement("input");
        this.sbSeedInput.type = "number";
        this.sbSeedInput.placeholder = "(inherit)";
        this._styleInput(this.sbSeedInput);
        swallowKeys(this.sbSeedInput);
        this.sbSeedInput.oninput = () => {
            if (this.selectedIdx < 0) return;
            const v = this.sbSeedInput.value.trim();
            this.segments[this.selectedIdx].seed_override = v === "" ? null : parseInt(v, 10);
            this._saveSegments();
        };
        appendCell(this.sbSeedInput);

        this.sidebarDetailWrap.appendChild(sGrid);

        this.sbPromoteWrap = document.createElement("label");
        this.sbPromoteWrap.style.cssText = "display: flex; gap: 6px; align-items: center; cursor: pointer; font-size: 11px; margin-top: -2px;";
        this.sbPromoteCheck = document.createElement("input");
        this.sbPromoteCheck.type = "checkbox";
        this.sbPromoteCheck.onchange = () => {
            if (this.selectedIdx < 0) return;
            this.segments[this.selectedIdx].promote_anchor = this.sbPromoteCheck.checked;
            this._saveSegments();
            this._scheduleRender();
        };
        this.sbPromoteWrap.appendChild(this.sbPromoteCheck);
        const promoteSpan = document.createElement("span");
        promoteSpan.textContent = "Promote to new persistent anchor sequence";
        promoteSpan.style.color = COLOR_TEXT_MUTED;
        this.sbPromoteWrap.appendChild(promoteSpan);

        this.sidebarDetailWrap.appendChild(this.sbPromoteWrap);

        segBoxBody.appendChild(this.sidebarDetailWrap);
        segBox.appendChild(segCollapse.wrap);


        // ==========================================
        // RIGHT COL: GLOBALS AND ADVANCED
        // ==========================================
        this.globalBox = document.createElement("div");
        this.globalBox.style.cssText = `
            flex: 1 1 50%; min-width: 0; max-width: 100%;
            display: flex; flex-direction: column; gap: 10px; background: ${COLOR_BG_PANEL};
            border: 1px solid ${COLOR_BORDER}; border-radius: 6px; padding: 10px; box-sizing: border-box; overflow: hidden;
        `;
        
        const gTitleEl = document.createElement("div");
        gTitleEl.textContent = "Global Generation Setup";
        gTitleEl.style.cssText = "font-weight: 700; font-size: 12px; color: " + COLOR_TEXT + ";";
        const globalCollapse = this._mkInlineCollapsible("Global Generation Setup", { startOpen: true, titleEl: gTitleEl });
        
        const globalGridWrap = document.createElement("div");
        globalGridWrap.style.cssText = "display: flex; flex-direction: column; gap: 6px;";
        this._buildWidgetGrid(globalGridWrap, [
            ["width", "Width"], ["height", "Height"],
            ["steps", "Steps"], ["split_step", "Split"],
            ["cfg_high", "CFG High"], ["cfg_low", "CFG Low"],
            ["scheduler", "Scheduler"], ["seed_policy", "Seed Policy"],
            ["shift", "Shift"], ["rope_function", "RoPE Function"]
        ]);
        globalCollapse.body.appendChild(globalGridWrap);
        this.globalBox.appendChild(globalCollapse.wrap);

        // Fallback Prompt Collapsible
        const promptsCollapse = this._mkInlineCollapsible("Fallback Prompt", { startOpen: true });
        this.globalBox.appendChild(promptsCollapse.wrap);
        const promptsBody = promptsCollapse.body;

        promptsBody.appendChild(this._mkLabel("Fallback Prompt", "If Segment doesn't have a prompt this fallback prompt will be used"));
        this.globalPromptArea = document.createElement("textarea");
        this.globalPromptArea.rows = 3; 
        this._styleTextarea(this.globalPromptArea);
        this.globalPromptArea.value = this.globalPromptWidget ? this.globalPromptWidget.value : "";
        this.globalPromptArea.oninput = () => { if (this.globalPromptWidget) this.globalPromptWidget.value = this.globalPromptArea.value; };
        swallowKeys(this.globalPromptArea);
        promptsBody.appendChild(this.globalPromptArea);

        // Advanced Logic Parameters Collapsible
        const advCollapse = this._mkInlineCollapsible("Advanced Logic Parameters", { startOpen: false });
        this.globalBox.appendChild(advCollapse.wrap);
        const advBody = advCollapse.body;

        this._buildAdvancedGroup(advBody, "Stitch & Decode", [
            ["stitch_policy", "Stitch policy"], 
            ["decode_per_segment", "Decode policy"], // Moved under Stitch Policy
            ["overlap_blend_frames", "Blend overlap (frames)"], 
            ["overlap_side", "Overlap side"],
            ["startup_trim", "Startup trim (frames)"], 
            ["color_correction", "Color correction"]
        ]);

        this._buildAdvancedGroup(advBody, "SVI 2.0 Pro Continuation", [
            ["svipro_motion_latent_count", "SVI Pro motion latents"], ["everanimate_mode", "EverAnimate Mode (N=4)"], ["augment_empty_frames", "Augment empty frames"], ["anchor_frame_offset", "Anchor frame offset"],
            ["continue_frames_count", "Continue frames count (legacy)"], ["svi_motion_strength", "SVI motion strength (legacy)"], ["reference_strength", "Reference strength seg 1 (legacy)"]
        ]);

        this._buildAdvancedGroup(advBody, "Runtime", [
            ["spill_to_disk", "Spill segments to disk"], ["rope_negative_offset", "RoPE negative offset (StoryMem)"], ["rope_negative_offset_frames", "RoPE offset frames (StoryMem)"]
        ]);

        // NAG section with Negative Prompt tucked inside
        const nagHeader = document.createElement("div");
        nagHeader.textContent = "NAG (CFG=1 Negative Prompting)";
        nagHeader.style.cssText = `font-size: 11px; font-weight: 600; color: ${COLOR_TEXT_MUTED}; margin: 6px 0 2px 0; border-bottom: 1px solid ${COLOR_DIVIDER}; padding-bottom: 2px; text-transform: uppercase; letter-spacing: 0.05em;`;
        advBody.appendChild(nagHeader);

        const negWrap = document.createElement("div");
        negWrap.dataset.advRowKey = "negative_prompt_wrap";
        negWrap.style.cssText = "display: flex; flex-direction: column; gap: 4px; margin-bottom: 6px;";
        negWrap.appendChild(this._mkLabel("Negative Prompt", "Pushes attention away from these concepts"));

        this.negativePromptArea = document.createElement("textarea");
        this.negativePromptArea.rows = 2; 
        this._styleTextarea(this.negativePromptArea);
        this.negativePromptArea.value = this.negativePromptWidget ? this.negativePromptWidget.value : "";
        this.negativePromptArea.oninput = () => { if (this.negativePromptWidget) this.negativePromptWidget.value = this.negativePromptArea.value; };
        swallowKeys(this.negativePromptArea);
        negWrap.appendChild(this.negativePromptArea);
        advBody.appendChild(negWrap);

        this._buildAdvancedGroup(advBody, "", [ // Empty string since we made the header manually
            ["nag_enabled", "Enable NAG"], ["nag_scale", "NAG scale"], ["nag_tau", "NAG tau (clamp)"], ["nag_alpha", "NAG alpha (blend)"], ["nag_apply_to", "Apply to phase"]
        ]);

        // Add Ollama into Global Setup perfectly tucked
        this._buildOllamaPanel(this.globalBox);

        // Wiring to automatically update/refresh visibility on changes
        const decodeW = findWidget(this.node, "decode_per_segment");
        if (decodeW) {
            const prev = decodeW.callback;
            decodeW.callback = (v) => {
                if (prev) try { prev(v); } catch (e) {}
                try { this._refreshAdvancedVisibility(); } catch (e) {}
            };
        }
        const stitchW = findWidget(this.node, "stitch_policy");
        if (stitchW) {
            const prev = stitchW.callback;
            stitchW.callback = (v) => {
                if (prev) try { prev(v); } catch (e) {}
                try { this._refreshAdvancedVisibility(); } catch (e) {}
            };
        }

        const nagW = findWidget(this.node, "nag_enabled");
        if (nagW) {
            const prev = nagW.callback;
            nagW.callback = (v) => {
                if (prev) try { prev(v); } catch (e) {}
                try { this._refreshAdvancedVisibility(); } catch (e) {}
            };
        }

        row.appendChild(segBox);
        row.appendChild(this.globalBox);

        this.mainCol.appendChild(row);
        this._populateSidebar();
        this._refreshAdvancedVisibility();
    }

    _buildAdvancedGroup(parent, label, fields) {
        if (label) {
            const groupHeader = document.createElement("div");
            groupHeader.textContent = label;
            groupHeader.style.cssText = `font-size: 11px; font-weight: 600; color: ${COLOR_TEXT_MUTED}; margin: 6px 0 2px 0; border-bottom: 1px solid ${COLOR_DIVIDER}; padding-bottom: 2px; text-transform: uppercase; letter-spacing: 0.05em;`;
            parent.appendChild(groupHeader);
        }
        const grid = document.createElement("div");
        grid.style.cssText = `display: grid; gap: 4px 12px; grid-template-columns: minmax(120px, max-content) minmax(0, 1fr); align-items: center; min-width: 0; max-width: 100%; box-sizing: border-box; overflow: hidden;`;
        parent.appendChild(grid);
        for (const [widgetName, lblText] of fields) {
            const widget = findWidget(this.node, widgetName);
            if (!widget) continue;
            const lbl = document.createElement("div"); lbl.textContent = lblText; lbl.style.cssText = "font-size: 11px; color: " + COLOR_TEXT + ";";
            if (widget.options && widget.options.tooltip) lbl.title = widget.options.tooltip;
            lbl.dataset.advRowKey = widgetName;
            grid.appendChild(lbl);
            const control = this._mkWidgetMirror(widget);
            if (widget.options && widget.options.tooltip && control) control.title = widget.options.tooltip;
            if (control) control.dataset.advRowKey = widgetName;
            grid.appendChild(control);
        }
    }

    _buildWidgetGrid(parent, fields) {
        const grid = document.createElement("div");
        grid.style.cssText = `display: grid; gap: 6px 10px; grid-template-columns: minmax(50px, max-content) minmax(0, 1fr) minmax(50px, max-content) minmax(0, 1fr); align-items: center; background: ${COLOR_BG_DEEP}; padding: 8px; border-radius: 4px; border: 1px solid ${COLOR_BORDER_IN}; min-width: 0; max-width: 100%; box-sizing: border-box; overflow: hidden;`;
        for (const [widgetName, lblText] of fields) {
            const widget = findWidget(this.node, widgetName);
            if (!widget) continue;
            const lbl = document.createElement("div");
            lbl.textContent = lblText;
            lbl.style.cssText = "font-size: 11px; font-weight: 500; color: " + COLOR_TEXT_MUTED + "; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;";
            if (widget.options && widget.options.tooltip) lbl.title = widget.options.tooltip;
            grid.appendChild(lbl);
            const control = this._mkWidgetMirror(widget);
            if (widget.options && widget.options.tooltip && control) control.title = widget.options.tooltip;
            const cell = document.createElement("div");
            cell.style.cssText = "min-width: 0; max-width: 100%; overflow: hidden;";
            if (control) {
                if (control.style) { control.style.width = "100%"; control.style.minWidth = "0"; control.style.maxWidth = "100%"; control.style.boxSizing = "border-box"; control.style.textOverflow = "ellipsis"; }
                cell.appendChild(control);
            }
            grid.appendChild(cell);
        }
        parent.appendChild(grid);
    }

    _setAdvancedRowVisible(widgetName, visible) {
        if (!this.mainCol) return;
        const els = this.mainCol.querySelectorAll(`[data-adv-row-key="${widgetName}"]`);
        for (const el of els) { el.style.display = visible ? "" : "none"; }
    }

    _refreshAdvancedVisibility() {
        this._setAdvancedRowVisible("reference_strength",   false);
        this._setAdvancedRowVisible("svi_motion_strength",  false);
        this._setAdvancedRowVisible("continue_frames_count", false);

        const anchorOffsetLive = (this.segments || []).some(s => s.anchor_mode === "previous_last_frame" || s.promote_anchor === true);
        this._setAdvancedRowVisible("anchor_frame_offset", anchorOffsetLive);

        const memWired = (this.node && this.node.inputs || []).some(i => i.name === "memory_images" && i.link != null);
        this._setAdvancedRowVisible("rope_negative_offset",        memWired);
        this._setAdvancedRowVisible("rope_negative_offset_frames", memWired);

        const stitchWidget = findWidget(this.node, "stitch_policy");
        const isBlendActive = stitchWidget && ["linear_blend", "ease_in_out", "filmic_crossfade"].includes(stitchWidget.value);

        const decodeWidget = findWidget(this.node, "decode_per_segment");
        const decodeRowEls = this.mainCol.querySelectorAll(`[data-adv-row-key="decode_per_segment"]`);
        decodeRowEls.forEach(el => {
            if (el.tagName === "SELECT") {
                if (isBlendActive) {
                    el.disabled = true;
                    el.style.opacity = "0.4";
                    el.title = "Forced to decode 'always' because a blending stitch policy is active.";
                } else {
                    el.disabled = false;
                    el.style.opacity = "1";
                    el.title = "Decode per-segment images for intermediate use.";
                }
            }
        });

        const trimLive = decodeWidget && decodeWidget.value === "always";
        this._setAdvancedRowVisible("startup_trim", trimLive);

        const nagWidget = findWidget(this.node, "nag_enabled");
        const nagLive = nagWidget && nagWidget.value === true;
        this._setAdvancedRowVisible("nag_scale",    nagLive);
        this._setAdvancedRowVisible("nag_tau",      nagLive);
        this._setAdvancedRowVisible("nag_alpha",    nagLive);
        this._setAdvancedRowVisible("nag_apply_to", nagLive);
        this._setAdvancedRowVisible("negative_prompt_wrap", nagLive);
    }

    _mkLabel(text, hint) {
        const wrap = document.createElement("div"); wrap.style.cssText = `font-size: 11px; font-weight: 600; color: ${COLOR_TEXT_MUTED}; display: flex; justify-content: space-between;`;
        const l = document.createElement("span"); l.textContent = text; wrap.appendChild(l);
        if (hint) { const h = document.createElement("span"); h.textContent = hint; h.style.cssText = "font-size: 9px; font-weight: 400; opacity: 0.7;"; wrap.appendChild(h); }
        return wrap;
    }

    _styleInput(el) {
        el.style.cssText = `width: 100%; min-width: 0; background: ${COLOR_BG_INPUT}; color: ${COLOR_TEXT}; border: 1px solid ${COLOR_BORDER_IN}; border-radius: 4px; padding: 4px 6px; font-family: inherit; font-size: 11px; outline: none; box-sizing: border-box; transition: 0.2s;`;
        el.onfocus = () => el.style.borderColor = COLOR_ACCENT;
        el.onblur = () => el.style.borderColor = COLOR_BORDER_IN;
    }

    _styleTextarea(el) {
        el.style.cssText = `width: 100%; box-sizing: border-box; background: ${COLOR_BG_INPUT}; color: ${COLOR_TEXT}; border: 1px solid ${COLOR_BORDER_IN}; border-radius: 4px; padding: 6px; font-family: inherit; font-size: 11px; resize: vertical; outline: none; transition: 0.2s;`;
        el.onfocus = () => el.style.borderColor = COLOR_ACCENT;
        el.onblur = () => el.style.borderColor = COLOR_BORDER_IN;
    }

    _styleButton(el, size) {
        const pad = size === "small" ? "2px 6px" : "4px 10px";
        const fs = size === "small" ? "10px" : "11px";
        el.style.cssText = `background: ${COLOR_BG_INPUT}; color: ${COLOR_TEXT}; border: 1px solid ${COLOR_BORDER_IN}; border-radius: 4px; padding: ${pad}; font-family: inherit; font-size: ${fs}; font-weight: 500; cursor: pointer; outline: none; white-space: nowrap; transition: 0.2s;`;
        el.onmouseover = () => { el.style.background = COLOR_BG_PANEL; };
        el.onmouseout = () => { el.style.background = COLOR_BG_INPUT; };
    }

    _mkCheckbox(label, tooltip, onChange, initial) {
        const wrap = document.createElement("label"); wrap.title = tooltip; wrap.style.cssText = "display: flex; gap: 4px; align-items: center; cursor: pointer; font-size: 11px;";
        const cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = !!initial;
        cb.onchange = () => onChange(cb.checked);
        const text = document.createElement("span"); text.textContent = label;
        wrap.appendChild(cb); wrap.appendChild(text);
        return { wrap, cb };
    }

    _mkWidgetMirror(widget) {
        if (!widget) return null;
        const wType = widget.type;
        const opts  = widget.options || {};

        if (Array.isArray(opts.values)) {
            const sel = document.createElement("select"); this._styleInput(sel);
            for (const v of opts.values) {
                const opt = document.createElement("option"); opt.value = v; opt.textContent = v;
                if (v === widget.value) opt.selected = true; sel.appendChild(opt);
            }
            sel.onchange = () => { widget.value = sel.value; if (widget.callback) try { widget.callback(widget.value); } catch (e) {} };
            return sel;
        }

        if (wType === "BOOLEAN" || wType === "toggle" || typeof widget.value === "boolean") {
            const wrap = document.createElement("label"); wrap.style.cssText = "display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 11px;";
            const cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = !!widget.value;
            const span = document.createElement("span"); span.textContent = cb.checked ? "on" : "off"; span.style.color = COLOR_TEXT_MUTED;
            cb.onchange = () => { widget.value = cb.checked; span.textContent = cb.checked ? "on" : "off"; if (widget.callback) try { widget.callback(widget.value); } catch (e) {} };
            wrap.appendChild(cb); wrap.appendChild(span);
            return wrap;
        }

        const isInt = wType === "INT" || Number.isInteger(widget.value);
        const isFloat = wType === "FLOAT" || (!isInt && typeof widget.value === "number");
        if (isInt || isFloat) {
            const inp = document.createElement("input"); inp.type = "number";
            if (opts.min !== undefined) inp.min = String(opts.min);
            if (opts.max !== undefined) inp.max = String(opts.max);
            if (isInt) { const declaredStep = (opts.step !== undefined && opts.step !== 10) ? opts.step : 1; inp.step = String(declaredStep); }
            else if (opts.step !== undefined) { inp.step = String(opts.step); }
            else { inp.step = "0.05"; }
            this._styleInput(inp); inp.value = String(widget.value); swallowKeys(inp);
            inp.oninput = () => {
                const raw = inp.value; if (raw === "") return;
                const v = isInt ? parseInt(raw, 10) : parseFloat(raw); if (!isFinite(v)) return;
                widget.value = v; if (widget.callback) try { widget.callback(widget.value); } catch (e) {}
            };
            return inp;
        }

        const inp = document.createElement("input"); inp.type = "text"; this._styleInput(inp);
        inp.value = String(widget.value ?? ""); swallowKeys(inp);
        inp.oninput = () => { widget.value = inp.value; if (widget.callback) try { widget.callback(widget.value); } catch (e) {} };
        return inp;
    }

    _buildOllamaPanel(parentBox) {
        const ollamaCollapse = this._mkInlineCollapsible("Ollama Prompter", { startOpen: false });
        parentBox.appendChild(ollamaCollapse.wrap);
        const box = ollamaCollapse.body;

        const urlRow = document.createElement("div"); urlRow.style.cssText = "display: flex; gap: 6px;";
        this.ollamaUrlInput = document.createElement("input"); this.ollamaUrlInput.type = "text"; this.ollamaUrlInput.placeholder = "http://127.0.0.1:11434";
        this._styleInput(this.ollamaUrlInput); this.ollamaUrlInput.style.flex = "1 1 auto"; this.ollamaUrlInput.style.minWidth = "0";
        this.ollamaUrlInput.value = this.ollamaUrlWidget ? this.ollamaUrlWidget.value : "http://127.0.0.1:11434";
        this.ollamaUrlInput.oninput = () => { if (this.ollamaUrlWidget) this.ollamaUrlWidget.value = this.ollamaUrlInput.value; };
        swallowKeys(this.ollamaUrlInput); urlRow.appendChild(this.ollamaUrlInput);
        const refreshBtn = document.createElement("button"); refreshBtn.textContent = "Refresh"; this._styleButton(refreshBtn);
        refreshBtn.onclick = () => this._refreshOllamaModels(); urlRow.appendChild(refreshBtn); box.appendChild(urlRow);

        this.ollamaModelSelect = document.createElement("select"); this._styleInput(this.ollamaModelSelect);
        const blank = document.createElement("option"); blank.value = ""; blank.textContent = "(Off / No Model)"; this.ollamaModelSelect.appendChild(blank);
        if (this.ollamaModelWidget && this.ollamaModelWidget.value) {
            const o = document.createElement("option"); o.value = this.ollamaModelWidget.value; o.textContent = this.ollamaModelWidget.value; o.selected = true; this.ollamaModelSelect.appendChild(o);
        }
        this.ollamaModelSelect.onchange = () => { if (this.ollamaModelWidget) this.ollamaModelWidget.value = this.ollamaModelSelect.value; };
        box.appendChild(this.ollamaModelSelect);

        box.appendChild(this._mkLabel("Story / concept"));
        this.ollamaStoryArea = document.createElement("textarea"); this.ollamaStoryArea.rows = 3; this._styleTextarea(this.ollamaStoryArea);
        this.ollamaStoryArea.value = this.ollamaStoryWidget ? this.ollamaStoryWidget.value : "";
        this.ollamaStoryArea.oninput = () => { if (this.ollamaStoryWidget) this.ollamaStoryWidget.value = this.ollamaStoryArea.value; };
        swallowKeys(this.ollamaStoryArea); box.appendChild(this.ollamaStoryArea);

        box.appendChild(this._mkLabel("Custom direction", "(LoRA triggers, style notes)"));
        this.ollamaDirectionArea = document.createElement("textarea"); this.ollamaDirectionArea.rows = 2; this._styleTextarea(this.ollamaDirectionArea);
        this.ollamaDirectionArea.value = this.ollamaDirectionWidget ? this.ollamaDirectionWidget.value : "";
        this.ollamaDirectionArea.oninput = () => { if (this.ollamaDirectionWidget) this.ollamaDirectionWidget.value = this.ollamaDirectionArea.value; };
        swallowKeys(this.ollamaDirectionArea); box.appendChild(this.ollamaDirectionArea);

        const sysLabelRow = document.createElement("div"); sysLabelRow.style.cssText = "display: flex; gap: 6px; align-items: center; flex-wrap: wrap;";
        sysLabelRow.appendChild(this._mkLabel("System prompt", "(blank = default)"));
        const sysSpacer = document.createElement("div"); sysSpacer.style.flex = "1 1 auto"; sysLabelRow.appendChild(sysSpacer);
        const presetWrap = document.createElement("div"); presetWrap.style.cssText = "display: flex; align-items: center; gap: 6px; flex: 1 1 auto; justify-content: flex-end; min-width: 0; max-width: 100%; box-sizing: border-box;";
        const presetLbl = document.createElement("span"); presetLbl.textContent = "Preset:"; presetLbl.style.cssText = "font-size: 11px; color: " + COLOR_TEXT_MUTED + "; white-space: nowrap;"; presetWrap.appendChild(presetLbl);
        this.presetSelect = document.createElement("select"); this._styleInput(this.presetSelect); this.presetSelect.style.cssText += " flex: 1 1 auto; min-width: 0; text-overflow: ellipsis;";
        const presetBlank = document.createElement("option"); presetBlank.value = ""; presetBlank.textContent = "(Default)"; this.presetSelect.appendChild(presetBlank);
        this.presetSelect.onchange = () => this._loadPresetIntoSystemPrompt();
        presetWrap.appendChild(this.presetSelect); sysLabelRow.appendChild(presetWrap); box.appendChild(sysLabelRow);

        this.ollamaSystemArea = document.createElement("textarea"); this.ollamaSystemArea.rows = 4; this._styleTextarea(this.ollamaSystemArea);
        this.ollamaSystemArea.value = this.ollamaSystemWidget ? this.ollamaSystemWidget.value : "";
        this.ollamaSystemArea.oninput = () => {
            if (this.ollamaSystemWidget) this.ollamaSystemWidget.value = this.ollamaSystemArea.value;
            if (this.presetSelect.value) { this.presetSelect.value = ""; if (this.presetWidget) this.presetWidget.value = ""; }
        };
        swallowKeys(this.ollamaSystemArea); box.appendChild(this.ollamaSystemArea);

        const togRow1 = document.createElement("div"); togRow1.style.cssText = "display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-top: 4px;";
        this.useFrameCheck = this._mkCheckbox("Use anchor frame", "Include the global anchor image as vision input", v => { if (this.ollamaUseFrameWidget) this.ollamaUseFrameWidget.value = v; }, !!(this.ollamaUseFrameWidget && this.ollamaUseFrameWidget.value));
        togRow1.appendChild(this.useFrameCheck.wrap);
        this.perSegmentCheck = this._mkCheckbox("Per-segment", "Ollama returns JSON for all segments", v => { if (this.ollamaPerSegmentWidget) this.ollamaPerSegmentWidget.value = v; }, !!(this.ollamaPerSegmentWidget && this.ollamaPerSegmentWidget.value));
        togRow1.appendChild(this.perSegmentCheck.wrap);
        this.enhanceCheck = this._mkCheckbox("Enhance existing", "Rewrite current prompts in Wan 2.2 style", v => { if (this.ollamaEnhanceWidget) this.ollamaEnhanceWidget.value = v; }, !!(this.ollamaEnhanceWidget && this.ollamaEnhanceWidget.value));
        togRow1.appendChild(this.enhanceCheck.wrap);
        box.appendChild(togRow1);

        const togRow2 = document.createElement("div"); togRow2.style.cssText = "display: flex; flex-wrap: wrap; gap: 8px; align-items: center;";
        this.autoGenCheck = this._mkCheckbox("Auto-fill on queue", "ON: server runs Ollama at queue time IF base prompt is empty. Once filled, stays filled across runs. Good for set-and-forget single-image workflows.", v => { if (this.autoGenWidget) this.autoGenWidget.value = v; }, !!(this.autoGenWidget && this.autoGenWidget.value));
        togRow2.appendChild(this.autoGenCheck.wrap);
        this.rerollCheck = this._mkCheckbox("Re-roll on queue", "ON: server runs Ollama on EVERY queue iteration. Pair with an upstream image randomizer (FL Image Randomizer, etc) for overnight batches: each queue picks a new image, LLM writes prompts for it, sampler runs them. Vision (use anchor frame) recommended.", v => { if (this.rerollWidget) this.rerollWidget.value = v; }, !!(this.rerollWidget && this.rerollWidget.value));
        togRow2.appendChild(this.rerollCheck.wrap);
        this.unloadCheck = this._mkCheckbox("Unload after", "Evict model immediately", v => { if (this.ollamaUnloadWidget) this.ollamaUnloadWidget.value = v; }, !!(this.ollamaUnloadWidget && this.ollamaUnloadWidget.value));
        togRow2.appendChild(this.unloadCheck.wrap);
        box.appendChild(togRow2);

        const numRow = document.createElement("div"); numRow.style.cssText = "display: flex; gap: 6px; align-items: center; flex-wrap: wrap; margin-top: 4px; min-width: 0; max-width: 100%; box-sizing: border-box;";
        numRow.appendChild(this._mkLabel("Temp"));
        this.tempInput = document.createElement("input"); this.tempInput.type = "number"; this.tempInput.step = "0.05"; this.tempInput.min = "0"; this.tempInput.max = "2";
        this._styleInput(this.tempInput); this.tempInput.style.cssText += " flex: 1 1 60px; min-width: 0; max-width: 100px;";
        this.tempInput.value = String(this.ollamaTempWidget ? (this.ollamaTempWidget.value !== undefined ? this.ollamaTempWidget.value : 0.9) : 0.9);
        this.tempInput.oninput = () => { if (this.ollamaTempWidget) this.ollamaTempWidget.value = parseFloat(this.tempInput.value) || 0.9; };
        swallowKeys(this.tempInput); numRow.appendChild(this.tempInput);
        
        numRow.appendChild(this._mkLabel("ctx"));
        this.ctxInput = document.createElement("input"); this.ctxInput.type = "number"; this.ctxInput.step = "1024"; this.ctxInput.min = "2048";
        this._styleInput(this.ctxInput); this.ctxInput.style.cssText += " flex: 1 1 80px; min-width: 0; max-width: 120px;";
        this.ctxInput.value = String(this.ollamaCtxWidget ? (this.ollamaCtxWidget.value !== undefined ? this.ollamaCtxWidget.value : 8192) : 8192);
        this.ctxInput.oninput = () => { if (this.ollamaCtxWidget) this.ollamaCtxWidget.value = parseInt(this.ctxInput.value, 10) || 8192; };
        swallowKeys(this.ctxInput); numRow.appendChild(this.ctxInput);
        box.appendChild(numRow);

        const sendRow = document.createElement("div"); sendRow.style.cssText = "display: flex; gap: 6px; align-items: center; margin-top: 6px;";
        this.sendBtn = document.createElement("button"); this.sendBtn.textContent = "Generate prompt(s)"; this._styleButton(this.sendBtn);
        this.sendBtn.style.flex = "1 1 auto"; this.sendBtn.style.backgroundColor = COLOR_ACCENT; this.sendBtn.style.borderColor = COLOR_ACCENT; this.sendBtn.style.color = "#ffffff";
        this.sendBtn.onclick = () => this._sendOllamaRequest(); sendRow.appendChild(this.sendBtn); box.appendChild(sendRow);

        this.statusLine = document.createElement("div"); this.statusLine.style.cssText = "font-size: 11px; color: " + COLOR_TEXT_MUTED + "; min-height: 14px;";
        box.appendChild(this.statusLine);

        this._refreshOllamaModels({ silent: true });
        this._refreshPresetList();
    }

    async _refreshOllamaModels(opts) {
        opts = opts || {};
        if (!opts.silent) this.statusLine.textContent = "Listing Ollama models...";
        try {
            const resp = await api.fetchApi("/wan_looper_designer/models", {
                method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ollama_url: this.ollamaUrlInput.value }),
            });
            const data = await resp.json();
            if (!resp.ok) { this.statusLine.textContent = "Ollama: " + (data.error || resp.status); return; }
            const models = data.models || [];
            this.ollamaModelSelect.innerHTML = "";
            const blank = document.createElement("option"); blank.value = ""; blank.textContent = "(Off / No Model)"; this.ollamaModelSelect.appendChild(blank);
            for (const m of models) { const o = document.createElement("option"); o.value = m; o.textContent = m; this.ollamaModelSelect.appendChild(o); }
            const prior = this.ollamaModelWidget ? this.ollamaModelWidget.value : "";
            if (prior && models.includes(prior)) this.ollamaModelSelect.value = prior;
            if (!opts.silent) this.statusLine.textContent = `Found ${models.length} models.`;
        } catch (e) { this.statusLine.textContent = "Ollama refresh failed: " + e.message; }
    }

    async _refreshPresetList() {
        try {
            const resp = await api.fetchApi("/wan_looper_designer/system_prompts", { method: "GET" });
            if (!resp.ok) return;
            const data = await resp.json();
            const presets = data.presets || [];
            this.presetSelect.innerHTML = "";
            const blank = document.createElement("option"); blank.value = ""; blank.textContent = "(Default)"; this.presetSelect.appendChild(blank);
            for (const p of presets) { const o = document.createElement("option"); o.value = p.filename; o.textContent = p.title; o.title = p.description || ""; this.presetSelect.appendChild(o); }
            const sel = this.presetWidget ? this.presetWidget.value : "";
            if (sel && presets.some(p => p.filename === sel)) this.presetSelect.value = sel;
        } catch (e) {}
    }

    async _loadPresetIntoSystemPrompt() {
        const filename = this.presetSelect.value;
        if (this.presetWidget) this.presetWidget.value = filename;
        if (!filename) return;
        try {
            const resp = await api.fetchApi("/wan_looper_designer/system_prompts/" + encodeURIComponent(filename), { method: "GET" });
            if (!resp.ok) { this.statusLine.textContent = "Preset load failed: HTTP " + resp.status; return; }
            const data = await resp.json();
            this.ollamaSystemArea.value = data.content || "";
            if (this.ollamaSystemWidget) this.ollamaSystemWidget.value = this.ollamaSystemArea.value;
        } catch (e) { this.statusLine.textContent = "Preset load error: " + e.message; }
    }

    _buildOllamaUserPrompt() {
        const story = this.ollamaStoryArea.value.trim();
        const direction = this.ollamaDirectionArea.value.trim();
        const numSegs = this.segments.length;
        const enhance = !!(this.ollamaEnhanceWidget && this.ollamaEnhanceWidget.value);
        const perSegment = !!(this.ollamaPerSegmentWidget && this.ollamaPerSegmentWidget.value);

        let body = "";
        if (enhance) {
            body += "ENHANCE the following prompts in Wan 2.2 cinematic style. Keep intent.\n\n";
            body += `Base prompt: ${this.globalPromptArea.value.trim() || "(empty)"}\n\n`;
            body += "Segments:\n";
            this.segments.forEach((s, i) => { body += `  ${i + 1}. (${s.frames} frames) ${s.prompt || "(empty)"}\n`; });
            if (perSegment) { body += `\nOutput JSON with this exact shape:\n{ "base": "<enhanced base>", "segments": [{"idx": 1, "prompt": "<enhanced>"}, ...] }`; }
            else { body += `\nOutput a single rewritten base prompt only. No JSON, no preamble.`; }
        } else {
            body += `Story: ${story || "(unspecified)"}\n`;
            if (direction) body += `Direction: ${direction}\n`;
            body += `\nGenerate ${perSegment ? `${numSegs} per-segment prompts plus a base prompt` : "a single base prompt"} for a ${numSegs}-segment Wan 2.2 SVI chain.\n`;
            this.segments.forEach((s, i) => { body += `Segment ${i + 1}: ${s.frames} frames.\n`; });
            if (perSegment) { body += `\nOutput JSON with this exact shape:\n{ "base": "<global anchor description>", "segments": [{"idx": 1, "prompt": "<segment 1 action>"}, ...] }\nNo preamble.`; }
            else { body += `\nOutput a single base prompt. No JSON, no preamble.`; }
        }
        return body;
    }

    async _sendOllamaRequest() {
        const model = this.ollamaModelSelect.value;
        if (!model) { this.statusLine.textContent = "Pick an Ollama model first."; return; }
        const enhance = !!(this.ollamaEnhanceWidget && this.ollamaEnhanceWidget.value);
        const perSegment = !!(this.ollamaPerSegmentWidget && this.ollamaPerSegmentWidget.value);
        const useFrame = !!(this.ollamaUseFrameWidget && this.ollamaUseFrameWidget.value);
        const unload = !!(this.ollamaUnloadWidget && this.ollamaUnloadWidget.value);

        const userPrompt = this._buildOllamaUserPrompt();
        let systemPrompt = (this.ollamaSystemArea.value || "").trim();
        if (!systemPrompt) systemPrompt = enhance ? WAN_ENHANCE_SYSTEM_PROMPT : DEFAULT_SYSTEM_PROMPT;

        const payload = {
            ollama_url: this.ollamaUrlInput.value || "http://127.0.0.1:11434",
            model, system: systemPrompt, prompt: userPrompt,
            options: { temperature: parseFloat(this.tempInput.value) || 0.9, num_ctx: parseInt(this.ctxInput.value, 10) || 8192 },
        };
        if (unload) payload.keep_alive = 0;
        
        if (useFrame) { const frameB64 = await this._captureAnchorB64(); if (frameB64) payload.images = [frameB64]; }

        this.sendBtn.disabled = true;
        const prevText = this.sendBtn.textContent;
        const prevBg = this.sendBtn.style.backgroundColor; const prevBd = this.sendBtn.style.borderColor;
        const prevColor = this.sendBtn.style.color; const prevBoxShadow = this.sendBtn.style.boxShadow;
        const prevAnim = this.sendBtn.style.animation; const prevFontWeight = this.sendBtn.style.fontWeight;
        const prevTextShadow = this.sendBtn.style.textShadow;
        
        this.sendBtn.textContent = "Generating...";
        // Supercharged Amber/Yellow Solid color for generating state
        this.sendBtn.style.backgroundColor = "#eab308";
        this.sendBtn.style.borderColor = "#ca8a04";
        this.sendBtn.style.color = "#000000";
        this.sendBtn.style.fontWeight = "700";
        this.sendBtn.style.textShadow = "none";
        this.sendBtn.style.boxShadow = "0 0 12px rgba(234, 179, 8, 0.75)";
        if (!document.getElementById("wld-pulse-keyframes")) {
            const style = document.createElement("style"); style.id = "wld-pulse-keyframes";
            style.textContent = "@keyframes wld-pulse { 0%, 100% { box-shadow: 0 0 8px rgba(234, 179, 8, 0.5); } 50% { box-shadow: 0 0 20px rgba(234, 179, 8, 0.95); } }";
            document.head.appendChild(style);
        }
        this.sendBtn.style.animation = "wld-pulse 1.2s ease-in-out infinite";
        this.statusLine.textContent = `Asking ${model}...`;
        
        try {
            const resp = await api.fetchApi("/wan_looper_designer/generate", {
                method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
            });
            const data = await resp.json();
            if (!resp.ok) { this.statusLine.textContent = "Ollama error: " + (data.error || resp.status); return; }
            this._applyOllamaResponse((data.response || "").trim(), perSegment);
        } catch (e) {
            this.statusLine.textContent = "Ollama error: " + e.message;
        } finally {
            this.sendBtn.disabled = false; this.sendBtn.textContent = prevText;
            this.sendBtn.style.backgroundColor = prevBg; this.sendBtn.style.borderColor = prevBd;
            this.sendBtn.style.color = prevColor; this.sendBtn.style.boxShadow = prevBoxShadow;
            this.sendBtn.style.animation = prevAnim; this.sendBtn.style.fontWeight = prevFontWeight;
            this.sendBtn.style.textShadow = prevTextShadow;
        }
    }

    _applyOllamaResponse(text, perSegment) {
        if (perSegment) {
            const parsed = extractJsonFromResponse(text);
            if (!parsed || typeof parsed !== "object") {
                this.statusLine.textContent = "LLM non-JSON; treating as plain base prompt.";
                this.globalPromptArea.value = text;
                if (this.globalPromptWidget) this.globalPromptWidget.value = text;
                return;
            }
            if (typeof parsed.base === "string") {
                this.globalPromptArea.value = parsed.base;
                if (this.globalPromptWidget) this.globalPromptWidget.value = parsed.base;
            }
            const segs = Array.isArray(parsed.segments) ? parsed.segments : [];
            for (const s of segs) {
                if (!s || typeof s !== "object") continue;
                let idx = parseInt(s.idx, 10);
                if (!isFinite(idx)) continue;
                idx -= 1;
                if (idx >= 0 && idx < this.segments.length && typeof s.prompt === "string") {
                    this.segments[idx].prompt = s.prompt;
                }
            }
            this._saveSegments(); this._populateSidebar(); this._scheduleRender();
            this.statusLine.textContent = `Applied ${segs.length} per-segment prompts.`;
        } else {
            this.globalPromptArea.value = text;
            if (this.globalPromptWidget) this.globalPromptWidget.value = text;
            this.statusLine.textContent = "Base prompt updated.";
        }
    }

    async _captureAnchorB64() {
        const name = this._findUpstreamAnchorFilename();
        if (!name) return null;
        try {
            const resp = await fetch("/view?filename=" + encodeURIComponent(name) + "&type=input");
            if (!resp.ok) return null;
            const blob = await resp.blob();
            return await new Promise((resolve) => {
                const reader = new FileReader();
                reader.onloadend = () => {
                    const dataUrl = reader.result;
                    const comma = dataUrl.indexOf(",");
                    resolve(comma >= 0 ? dataUrl.slice(comma + 1) : null);
                };
                reader.readAsDataURL(blob);
            });
        } catch (e) { return null; }
    }

    _findUpstreamAnchorFilename() {
        try {
            const anchorInput = (this.node && this.node.inputs || []).find(i => i.name === "anchor_image");
            if (!anchorInput || anchorInput.link == null) return null;
            const graph = this.node.graph;
            if (!graph) return null;

            const visited = new Set();
            const queue = [anchorInput.link];
            const MAX_DEPTH = 8;
            let depth = 0;
            const imageWidgetNames = ["image", "filename", "file", "image_path", "path"];

            while (queue.length > 0 && depth < MAX_DEPTH) {
                const linkId = queue.shift();
                if (linkId == null || visited.has(linkId)) continue;
                visited.add(linkId);
                const link = graph.links && graph.links[linkId];
                if (!link) continue;
                const srcNode = graph.getNodeById && graph.getNodeById(link.origin_id);
                if (!srcNode) continue;
                for (const wname of imageWidgetNames) {
                    const w = srcNode.widgets && srcNode.widgets.find(x => x.name === wname);
                    if (w && typeof w.value === "string" && w.value.length > 0 && /\.(png|jpe?g|webp|bmp|gif|tiff?)$/i.test(w.value)) {
                        return w.value;
                    }
                }
                for (const ip of (srcNode.inputs || [])) {
                    if (ip.link != null && (ip.type === "IMAGE" || ip.type === "*" || !ip.type)) {
                        queue.push(ip.link);
                    }
                }
                depth++;
            }
        } catch (e) { }
        return null;
    }

    _renderSidebarSegList() {
        if (!this.sidebarSegList) return;
        this.sidebarSegList.innerHTML = "";
        if (!this.segments || this.segments.length === 0) {
            const empty = document.createElement("div");
            empty.textContent = "No segments yet. Use '+ Add Segment'.";
            empty.style.cssText = `font-size: 10px; color: ${COLOR_TEXT_MUTED}; padding: 6px;`;
            this.sidebarSegList.appendChild(empty);
            return;
        }
        const activeSeg = this._activeProgressSeg;
        const activePhase = this._activeProgressPhase;
        const isLoPhase = (activePhase === "low");
        for (let i = 0; i < this.segments.length; i++) {
            const seg = this.segments[i];
            const isSelected = i === this.selectedIdx;
            const isActive = activeSeg != null && activeSeg === i;
            const borderColor = isActive ? "#f59e0b" : isSelected ? COLOR_ACCENT : COLOR_BORDER_IN;
            const bg = isActive ? (isLoPhase ? "rgba(245, 158, 11, 0.42)" : "rgba(245, 158, 11, 0.16)") : isSelected ? COLOR_BG_INPUT : COLOR_BG_DEEP;
            const card = document.createElement("div");
            card.style.cssText = `display: flex; flex-direction: column; gap: 2px; padding: 5px 7px; background: ${bg}; border: 1px solid ${borderColor}; border-radius: 4px; cursor: pointer; transition: background 0.15s, border-color 0.15s;`;
            const head = document.createElement("div");
            head.style.cssText = `display: flex; justify-content: space-between; font-size: 10px; font-weight: 600; color: ${COLOR_TEXT};`;
            const left = document.createElement("span");
            const samplingLabel = isActive ? (isLoPhase ? "  (sampling LO)" : activePhase === "high" ? "  (sampling HI)" : "  (sampling)") : "";
            left.textContent = `Segment ${i + 1}` + samplingLabel;
            const right = document.createElement("span");
            right.style.cssText = `color: ${COLOR_TEXT_MUTED}; font-weight: 400;`;
            right.textContent = `${seg.frames}f`;
            head.appendChild(left); head.appendChild(right);
            card.appendChild(head);

            const promptLine = document.createElement("div");
            const text = (seg.prompt || "(no prompt -- uses fallback)").replace(/\s+/g, " ").trim();
            const truncated = text.length > 80 ? text.slice(0, 80) + "..." : text;
            promptLine.textContent = truncated;
            promptLine.style.cssText = `font-size: 9px; color: ${COLOR_TEXT_MUTED}; line-height: 1.3;`;
            card.appendChild(promptLine);

            card.onclick = () => { this.selectedIdx = i; this._populateSidebar(); this._scheduleRender(); };
            this.sidebarSegList.appendChild(card);
        }
    }

    _populateSidebar() {
        this._renderSidebarSegList();
        if (this.selectedIdx < 0 || this.selectedIdx >= this.segments.length) {
            this.sidebarDetailWrap.style.display = "none";
            return;
        }
        this.sidebarDetailWrap.style.display = "flex";
        const seg = this.segments[this.selectedIdx];
        this.detailHeader.textContent = `Segment Settings #${this.selectedIdx + 1}`;
        this.sbPromptArea.value = seg.prompt;
        this.sbFramesInput.value = String(seg.frames);
        this.sbAnchorSelect.value = seg.anchor_mode;
        this.sbPromoteCheck.checked = !!seg.promote_anchor;
        this.sbSeedInput.value = seg.seed_override == null ? "" : String(seg.seed_override);
    }

    _scheduleRender() {
        if (this._renderQueued) return;
        this._renderQueued = true;
        requestAnimationFrame(() => {
            this._renderQueued = false;
            this._render();
            if (this._activeProgressSeg != null) {
                this._scheduleRender();
            }
        });
    }

    _render() {
        if (!this.segGridContainer) return;

        if (this.segmentCountLabel) {
            const totalFrames = this.segments.reduce((a, s) => a + s.frames, 0);
            this.segmentCountLabel.textContent = `${this.segments.length} Segments | ${totalFrames} Total Frames`;
        }

        const grid = this.segGridContainer;
        grid.innerHTML = "";

        const activeSeg = this._activeProgressSeg;
        const activePhase = this._activeProgressPhase;
        const isLoPhase = (activePhase === "low");
        const t = (performance.now() % 1200) / 1200;
        const pulse = 0.55 + 0.45 * Math.sin(t * Math.PI * 2);

        for (let i = 0; i < this.segments.length; i++) {
            const seg = this.segments[i];
            const isActive = (activeSeg === i);

            const btn = document.createElement("button");
            let borderColor = COLOR_BORDER_IN;
            let bg = COLOR_BG_INPUT;
            if (isActive) {
                borderColor = "#f59e0b";
                const fillAlpha = isLoPhase
                    ? (0.35 + 0.20 * pulse).toFixed(3)
                    : (0.10 + 0.10 * pulse).toFixed(3);
                bg = `rgba(245, 158, 11, ${fillAlpha})`;
            }
            btn.style.cssText = `
                display: inline-flex; align-items: center; justify-content: center;
                gap: 8px;
                padding: 8px 12px;
                background: ${bg};
                border: 1px solid ${borderColor};
                border-radius: 4px;
                cursor: pointer;
                font-family: inherit; font-size: 11px; font-weight: 600;
                color: ${COLOR_TEXT};
                transition: background 0.15s, border-color 0.15s;
                white-space: nowrap;
                flex: 1 1 0; min-width: 80px;
            `;

            const labelSpan = document.createElement("span");
            const phaseSuffix = isActive
                ? (isLoPhase ? " LO" : activePhase === "high" ? " HI" : activePhase === "done" ? " OK" : "")
                : "";
            labelSpan.textContent = `${i + 1}: ${seg.frames}f${phaseSuffix}`;
            btn.appendChild(labelSpan);

            const badges = [];
            if (seg.prompt && seg.prompt.length > 0) badges.push(["P", BADGE_PROMPT]);
            if (seg.anchor_mode !== "global") badges.push(["K", BADGE_ANCHOR]);
            if (seg.promote_anchor) badges.push(["*", BADGE_PROMOTE]);
            for (const [ch, color] of badges) {
                const b = document.createElement("span");
                b.textContent = ch;
                b.style.cssText = `
                    display: inline-block; background: ${color}; color: #000;
                    padding: 0 4px; border-radius: 2px;
                    font-size: 9px; font-weight: 700;
                `;
                btn.appendChild(b);
            }

            btn.onclick = () => {
                this.selectedIdx = i;
                this._populateSidebar();
                this._scheduleRender();
            };
            btn.oncontextmenu = (e) => this._onContextMenu(e, i);
            btn.onmouseover = () => {
                if (!isActive) btn.style.background = COLOR_BG_DEEP;
            };
            btn.onmouseout = () => {
                if (!isActive) btn.style.background = COLOR_BG_INPUT;
            };

            grid.appendChild(btn);
        }
    }

    _onContextMenu(e, hitIdx) {
        e.preventDefault();
        this._lastMenuX = e.clientX; this._lastMenuY = e.clientY;
        if (hitIdx >= 0) this._showSegmentMenu(hitIdx, e.clientX, e.clientY);
        else this._showEmptyMenu(e.clientX, e.clientY);
    }

    _showSegmentMenu(idx, x, y) {
        const items = [
            { label: "Duplicate", fn: () => this._duplicateSegment(idx) },
            { label: "Split at midpoint", fn: () => this._splitSegment(idx) },
            { label: "Delete", fn: () => this._deleteSegment(idx) },
            { divider: true },
            { label: "Clear prompt", fn: () => { this.segments[idx].prompt = ""; this._saveSegments(); if (this.selectedIdx === idx) this._populateSidebar(); this._scheduleRender(); }},
            { label: this.segments[idx].promote_anchor ? "Unset promote anchor" : "Set promote anchor", fn: () => { this.segments[idx].promote_anchor = !this.segments[idx].promote_anchor; this._saveSegments(); if (this.selectedIdx === idx) this._populateSidebar(); this._scheduleRender(); }},
            { divider: true },
            { label: "Anchor: global", fn: () => this._setAnchorMode(idx, "global") },
            { label: "Anchor: previous last frame", fn: () => this._setAnchorMode(idx, "previous_last_frame") },
            { label: "Anchor: custom override", fn: () => this._setAnchorMode(idx, "custom_override") },
        ];
        this._renderPopupMenu(x, y, items);
    }

    _showEmptyMenu(x, y) {
        const items = [
            { label: "+ Add segment", fn: () => this._addSegment() },
            { label: "+ Add 5 segments", fn: () => { for (let i = 0; i < 5; i++) this._addSegment(); }},
        ];
        this._renderPopupMenu(x, y, items);
    }

    _renderPopupMenu(x, y, items) {
        if (this._activeMenu) { this._activeMenu.remove(); this._activeMenu = null; }
        const menu = document.createElement("div");
        menu.style.cssText = `position: fixed; top: ${y}px; left: ${x}px; background: ${COLOR_BG_PANEL}; border: 1px solid ${COLOR_BORDER}; border-radius: 4px; padding: 4px; font-family: ui-sans-serif, system-ui, sans-serif; font-size: 11px; color: ${COLOR_TEXT}; z-index: 99999; box-shadow: 0 4px 12px rgba(0,0,0,0.5); min-width: 200px;`;
        for (const item of items) {
            if (item.divider) { const div = document.createElement("div"); div.style.cssText = `border-top: 1px solid ${COLOR_DIVIDER}; margin: 4px 0;`; menu.appendChild(div); continue; }
            const row = document.createElement("div"); row.textContent = item.label; row.style.cssText = "padding: 6px 8px; cursor: pointer; border-radius: 2px;";
            row.onmouseover = () => { row.style.background = COLOR_BG_INPUT; }; row.onmouseout  = () => { row.style.background = "transparent"; };
            row.onclick = () => { item.fn(); menu.remove(); this._activeMenu = null; }; menu.appendChild(row);
        }
        document.body.appendChild(menu); this._activeMenu = menu;
        const closer = (ev) => { if (menu.contains(ev.target)) return; menu.remove(); this._activeMenu = null; document.removeEventListener("mousedown", closer, true); };
        setTimeout(() => document.addEventListener("mousedown", closer, true), 0);
    }

    _addSegment() {
        const last = this.segments[this.segments.length - 1];
        this.segments.push(defaultSegment(last ? last.frames : 81));
        this.selectedIdx = this.segments.length - 1;
        this._saveSegments(); this._populateSidebar(); this._scheduleRender();
    }

    _duplicateSegment(idx) {
        if (idx < 0 || idx >= this.segments.length) return;
        const clone = JSON.parse(JSON.stringify(this.segments[idx]));
        this.segments.splice(idx + 1, 0, clone); this.selectedIdx = idx + 1;
        this._saveSegments(); this._populateSidebar(); this._scheduleRender();
    }

    _splitSegment(idx) {
        if (idx < 0 || idx >= this.segments.length) return;
        const seg = this.segments[idx];
        if (seg.frames < 18) return;
        const halfFrames = snapFramesToWanGrid(Math.floor(seg.frames / 2));
        const remaining = seg.frames - halfFrames + 1;
        seg.frames = halfFrames;
        const right = JSON.parse(JSON.stringify(seg));
        right.frames = snapFramesToWanGrid(Math.max(9, remaining));
        right.promote_anchor = false;
        this.segments.splice(idx + 1, 0, right);
        this._saveSegments(); this._scheduleRender();
    }

    _deleteSegment(idx) {
        if (this.segments.length <= 1) return;
        this.segments.splice(idx, 1);
        if (this.selectedIdx >= this.segments.length) this.selectedIdx = this.segments.length - 1;
        this._saveSegments(); this._populateSidebar(); this._scheduleRender();
    }

    _setAnchorMode(idx, mode) {
        if (idx < 0 || idx >= this.segments.length) return;
        this.segments[idx].anchor_mode = mode;
        this._saveSegments(); if (this.selectedIdx === idx) this._populateSidebar(); this._scheduleRender();
    }

    _installVisibilityWatchdog() {
        let ticks = 0;
        const tick = () => {
            for (const name of HIDDEN_WIDGETS) {
                const w = findWidget(this.node, name);
                if (w && w.type !== "WANLOOPER_HIDDEN") hideWidget(w);
            }
            ticks++;
            if (ticks < 60) requestAnimationFrame(tick);
        };
        tick();

        try {
            const ro = new ResizeObserver(() => {
                for (const name of HIDDEN_WIDGETS) {
                    const w = findWidget(this.node, name);
                    if (w && w.type !== "WANLOOPER_HIDDEN") hideWidget(w);
                }
                this._scheduleRender();
            });
            ro.observe(this.mount);
        } catch (e) { }
    }

    _updateLivePreview(src) {
        if (!this.previewContainer) return;
        if (this.previewImage.src !== src) {
            this.previewImage.src = src;
        }
        if (this.previewContainer.style.display === "none") {
            this.previewContainer.style.display = "block";
        }
    }

    _clearNodePreview() {
        try {
            if (this.node) {
                this.node.imgs = null;
                this.node.images = null;
                this.node.imageIndex = null;
                if (this.node.preview) this.node.preview = null;
            }
            
            if (this.previewContainer) {
                this.previewContainer.style.display = "none";
                this.previewImage.src = "";
            }

            if (this.node && typeof this.node.setSize === "function") {
                this.node.setSize([this.node.size[0], this.node.computeSize()[1]]);
                if (this.node.graph && typeof this.node.graph.setDirtyCanvas === "function") {
                    this.node.graph.setDirtyCanvas(true, true);
                }
            }
        } catch (e) { }
    }
}

// =========================================================================
// Extension registration
// =========================================================================

app.registerExtension({
    name: "WanLooperDesigner.Editor",
    async beforeRegisterNodeDef(nodeType, nodeData) {
        if (nodeData.name !== "WanLooperDesigner") return;

        const onNodeCreated = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function () {
            const r = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;

            try {
                for (const name of HIDDEN_WIDGETS) {
                    hideWidget(findWidget(this, name));
                }

                const mount = document.createElement("div");
                mount.style.cssText = "width: 100%; box-sizing: border-box;";
                
                const getEditorHeight = () => {
                    const ed = mount.firstElementChild;
                    const h = ed ? ed.scrollHeight : mount.scrollHeight;
                    if (h > 0) return h;
                    return 600; 
                };
                
                const editorWidget = this.addDOMWidget("wan_looper_editor", "div", mount, {
                    serialize: false,
                    hideOnZoom: false,
                    getHeight: getEditorHeight,
                });
                
                if (editorWidget) {
                    editorWidget.computeSize = function (width) {
                        return [width, getEditorHeight()];
                    };
                }
                
                if (typeof ResizeObserver !== "undefined") {
                    let pending = false;
                    const ro = new ResizeObserver(() => {
                        if (pending) return;
                        pending = true;
                        requestAnimationFrame(() => {
                            pending = false;
                            try {
                                if (typeof this.setSize === "function" && this.size) {
                                    this.setSize([this.size[0], this.computeSize()[1]]);
                                }
                                if (this.graph && typeof this.graph.setDirtyCanvas === "function") {
                                    this.graph.setDirtyCanvas(true, true);
                                }
                            } catch (e) { }
                        });
                    });
                    ro.observe(mount);
                }

                this._wanLooperEditor = new LooperEditor(this, mount);

                requestAnimationFrame(() => {
                    try {
                        if (typeof this.computeSize === "function" && this.size) {
                            this.size[1] = this.computeSize()[1];
                        }
                        if (this.graph && typeof this.graph.setDirtyCanvas === "function") {
                            this.graph.setDirtyCanvas(true, true);
                        }
                    } catch (e) { }
                });

                const origOnDrawBackground = this.onDrawBackground;
                this.onDrawBackground = function(ctx) {
                    let stoleImage = false;
                    if (this.imgs && this.imgs.length > 0 && this._wanLooperEditor) {
                        const img = this.imgs[0];
                        if (img) {
                            let src = null;
                            if (typeof img === "string") src = img;
                            else if (img.src) src = img.src;
                            else if (img instanceof HTMLCanvasElement) src = img.toDataURL();
                            else if (img.currentSrc) src = img.currentSrc;
                            
                            if (src) {
                                this._wanLooperEditor._updateLivePreview(src);
                                stoleImage = true;
                            }
                        }
                    }
                    
                    if (stoleImage) {
                        const stash = this.imgs;
                        const stashAnim = this.animatedImages;
                        this.imgs = null;
                        this.animatedImages = false;
                        
                        if (origOnDrawBackground) origOnDrawBackground.apply(this, arguments);
                        
                        this.imgs = stash;
                        this.animatedImages = stashAnim;
                    } else {
                        if (origOnDrawBackground) origOnDrawBackground.apply(this, arguments);
                    }
                };

                const origComputeSize = this.computeSize;
                this.computeSize = function(out) {
                    let stash = null;
                    let stashAnim = false;
                    if (this._wanLooperEditor && this.imgs) {
                        stash = this.imgs;
                        stashAnim = this.animatedImages;
                        this.imgs = null;
                        this.animatedImages = false;
                    }

                    let size;
                    if (origComputeSize) {
                        size = origComputeSize.apply(this, arguments);
                    } else if (typeof LiteGraph !== "undefined") {
                        size = LiteGraph.LGraphNode.prototype.computeSize.call(this, out);
                    } else {
                        size = [this.size[0], this.size[1]];
                    }

                    if (stash) {
                        this.imgs = stash;
                        this.animatedImages = stashAnim;
                    }
                    return size;
                };

            } catch (err) {
                console.error("[WanLooperDesigner] Crash during Editor setup:", err);
            }

            if (!app._wanLooperExecutedListenerInstalled) {
                api.addEventListener("executed", (e) => {
                    const detail = e.detail || {};
                    const nodeId = String(detail.node !== undefined ? detail.node : (detail.display_node !== undefined ? detail.display_node : ""));
                    if (!nodeId) return;
                    const nodes = app.graph && app.graph._nodes ? app.graph._nodes : [];
                    for (const n of nodes) {
                        if (n.type !== "WanLooperDesigner") continue;
                        if (String(n.id) !== nodeId) continue;
                        const ed = n._wanLooperEditor;
                        if (!ed) continue;
                        setTimeout(() => {
                            try { ed._clearNodePreview(); }
                            catch (err) {}
                        }, 800);
                    }
                });
                app._wanLooperExecutedListenerInstalled = true;
            }
            
            if (!app._wanLooperProgressListenerInstalled) {
                api.addEventListener("wld_segment_progress", (e) => {
                    const d = e.detail || {};
                    const nodeId = String(d.node_id || "");
                    if (!nodeId) return;
                    const nodes = app.graph?._nodes || [];
                    for (const n of nodes) {
                        if (n.type !== "WanLooperDesigner") continue;
                        if (String(n.id) !== nodeId) continue;
                        const ed = n._wanLooperEditor;
                        if (!ed) continue;
                        const phase = d.phase || "";
                        if (phase === "all_done") {
                            ed._activeProgressSeg = null;
                            ed._activeProgressPhase = null;
                            if (ed.statusLine) ed.statusLine.textContent = "Run complete.";
                        } else {
                            ed._activeProgressSeg = Number(d.seg_idx);
                            ed._activeProgressPhase = phase;
                            const human = phase === "high" ? "high-noise pass"
                                       : phase === "low"  ? "low-noise pass"
                                       : phase === "decode" ? "decoding image"
                                       : phase === "done" ? "complete"
                                       : phase;
                            if (ed.statusLine) {
                                ed.statusLine.textContent =
                                    `Segment ${Number(d.seg_idx) + 1} of ${Number(d.total)} -- ${human}`;
                            }
                        }
                        try { ed._renderSidebarSegList(); } catch (err) {}
                        try { ed._scheduleRender(); } catch (err) {}
                    }
                });
                app._wanLooperProgressListenerInstalled = true;
            }

            if (!app._wanLooperOllamaAppliedListenerInstalled) {
                api.addEventListener("wld_ollama_applied", (e) => {
                    const d = e.detail || {};
                    const nodeId = String(d.node_id || "");
                    if (!nodeId) return;
                    const nodes = app.graph?._nodes || [];
                    for (const n of nodes) {
                        if (n.type !== "WanLooperDesigner") continue;
                        if (String(n.id) !== nodeId) continue;
                        const ed = n._wanLooperEditor;
                        if (!ed) continue;
                        try {
                            if (typeof d.base === "string") {
                                ed.globalPromptArea.value = d.base;
                                if (ed.globalPromptWidget) ed.globalPromptWidget.value = d.base;
                            }
                            if (Array.isArray(d.segments)) {
                                for (let i = 0; i < d.segments.length && i < ed.segments.length; i++) {
                                    const s = d.segments[i];
                                    if (s && typeof s.prompt === "string") {
                                        ed.segments[i].prompt = s.prompt;
                                    }
                                }
                                ed._saveSegments();
                                ed._populateSidebar();
                                ed._scheduleRender();
                            }
                            if (ed.statusLine) {
                                ed.statusLine.textContent =
                                    "Server-side Ollama applied prompts for this run.";
                            }
                        } catch (err) {}
                    }
                });
                app._wanLooperOllamaAppliedListenerInstalled = true;
            }

            return r;
        };

        const onResize = nodeType.prototype.onResize;
        nodeType.prototype.onResize = function (size) {
            if (onResize) onResize.apply(this, arguments);
            if (this._wanLooperEditor && typeof this._wanLooperEditor._scheduleRender === "function") {
                this._wanLooperEditor._scheduleRender();
            }
        };
        
        const onConnectionsChange = nodeType.prototype.onConnectionsChange;
        nodeType.prototype.onConnectionsChange = function (type, slotIndex, connected, linkInfo, ioSlot) {
            if (onConnectionsChange) onConnectionsChange.apply(this, arguments);
            if (!this._wanLooperEditor || !ioSlot) return;
            try {
                if (ioSlot.name === "memory_images") {
                    this._wanLooperEditor._refreshAdvancedVisibility();
                }
            } catch (e) { }
        };
    },
});
