"""ComfyUI-WanLooperDesigner v1.2.50: Multi-segment Wan 2.2 I2V looper with Designer-style GUI."""

from .wan_looper_designer import (
    NODE_CLASS_MAPPINGS,
    NODE_DISPLAY_NAME_MAPPINGS,
    WEB_DIRECTORY,
)

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS", "WEB_DIRECTORY"]
