import os
import gc
import json
import math
import inspect
import logging
import tempfile
import shutil
import textwrap
import pathlib
from typing import Optional, List, Dict, Any, Tuple

import torch
import torch.nn.functional as F

import comfy.utils
import comfy.model_management as mm
from comfy.utils import common_upscale

try:
    import folder_paths
except ImportError:
    folder_paths = None

log = logging.getLogger("WanLooperDesigner")

# Device handles -- resolved at module load
_DEVICE = mm.get_torch_device()
_OFFLOAD = mm.unet_offload_device()


# ===========================================================================
# Vendored helpers from ComfyUI-WanUltimateI2V v3.3
# ===========================================================================

def _unwrap_vae_result(result):
    if isinstance(result, (list, tuple)):
        if len(result) == 0:
            raise RuntimeError(
                "[WanLooperDesigner] VAE call returned an empty list. "
                "This is unexpected; check WanVideoWrapper version."
            )
        return result[0]
    return result


_KJ_ENCODE_INSTANCE = None
_KJ_ENCODE_TRIED = False


def _resolve_kj_encode():
    """Resolve Kijai's WanVideoEncode node for delegated image->latent encoding.

    Delegating to the actual node guarantees the anchor latent is
    byte-identical to what a hand-built subgraph workflow produces
    (same dtype handling, same [0,1] -> [-1,1] conversion, same VAE
    call signature for the installed wrapper revision). The internal
    fallback below is only used when the class cannot be imported.
    """
    global _KJ_ENCODE_INSTANCE, _KJ_ENCODE_TRIED
    if _KJ_ENCODE_TRIED:
        return _KJ_ENCODE_INSTANCE
    _KJ_ENCODE_TRIED = True
    cls = _try_import_wrapper_class("WanVideoEncode")
    if cls is not None:
        _KJ_ENCODE_INSTANCE = cls()
        log.info("[WanLooperDesigner] Image encode delegated to Kijai's WanVideoEncode node.")
    else:
        log.warning(
            "[WanLooperDesigner] WanVideoEncode not importable from the installed "
            "WanVideoWrapper; using internal VAE encode fallback. Latents may not be "
            "byte-identical to a hand-built workflow."
        )
    return _KJ_ENCODE_INSTANCE


def _wrapper_vae_encode(vae, images_bhwc):
    # NOTE: call sites pass images normalized to [-1, 1] (via
    # _resize_and_normalize). Kijai's WanVideoEncode expects [0, 1]
    # and applies its own *2-1 internally, so we convert back before
    # delegating. The round trip is lossless in float32.
    enc = _resolve_kj_encode()
    if enc is not None:
        img01 = (images_bhwc.to(torch.float32) + 1.0) * 0.5
        if img01.shape[-1] == 4:
            img01 = img01[..., :3]
        result = _call_wrapper(
            enc,
            ("encode", "process"),
            vae=vae,
            image=img01,
            enable_vae_tiling=False,
            tile_x=272, tile_y=272, tile_stride_x=144, tile_stride_y=128,
            noise_aug_strength=0.0,
            latent_strength=1.0,
            mask=None,
        )
        lat = result[0] if isinstance(result, tuple) else result
        if isinstance(lat, dict):
            lat = lat.get("samples", lat)
        while torch.is_tensor(lat) and lat.dim() > 4:
            lat = lat.squeeze(0)
        return lat.to(_DEVICE)

    img = images_bhwc.permute(0, 3, 1, 2)   # (T, C, H, W)
    img = img.permute(1, 0, 2, 3)           # (C, T, H, W)
    img = img.to(_DEVICE, dtype=vae.dtype)

    vae.to(_DEVICE)
    result = vae.encode([img], _DEVICE)
    vae.to(_OFFLOAD)

    result = _unwrap_vae_result(result)
    while result.dim() > 4:
        result = result.squeeze(0)
    return result


def _wrapper_vae_encode_batch(vae, images_bhwc):
    B, H, W, C = images_bhwc.shape
    if C == 4:
        images_bhwc = images_bhwc[..., :3]

    enc = _resolve_kj_encode()
    if enc is not None:
        # Encode each memory frame independently (T=1 each), exactly as a
        # subgraph would, then concat along the latent T axis.
        latents = []
        for i in range(B):
            norm = images_bhwc[i:i + 1].to(torch.float32) * 2.0 - 1.0
            latents.append(_wrapper_vae_encode(vae, norm))
        return torch.cat(latents, dim=1)

    images_norm = images_bhwc.to(_DEVICE, dtype=vae.dtype) * 2.0 - 1.0

    vae.to(_DEVICE)
    latents = []
    for i in range(B):
        img = images_norm[i].permute(2, 0, 1).unsqueeze(1)   # (C, 1, H, W)
        lat = vae.encode([img], _DEVICE)
        lat = _unwrap_vae_result(lat)
        while lat.dim() > 4:
            lat = lat.squeeze(0)
        latents.append(lat)
    vae.to(_OFFLOAD)
    return torch.cat(latents, dim=1)


def _wrapper_vae_decode(vae, latent_samples):
    samples = latent_samples
    if samples.dim() == 5:
        samples = samples[0]
    samples = samples.to(_DEVICE, dtype=vae.dtype)

    lat_T = samples.shape[1] if samples.dim() >= 4 else 1
    lat_H = samples.shape[2] if samples.dim() >= 4 else 1
    lat_W = samples.shape[3] if samples.dim() >= 4 else 1
    expected_T = (lat_T - 1) * 4 + 1 if lat_T > 1 else 1
    spatial_stride = getattr(vae, "upsampling_factor", 8)
    expected_H = lat_H * spatial_stride
    expected_W = lat_W * spatial_stride

    vae.to(_DEVICE)
    out = vae.decode([samples], _DEVICE)
    vae.to(_OFFLOAD)

    out = _unwrap_vae_result(out)
    raw_shape = tuple(out.shape)

    while out.dim() > 4:
        out = out.squeeze(0)
    if out.dim() != 4:
        log.warning(
            f"[WanLooperDesigner] VAE decode produced unexpected dim "
            f"after squeeze: shape={tuple(out.shape)} (raw={raw_shape}). "
            f"Returning as-is; downstream may be garbled."
        )
        return out.clamp(0.0, 1.0).to(torch.float32).cpu()

    cand_channel_dims = [i for i, s in enumerate(out.shape) if s in (3, 4)]
    chosen_c = None
    if len(cand_channel_dims) == 1:
        chosen_c = cand_channel_dims[0]
    elif len(cand_channel_dims) > 1:
        for i in cand_channel_dims:
            if (out.shape[i] != expected_T
                    and out.shape[i] != expected_H
                    and out.shape[i] != expected_W):
                chosen_c = i
                break
        if chosen_c is None:
            chosen_c = cand_channel_dims[-1]

    if chosen_c is None:
        log.warning(
            f"[WanLooperDesigner] VAE decode: no dim of size 3 or 4 found "
            f"in shape {tuple(out.shape)}. Falling back to legacy permute."
        )
        out = out.permute(0, 2, 3, 1)
    elif chosen_c != out.dim() - 1:
        dims = list(range(out.dim()))
        dims.remove(chosen_c)
        dims.append(chosen_c)
        out = out.permute(*dims).contiguous()

    t_dim = None
    for i in range(3):
        if out.shape[i] == expected_T:
            t_dim = i
            break

    if t_dim is None:
        log.debug(
            f"[WanLooperDesigner] VAE decode: could not pin T-dim by value "
            f"(expected {expected_T}, shape after channel-move "
            f"{tuple(out.shape)}). Assuming dim 0 is T."
        )
    elif t_dim != 0:
        dims = list(range(out.dim()))
        dims.remove(t_dim)
        dims.insert(0, t_dim)
        out = out.permute(*dims).contiguous()

    if out.shape[1] != expected_H and out.shape[2] == expected_H:
        out = out.permute(0, 2, 1, 3).contiguous()

    sample_min = float(out.min())
    if sample_min < -0.05:
        sample_max = float(out.max())
        out = (out + 1.0) * 0.5

    out = out.clamp(0.0, 1.0)
    if out.dtype != torch.float32:
        out = out.to(torch.float32)
    return out.cpu()


def _resize_only(img, width, height, mode="crop"):
    img3 = img[..., :3].movedim(-1, 1)
    if mode == "stretch":
        out = common_upscale(img3, width, height, "bilinear", "disabled")
    elif mode == "pad":
        _, _, h_in, w_in = img3.shape
        scale = min(width / max(w_in, 1), height / max(h_in, 1))
        new_w = max(1, int(round(w_in * scale)))
        new_h = max(1, int(round(h_in * scale)))
        resized = common_upscale(img3, new_w, new_h, "bilinear", "disabled")
        canvas = torch.zeros(
            resized.shape[0], resized.shape[1], height, width,
            dtype=resized.dtype, device=resized.device,
        )
        pad_x = (width - new_w) // 2
        pad_y = (height - new_h) // 2
        canvas[:, :, pad_y:pad_y + new_h, pad_x:pad_x + new_w] = resized
        out = canvas
    else:
        out = common_upscale(img3, width, height, "bilinear", "center")
    return out.movedim(1, -1)


def _resize_and_normalize(img, width, height, mode="crop"):
    return _resize_only(img, width, height, mode) * 2 - 1


def _calculate_aligned_position(ratio, total_frames):
    desired_idx = int(total_frames * ratio)
    latent_idx = desired_idx // 4
    aligned_idx = latent_idx * 4
    return max(0, min(aligned_idx, total_frames - 1))


def _slice_video(video_tensor: Optional[torch.Tensor], start_idx: int, length: int) -> Optional[torch.Tensor]:
    """Helper to cleanly extract a frame chunk from a global pose/face driving video."""
    if video_tensor is None:
        return None
    total = video_tensor.shape[0]
    if start_idx >= total:
        start_idx = max(0, total - 1)
    
    end_idx = start_idx + length
    sliced = video_tensor[start_idx:end_idx]
    
    # If the driving video runs out of frames before the segment finishes, clamp and repeat the last frame
    if sliced.shape[0] < length:
        pad_len = length - sliced.shape[0]
        padding = sliced[-1:].repeat(pad_len, 1, 1, 1)
        sliced = torch.cat([sliced, padding], dim=0)
    return sliced


def _build_embeds_via_svipro_node(
    svipro_cls,
    add_story_mem_cls,
    vae,
    anchor_latent,
    seg_memory_images_01,
    prev_seg_latent,
    seg_length,
    motion_latent_count,
    rope_negative_offset,
    rope_negative_offset_frames,
    augment_empty_frames: float = 0.0,
):
    anchor_latent_dev = anchor_latent.to(_DEVICE).clone() if anchor_latent is not None else None
    prev_seg_latent_dev = prev_seg_latent.to(_DEVICE).clone() if prev_seg_latent is not None else None

    anchor_samples = {"samples": anchor_latent_dev.unsqueeze(0)}

    prev_samples = None
    if prev_seg_latent_dev is not None:
        prev_samples = {"samples": prev_seg_latent_dev.unsqueeze(0)}

    embeds_node = svipro_cls()
    svipro_method = getattr(svipro_cls, "FUNCTION", "process")

    # Honesty check: Kijai's current WanVideoSVIProEmbeds (mirroring the
    # SVI 2.2 Pro svi_wan22 reference: y = concat([anchor_latent,
    # motion_latent, zero_padding])) takes NO augment_empty_frames
    # parameter -- padding is pure zero-valued latents by design.
    # _call_wrapper filters unknown kwargs, so without this check a
    # nonzero widget value would be silently ignored.
    if float(augment_empty_frames) > 0.0:
        _m = getattr(embeds_node, svipro_method, None) or getattr(embeds_node, "add", None)
        if _m is not None and "augment_empty_frames" not in _accepted_kwargs(_m):
            log.warning(
                "[WanLooperDesigner] augment_empty_frames=%.2f is set, but the "
                "installed WanVideoSVIProEmbeds does not accept it. Value ignored; "
                "padding stays pure zero latents (SVI 2.2 Pro spec).",
                float(augment_empty_frames),
            )

    result = _call_wrapper(
        embeds_node,
        (svipro_method, "process", "encode", "get_embeds"),
        anchor_samples=anchor_samples,
        num_frames=seg_length,
        prev_samples=prev_samples,
        motion_latent_count=motion_latent_count,
        augment_empty_frames=float(augment_empty_frames),
    )
    embeds = result[0] if isinstance(result, tuple) else result

    if seg_memory_images_01 is not None and add_story_mem_cls is not None:
        add_mem_node = add_story_mem_cls()
        add_mem_method = getattr(add_story_mem_cls, "FUNCTION", "add")
        result = _call_wrapper(
            add_mem_node,
            (add_mem_method, "add", "process"),
            vae=vae,
            embeds=embeds,
            memory_images=seg_memory_images_01,
            rope_negative_offset=rope_negative_offset,
            rope_negative_offset_frames=rope_negative_offset_frames,
        )
        embeds = result[0] if isinstance(result, tuple) else result

    return embeds


def _build_embeds_for_segment(
    *,
    vae,
    width: int,
    height: int,
    length: int,
    anchor_latent,
    anchor_frame_count: int,
    prev_latent_samples=None,
    reference_image=None,
    reference_strength: int = 4,
    continue_frames_count: int = 5,
    svi_motion_strength: float = 1.0,
    augment_empty_frames: float = 0.0,
    middle_image=None,
    middle_frame_ratio: float = 0.5,
    end_image=None,
    memory_latents_tensor=None,
    rope_negative_offset_frames: int = 5,
    enable_start_frame: bool = True,
    enable_middle_frame: bool = True,
    enable_end_frame: bool = True,
):
    spacial_scale = vae.upsampling_factor
    latent_channels = vae.z_dim
    total_latents = ((length - 1) // 4) + 1
    H_lat = height // spacial_scale
    W_lat = width // spacial_scale

    middle_idx = _calculate_aligned_position(middle_frame_ratio, length)
    middle_idx = max(4, min(middle_idx, length - 5))
    middle_latent_idx = middle_idx // 4
    end_latent_idx = total_latents - 1

    has_prev = prev_latent_samples is not None

    if reference_image is not None and not has_prev and anchor_frame_count == 1:
        log.info(f"[WanLooperDesigner] Multi-anchor (image-space): 1 ref + {reference_strength} start reps")
        ref_lat = _wrapper_vae_encode(vae, reference_image[:1])
        start_repeated = anchor_latent.repeat(1, reference_strength, 1, 1)
        anchor_latent = torch.cat([ref_lat, start_repeated], dim=1)
        anchor_frame_count = 1 + reference_strength

    if has_prev and continue_frames_count > 0:
        prev = prev_latent_samples
        if prev.dim() == 5:
            prev = prev[0]
        prev = prev.to(_DEVICE)

        motion_latent_count = min(
            prev.shape[1],
            ((continue_frames_count - 1) // 4) + 1,
        )
        motion_latent = prev[:, -motion_latent_count:].clone()
        if svi_motion_strength != 1.0:
            motion_latent = motion_latent * svi_motion_strength

        single_anchor = anchor_latent[:, :1].to(_DEVICE)
        y = torch.zeros(
            latent_channels, total_latents, H_lat, W_lat,
            dtype=torch.float32, device=_DEVICE,
        )
        if enable_start_frame:
            y[:, :1] = single_anchor

        motion_start = 1
        motion_end = motion_start + motion_latent.shape[1]
        if motion_end <= total_latents:
            y[:, motion_start:motion_end] = motion_latent

        msk = torch.zeros(
            4, total_latents, H_lat, W_lat,
            device=_DEVICE, dtype=torch.float32,
        )
        if enable_start_frame:
            msk[:, :1] = 1.0
        if motion_end <= total_latents:
            msk[:, motion_start:motion_end] = 1.0
    else:
        padding_size = total_latents - anchor_latent.shape[1]
        if padding_size > 0:
            padding = torch.zeros(
                latent_channels, padding_size, H_lat, W_lat,
                dtype=anchor_latent.dtype, device=anchor_latent.device,
            )
            y = torch.cat([anchor_latent, padding], dim=1)
        else:
            y = anchor_latent[:, :total_latents]

        image_cutoff = 1 + 4 * (anchor_frame_count - 1)
        image_cutoff = min(image_cutoff, length)

        msk = torch.ones(1, length, H_lat, W_lat,
                         device=y.device, dtype=torch.float32)
        msk[:, image_cutoff:] = 0
        msk = torch.cat([
            torch.repeat_interleave(msk[:, 0:1], repeats=4, dim=1),
            msk[:, 1:],
        ], dim=1)
        msk = msk.view(1, msk.shape[1] // 4, 4, H_lat, W_lat)
        msk = msk.transpose(1, 2)[0]

    if middle_image is not None and enable_middle_frame:
        mid_lat = _wrapper_vae_encode(vae, middle_image[:1])
        if middle_latent_idx < total_latents:
            y[:, middle_latent_idx:middle_latent_idx + 1] = mid_lat
            msk[:, middle_latent_idx:middle_latent_idx + 1] = 1.0

    if end_image is not None and enable_end_frame:
        end_lat = _wrapper_vae_encode(vae, end_image[:1])
        y[:, end_latent_idx:end_latent_idx + 1] = end_lat
        msk[:, end_latent_idx:end_latent_idx + 1] = 1.0

    if augment_empty_frames > 0.0:
        frame_is_empty = (msk[0].mean(dim=(-2, -1)) < 0.5).view(1, -1, 1, 1)
        y = y[:, :1] + (y - y[:, :1]) * (
            (augment_empty_frames + 1) * frame_is_empty + ~frame_is_empty
        )
        y = torch.clamp(y, -6.0, 6.0)

    image_embeds = {
        "image_embeds": y.cpu(),
        "mask": msk.cpu(),
        "num_frames": length,
        "lat_h": H_lat,
        "lat_w": W_lat,
    }

    if memory_latents_tensor is not None:
        story_mem = memory_latents_tensor
        if story_mem.dim() == 5:
            story_mem = story_mem[0]
        image_embeds["story_mem_latents"] = story_mem.cpu()
        image_embeds["rope_negative_offset_frames"] = rope_negative_offset_frames

    return image_embeds


# ===========================================================================
# Runtime resolution of Kijai wrapper classes (signature-tolerant)
# ===========================================================================

_WRAPPER_CLASSES = {}     
_WRAPPER_KWARGS = {}      

def _try_import_wrapper_class(class_name: str):
    if class_name in _WRAPPER_CLASSES:
        return _WRAPPER_CLASSES[class_name]

    candidate_modules = [
        "custom_nodes.ComfyUI-WanVideoWrapper.nodes_sampler",
        "custom_nodes.ComfyUI-WanVideoWrapper.nodes",
        "custom_nodes.ComfyUI_WanVideoWrapper.nodes_sampler",
        "custom_nodes.ComfyUI_WanVideoWrapper.nodes",
    ]
    for mod_path in candidate_modules:
        try:
            import importlib
            mod = importlib.import_module(mod_path)
            cls = getattr(mod, class_name, None)
            if cls is not None:
                _WRAPPER_CLASSES[class_name] = cls
                return cls
        except Exception:
            continue

    import sys
    for name, mod in list(sys.modules.items()):
        if mod is None:
            continue
        if "WanVideoWrapper" not in name and "wanvideowrapper" not in name.lower():
            continue
        cls = getattr(mod, class_name, None)
        if cls is not None:
            _WRAPPER_CLASSES[class_name] = cls
            return cls

    _WRAPPER_CLASSES[class_name] = None
    return None


def _fetch_sampler_combo_options(field_name: str, fallback: List[str]) -> List[str]:
    SamplerCls = _try_import_wrapper_class("WanVideoSampler")
    if SamplerCls is None:
        return list(fallback)
    try:
        spec = SamplerCls.INPUT_TYPES()
        for section in ("required", "optional"):
            sect = spec.get(section, {})
            if field_name in sect:
                entry = sect[field_name]
                if isinstance(entry, tuple) and len(entry) >= 1:
                    opts = entry[0]
                    if isinstance(opts, list) and opts:
                        return list(opts)
    except Exception as e:
        log.warning(f"[WanLooperDesigner] Could not introspect WanVideoSampler INPUT_TYPES for '{field_name}': {e}. Using fallback list.")
    return list(fallback)


_SCHEDULER_FALLBACK = [
    "unipc", "unipc/beta", "dpm++", "dpm++/beta",
    "dpm++_sde", "dpm++_sde/beta", "euler", "euler/beta",
    "longcat_distill_euler", "deis", "lcm", "lcm/beta",
    "res_multistep", "er_sde",
    "flowmatch_causvid", "flowmatch_distill", "flowmatch_pusa",
    "multitalk", "sa_ode_stable", "rcm", "vibt_unipc",
]
_ROPE_FUNCTION_FALLBACK = ["default", "comfy", "comfy_chunked"]


def _accepted_kwargs(method) -> set:
    try:
        sig = inspect.signature(method)
    except (TypeError, ValueError):
        return set()
    return {p.name for p in sig.parameters.values()
            if p.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD,
                          inspect.Parameter.KEYWORD_ONLY)}


def _call_wrapper(instance, method_names: Tuple[str, ...], **kwargs):
    for name in method_names:
        method = getattr(instance, name, None)
        if method is None:
            continue
        accepted = _accepted_kwargs(method)
        filtered = {k: v for k, v in kwargs.items() if k in accepted}
        return method(**filtered)
    raise RuntimeError(
        f"[WanLooperDesigner] No method on {type(instance).__name__} from "
        f"{method_names!r}. The installed WanVideoWrapper revision may be "
        f"too old or too new for this pack."
    )


def _apply_nag_to_embeds(
    text_embeds,
    t5,
    encoder_instance,
    nag_prompt_text: str,
    nag_scale: float,
    nag_tau: float,
    nag_alpha: float,
):
    NAGCls = _try_import_wrapper_class("WanVideoApplyNAG")
    if NAGCls is None:
        log.warning(
            "[WanLooperDesigner] NAG requested but WanVideoApplyNAG not "
            "found in the installed WanVideoWrapper. Continuing without "
            "NAG enrichment. Update Kijai's wrapper to get NAG support."
        )
        return text_embeds

    if not nag_prompt_text or not nag_prompt_text.strip():
        log.warning(
            "[WanLooperDesigner] NAG enabled but negative_prompt is empty. "
            "NAG needs a non-empty context prompt to push attention away "
            "from. Skipping NAG enrichment for this segment."
        )
        return text_embeds

    try:
        nag_embeds_raw = _call_wrapper(
            encoder_instance,
            ("process", "encode"),
            t5=t5,
            positive_prompt=nag_prompt_text,
            prompt=nag_prompt_text,
            text=nag_prompt_text,
            negative_prompt="",
            negative_text="",
            force_offload=False,
        )
        nag_text_embeds = nag_embeds_raw[0] if isinstance(nag_embeds_raw, tuple) else nag_embeds_raw
    except Exception as e:
        log.warning(
            f"[WanLooperDesigner] NAG context encode failed: {e}. "
            f"Continuing without NAG enrichment."
        )
        return text_embeds

    try:
        nag_node = NAGCls()
        nag_method = getattr(NAGCls, "FUNCTION", "process")
        result = _call_wrapper(
            nag_node,
            (nag_method, "process", "apply", "apply_nag"),
            original_text_embeds=text_embeds,
            text_embeds=text_embeds,
            nag_text_embeds=nag_text_embeds,
            nag_scale=float(nag_scale),
            nag_tau=float(nag_tau),
            nag_alpha=float(nag_alpha),
            inplace=True,
        )
        enriched = result[0] if isinstance(result, tuple) else result
        log.info(
            f"[WanLooperDesigner] NAG applied: scale={nag_scale}, "
            f"tau={nag_tau}, alpha={nag_alpha}"
        )
        return enriched
    except Exception as e:
        log.warning(
            f"[WanLooperDesigner] WanVideoApplyNAG call failed: {e}. "
            f"Continuing without NAG enrichment."
        )
        return text_embeds


# ===========================================================================
# Defensive patch: Kijai WanVideoSampler.process() uninitialized-local fix
# ===========================================================================

_KIJAI_MULTITALK_LOCALS_INIT = textwrap.dedent("""
    multitalk_audio_stride = None
    multitalk_audio_input = None
    multitalk_audio_embeds = None
    multitalk_audio_embedding = None
    audio_emb_slice = None
    audio_features_in = None
    audio_scale = 1.0
    audio_cfg_scale = 1.0
    ref_target_masks = None
    audio_proj = None
""").strip().splitlines()

def _patch_kijai_multitalk_uninit(sampler_cls):
    if sampler_cls is None:
        return False
    if getattr(sampler_cls, "_wld_multitalk_patched", False):
        return True

    proc = getattr(sampler_cls, "process", None)
    if proc is None:
        return False

    try:
        raw_src = inspect.getsource(proc)
    except (OSError, TypeError) as e:
        return False

    src = textwrap.dedent(raw_src)
    lines = src.split("\n")
    body_start_idx = None
    in_def = False
    paren_balance = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not in_def:
            if stripped.startswith("def process"):
                in_def = True
                paren_balance = line.count("(") - line.count(")")
                if paren_balance == 0 and stripped.endswith(":"):
                    body_start_idx = i + 1
                    break
            continue
        paren_balance += line.count("(") - line.count(")")
        if paren_balance == 0 and stripped.endswith(":"):
            body_start_idx = i + 1
            break

    if body_start_idx is None or body_start_idx >= len(lines):
        return False

    body_line_idx = body_start_idx
    while body_line_idx < len(lines):
        s = lines[body_line_idx].strip()
        if s and not s.startswith("#"):
            break
        body_line_idx += 1
    if body_line_idx >= len(lines):
        return False
    body_line = lines[body_line_idx]
    indent = body_line[:len(body_line) - len(body_line.lstrip())]

    if "WanLooperDesigner uninit-local defensive init" in src:
        sampler_cls._wld_multitalk_patched = True
        return True

    init_block = [
        f"{indent}# --- WanLooperDesigner uninit-local defensive init ---",
        *[f"{indent}{line}" for line in _KIJAI_MULTITALK_LOCALS_INIT],
        f"{indent}# --- end WanLooperDesigner injection ---",
    ]
    new_lines = lines[:body_start_idx] + init_block + lines[body_start_idx:]
    new_src = "\n".join(new_lines)

    try:
        proc_globals = proc.__globals__
        local_ns = {}
        exec(compile(new_src, "<wld-patched WanVideoSampler.process>", "exec"),
             proc_globals, local_ns)
        new_proc = local_ns.get("process")
        if new_proc is None:
            return False
        sampler_cls.process = new_proc
        sampler_cls._wld_multitalk_patched = True
        return True
    except Exception as e:
        return False


# ===========================================================================
# Optional KJNodes overlap blender (image-space crossfade)
# ===========================================================================

_KJ_OVERLAP_INSTANCE = None
_KJ_OVERLAP_TRIED = False

def _resolve_kj_overlap():
    global _KJ_OVERLAP_INSTANCE, _KJ_OVERLAP_TRIED
    if _KJ_OVERLAP_TRIED:
        return _KJ_OVERLAP_INSTANCE
    _KJ_OVERLAP_TRIED = True

    candidates = [
        "custom_nodes.ComfyUI-KJNodes.nodes.image_nodes",
        "custom_nodes.comfyui-kjnodes.nodes.image_nodes",
    ]
    for mod_path in candidates:
        try:
            import importlib
            mod = importlib.import_module(mod_path)
            cls = getattr(mod, "ImageBatchExtendWithOverlap", None)
            if cls is not None:
                _KJ_OVERLAP_INSTANCE = cls()
                return _KJ_OVERLAP_INSTANCE
        except Exception:
            continue

    import sys
    for name, mod in list(sys.modules.items()):
        if mod is None:
            continue
        if "kjnodes" not in name.lower() and "KJNodes" not in name:
            continue
        cls = getattr(mod, "ImageBatchExtendWithOverlap", None)
        if cls is not None:
            _KJ_OVERLAP_INSTANCE = cls()
            return _KJ_OVERLAP_INSTANCE

    log.warning(
        "[WanLooperDesigner] ImageBatchExtendWithOverlap not found "
        "(comfyui-kjnodes not installed?). Crossfade stitch policies "
        "will fall back to 'cut'."
    )
    return None


# ===========================================================================
# Stitching helpers
# ===========================================================================

def _latent_seam_stitch(per_seg_latents: List[torch.Tensor],
                        svipro_motion_latent_count: int = 1,
                        anchor_latent_count: int = 1,
                        blend_latents: int = 0,
                        blend_mode: str = "linear") -> torch.Tensor:
    if not per_seg_latents:
        return torch.zeros(0)
    if len(per_seg_latents) == 1:
        return per_seg_latents[0]

    M = max(1, int(svipro_motion_latent_count))
    blend_w = max(0, min(int(blend_latents), M))

    pieces = [per_seg_latents[0]]
    for seg in per_seg_latents[1:]:
        prev = pieces[-1]
        seg_no_anchor = seg[:, anchor_latent_count:] if seg.shape[1] >= anchor_latent_count else seg

        if blend_w == 0 or seg_no_anchor.shape[1] <= M or prev.shape[1] < blend_w:
            drop = M
            if seg_no_anchor.shape[1] > drop:
                pieces.append(seg_no_anchor[:, drop:])
            continue

        skip = M - blend_w
        prev_tail = prev[:, -blend_w:]
        seg_bridge = seg_no_anchor[:, skip : skip + blend_w]
        seg_rest = seg_no_anchor[:, skip + blend_w :]

        idx = torch.arange(1, blend_w + 1, dtype=prev_tail.dtype, device=prev_tail.device)
        if blend_mode == "cosine":
            ramp = 0.5 - 0.5 * torch.cos(idx * math.pi / (blend_w + 1))
        else:
            ramp = idx / (blend_w + 1)
        w = ramp.view(1, blend_w, 1, 1)
        blended = prev_tail * (1.0 - w) + seg_bridge.to(prev_tail.device) * w

        pieces[-1] = torch.cat([prev[:, :-blend_w], blended], dim=1)
        if seg_rest.shape[1] > 0:
            pieces.append(seg_rest)

    return torch.cat(pieces, dim=1)


def _latent_overlap_drop(per_seg_latents: List[torch.Tensor],
                        continue_frames_count: int,
                        anchor_latent_count: int = 1) -> torch.Tensor:
    motion_latent_count = max(1, ((continue_frames_count - 1) // 4) + 1)
    return _latent_seam_stitch(per_seg_latents, svipro_motion_latent_count=motion_latent_count,
                               anchor_latent_count=anchor_latent_count, blend_latents=0)


def _image_stitch_cut(per_seg_images: List[torch.Tensor],
                     svipro_motion_latent_count: int,
                     anchor_latent_count: int = 1) -> torch.Tensor:
    if not per_seg_images:
        return torch.zeros(0, 1, 1, 3)
    if svipro_motion_latent_count <= 0 or len(per_seg_images) == 1:
        return torch.cat(per_seg_images, dim=0)

    motion_latent_count = max(1, int(svipro_motion_latent_count))
    drop_image_frames = 1 + (anchor_latent_count + motion_latent_count - 1) * 4
    
    pieces = [per_seg_images[0]]
    for seg in per_seg_images[1:]:
        if seg.shape[0] > drop_image_frames:
            pieces.append(seg[drop_image_frames:])
        else:
            log.warning(f"[WanLooperDesigner] Segment too short to drop {drop_image_frames} frames. Dropping entirely.")
    return torch.cat(pieces, dim=0)


def _image_stitch_crossfade(per_seg_images: List[torch.Tensor],
                           overlap_frames: int,
                           overlap_mode: str,
                           svipro_motion_latent_count: int,
                           overlap_side: str = "source") -> torch.Tensor:
    if not per_seg_images:
        return torch.zeros(0, 1, 1, 3)
    if len(per_seg_images) == 1 or overlap_frames <= 0:
        return _image_stitch_cut(per_seg_images, svipro_motion_latent_count)

    overlap_inst = _resolve_kj_overlap()
    if overlap_inst is None:
        log.warning(
            f"[WanLooperDesigner] crossfade policy '{overlap_mode}' "
            f"requested but KJNodes is unavailable. Falling back to cut."
        )
        return _image_stitch_cut(per_seg_images, svipro_motion_latent_count)

    motion_frames = max(1, int(svipro_motion_latent_count)) * 4
    eff_overlap = min(overlap_frames, motion_frames)

    acc = per_seg_images[0]
    for seg_idx, nxt in enumerate(per_seg_images[1:], start=1):
        if nxt.shape[0] > 1:
            nxt = nxt[1:]
            
        frames_to_skip = motion_frames - eff_overlap
        if frames_to_skip > 0 and nxt.shape[0] > frames_to_skip:
            nxt = nxt[frames_to_skip:]
            
        if eff_overlap <= 0:
            acc = torch.cat([acc, nxt], dim=0)
            continue
            
        try:
            safe_overlap = min(eff_overlap, acc.shape[0], nxt.shape[0])
            result = overlap_inst.imagesfrombatch(
                source_images=acc,
                overlap=safe_overlap,
                overlap_side=overlap_side,
                overlap_mode=overlap_mode,
                new_images=nxt,
            )
            extended = result[2] if len(result) >= 3 else result[0]
            acc = extended
        except Exception as e:
            log.error(
                f"[WanLooperDesigner] crossfade blend failed: {e}. "
                f"Falling back to cut for this seam."
            )
            safe_overlap = min(eff_overlap, acc.shape[0], nxt.shape[0])
            acc = torch.cat([acc, nxt[safe_overlap:]], dim=0)
    return acc


# ===========================================================================
# Color correction (anchor renormalization)
# ===========================================================================

def _capture_color_stats(image_bhwc: torch.Tensor):
    f = image_bhwc.float()
    ref_mean = f.mean(dim=(0, 1, 2), keepdim=True)
    ref_std = f.std(dim=(0, 1, 2), keepdim=True).clamp(min=1e-5)
    return ref_mean, ref_std


def _renormalize_to_stats(image_bhwc: torch.Tensor, ref_mean, ref_std):
    f = image_bhwc.float()
    a_mean = f.mean(dim=(0, 1, 2), keepdim=True)
    a_std = f.std(dim=(0, 1, 2), keepdim=True).clamp(min=1e-5)
    out = ((f - a_mean) / a_std) * ref_std + ref_mean
    return out.clamp(0.0, 1.0).to(image_bhwc.dtype)


# ===========================================================================
# Segments JSON parsing
# ===========================================================================

_SEGMENT_DEFAULTS = {
    "frames": 81,
    "prompt": "",
    "anchor_mode": "global",
    "promote_anchor": False,
    "seed_override": None,
    "cfg_high_override": None,
    "cfg_low_override": None,
    "width_override": None,
    "height_override": None,
    "anchor_image_filename": "",
    "middle_image_filename": "",
    "end_image_filename": "",
    "memory_image_filenames": [],
    "model_preset": None,
}


def _parse_segments(segments_json: str) -> List[Dict[str, Any]]:
    if not segments_json or not segments_json.strip():
        return []
    try:
        parsed = json.loads(segments_json)
    except json.JSONDecodeError as e:
        raise ValueError(f"[WanLooperDesigner] segments_json is not valid JSON: {e}")
    if not isinstance(parsed, list):
        raise ValueError("[WanLooperDesigner] segments_json must be a JSON array.")
    out = []
    for i, seg in enumerate(parsed):
        if not isinstance(seg, dict):
            raise ValueError(f"[WanLooperDesigner] segments_json[{i}] is not an object.")
        normalized = dict(_SEGMENT_DEFAULTS)
        normalized.update(seg)
        normalized["frames"] = int(normalized["frames"])
        if normalized["frames"] < 9:
            raise ValueError(f"[WanLooperDesigner] segments_json[{i}].frames must be >= 9.")
        if normalized["anchor_mode"] not in ("global", "previous_last_frame", "custom_override"):
            raise ValueError(f"[WanLooperDesigner] invalid anchor_mode.")
        out.append(normalized)
    return out


# ===========================================================================
# Server-side Ollama generation
# ===========================================================================

_OLLAMA_DEFAULT_SYSTEM_PROMPT = (
    "You write per-segment prompts for the Wan 2.2 video generation model\n"
    "in a Stable Video Infinity (SVI 2.2 Pro) chain. The chain produces a\n"
    "long continuous video by stitching N short segments, each conditioned\n"
    "on a shared anchor image (the same character/scene identity) and on\n"
    "the motion latents of the previous segment.\n"
    "\n"
    "Rules:\n"
    "- Each segment is ~3 seconds (~5 if 121 frames). Describe what is\n"
    "  visibly happening DURING that segment in present tense, third person.\n"
    "- Keep identity (subject, wardrobe, location, lighting) stable across\n"
    "  segments unless the user asks for a transition.\n"
    "- Write visible action in temporal order. Wan 2.2 follows clear\n"
    "  sequences better than disconnected tag piles.\n"
    "- Be specific: gestures, gaze direction, micro-motion, physical objects.\n"
    "- No preamble, no headers, no quotation marks. Output only the prompt.\n"
    "\n"
    "If an anchor image is provided, treat it as the literal starting frame\n"
    "and write prompts that flow naturally from what is visibly there."
)

_OLLAMA_ENHANCE_SYSTEM_PROMPT = (
    "You are an expert prompt writer for Wan 2.2 video generation in a\n"
    "Stable Video Infinity (SVI 2.2 Pro) chain. You ENHANCE the user's\n"
    "existing prompts to follow Wan 2.2 best practices without changing\n"
    "their intent.\n"
    "\n"
    "Wan 2.2 best practices:\n"
    "- Describe subject, setting, action, camera, lighting, mood, and\n"
    "  visual style in concrete cinematic language.\n"
    "- Write visible action in temporal order.\n"
    "- Keep identity, wardrobe, location, and chronology stable across\n"
    "  segments unless the user asked for a transition.\n"
    "- Use concrete physical action and cinematic detail. Avoid generic\n"
    "  filler ('beautiful', 'amazing', 'epic').\n"
    "- Preserve the user's original intent, characters, language, setting,\n"
    "  spoken words, and ending. Do not invent a different story.\n"
    "\n"
    "Input structure (when per-segment mode is ON):\n"
    "  base: <global anchor prompt>\n"
    "  segments: [{ idx, prompt }, ...]\n"
    "\n"
    "Output: same structure with rewritten 'prompt' fields. No preamble."
)


def _anchor_tensor_to_b64_png(image_bhwc: torch.Tensor) -> Optional[str]:
    try:
        import io
        import base64
        from PIL import Image
        import numpy as np

        img = image_bhwc
        if img.dim() == 4:
            img = img[0]
        arr = img.detach().cpu().clamp(0.0, 1.0).numpy()
        arr_u8 = (arr * 255.0 + 0.5).astype(np.uint8)
        pil = Image.fromarray(arr_u8)
        buf = io.BytesIO()
        pil.save(buf, format="PNG", optimize=False, compress_level=1)
        return base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception as e:
        log.warning(f"[WanLooperDesigner] anchor->base64 failed: {e}")
        return None


def _build_ollama_user_prompt_server(segments: List[Dict[str, Any]],
                                      story: str,
                                      direction: str,
                                      base_prompt: str,
                                      per_segment: bool,
                                      enhance: bool) -> str:
    num_segs = len(segments)
    body_lines = []
    if enhance:
        body_lines.append("ENHANCE the following prompts in Wan 2.2 cinematic style. Keep intent.")
        body_lines.append("")
        body_lines.append(f"Base prompt: {(base_prompt or '').strip() or '(empty)'}")
        body_lines.append("")
        body_lines.append("Segments:")
        for i, s in enumerate(segments):
            p = (s.get("prompt") or "").strip() or "(empty)"
            body_lines.append(f"  {i + 1}. ({s.get('frames', 81)} frames) {p}")
        if per_segment:
            body_lines.append("")
            body_lines.append("Output JSON with this exact shape:")
            body_lines.append('{ "base": "<enhanced base>", "segments": [{"idx": 1, "prompt": "<enhanced>"}, ...] }')
        else:
            body_lines.append("")
            body_lines.append("Output a single rewritten base prompt only. No JSON, no preamble.")
    else:
        body_lines.append(f"Story: {(story or '').strip() or '(unspecified)'}")
        if (direction or "").strip():
            body_lines.append(f"Direction: {direction.strip()}")
        body_lines.append("")
        target = f"{num_segs} per-segment prompts plus a base prompt" if per_segment else "a single base prompt"
        body_lines.append(f"Generate {target} for a {num_segs}-segment Wan 2.2 SVI chain.")
        for i, s in enumerate(segments):
            body_lines.append(f"Segment {i + 1}: {s.get('frames', 81)} frames.")
        if per_segment:
            body_lines.append("")
            body_lines.append("Output JSON with this exact shape:")
            body_lines.append('{ "base": "<global anchor description>", "segments": [{"idx": 1, "prompt": "<segment 1 action>"}, ...] }')
            body_lines.append("No preamble.")
        else:
            body_lines.append("")
            body_lines.append("Output a single base prompt. No JSON, no preamble.")
    return "\n".join(body_lines)


def _extract_json_from_response(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    text = text.strip()
    try:
        v = json.loads(text)
        if isinstance(v, dict):
            return v
    except Exception:
        pass
    if text.startswith("```"):
        lines = text.split("\n")
        if lines:
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        cleaned = "\n".join(lines).strip()
        try:
            v = json.loads(cleaned)
            if isinstance(v, dict):
                return v
        except Exception:
            pass
    start = text.find("{")
    while start != -1:
        depth = 0
        for end in range(start, len(text)):
            c = text[end]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    candidate = text[start:end + 1]
                    try:
                        v = json.loads(candidate)
                        if isinstance(v, dict):
                            return v
                    except Exception:
                        pass
                    break
        start = text.find("{", start + 1)
    return None


def _ollama_generate_prompts_server_side(
    anchor_image_bhwc: Optional[torch.Tensor],
    segments: List[Dict[str, Any]],
    base_prompt: str,
    *,
    ollama_url: str,
    model: str,
    system_prompt: str,
    story: str,
    direction: str,
    per_segment: bool,
    enhance: bool,
    use_frame: bool,
    temperature: float,
    num_ctx: int,
    unload_after: bool,
) -> Tuple[Optional[str], Optional[List[Dict[str, Any]]]]:
    if not model:
        return None, None

    try:
        import requests
    except ImportError:
        return None, None

    user_prompt = _build_ollama_user_prompt_server(
        segments, story, direction, base_prompt, per_segment, enhance
    )
    sys_p = (system_prompt or "").strip()
    if not sys_p:
        sys_p = _OLLAMA_ENHANCE_SYSTEM_PROMPT if enhance else _OLLAMA_DEFAULT_SYSTEM_PROMPT

    payload: Dict[str, Any] = {
        "model": model,
        "prompt": user_prompt,
        "system": sys_p,
        "stream": False,
        "options": {
            "temperature": float(temperature),
            "num_ctx": int(num_ctx),
        },
    }
    if unload_after:
        payload["keep_alive"] = 0
    if use_frame and anchor_image_bhwc is not None:
        b64 = _anchor_tensor_to_b64_png(anchor_image_bhwc)
        if b64:
            payload["images"] = [b64]

    url = (ollama_url or "http://127.0.0.1:11434").rstrip("/")
    try:
        resp = requests.post(f"{url}/api/generate", json=payload, timeout=300)
    except Exception as e:
        return None, None
    if resp.status_code != 200:
        return None, None
    try:
        data = resp.json()
    except Exception as e:
        return None, None

    text = (data.get("response") or "").strip()
    if not text:
        return None, None

    if per_segment:
        parsed = _extract_json_from_response(text)
        if not parsed:
            return text, None
        new_base = parsed.get("base") if isinstance(parsed.get("base"), str) else None
        new_segments = [dict(s) for s in segments]
        for s in (parsed.get("segments") or []):
            if not isinstance(s, dict):
                continue
            try:
                idx = int(s.get("idx")) - 1
            except (TypeError, ValueError):
                continue
            if 0 <= idx < len(new_segments) and isinstance(s.get("prompt"), str):
                new_segments[idx]["prompt"] = s["prompt"]
        return (new_base if new_base is not None else base_prompt), new_segments

    return text, None


def _push_applied_prompts_to_gui(unique_id, new_base: Optional[str],
                                  new_segments: Optional[List[Dict[str, Any]]]) -> None:
    try:
        from server import PromptServer
        PromptServer.instance.send_sync(
            "wld_ollama_applied",
            {
                "node_id": str(unique_id) if unique_id is not None else "",
                "base": new_base if isinstance(new_base, str) else None,
                "segments": new_segments if isinstance(new_segments, list) else None,
            },
        )
    except Exception:
        pass


# ===========================================================================
# Auto-generate Default System Prompts
# ===========================================================================
_SYSTEM_PROMPTS_DIR = pathlib.Path(__file__).parent / "system_prompts"
try:
    _SYSTEM_PROMPTS_DIR.mkdir(parents=True, exist_ok=True)
    _default_presets = {
        "00-character-narrative.txt": "# Title: Character Narrative\n# Description: Follows one consistent character through a sequence of actions.\n\nYou write per-segment prompts for a Wan 2.2 SVI 2.2 Pro chain that follows ONE consistent character through a short story. The anchor image defines the character's appearance; every segment keeps that appearance stable.\n\nRules:\n- The character's face, hair, body type, clothing, and accessories stay consistent across all segments. Do not invent new outfits or features.\n- Each segment is one beat in a 3-act arc: setup, conflict or turn, resolution. Plan beats across the segment count provided.\n- Write visible action in temporal order. Use concrete physical gestures, gaze direction, micro-motion, and physical objects the character interacts with.\n- Keep the setting stable unless the story explicitly transitions; reuse recognizable landmarks and lighting cues across segments.\n- Present tense, third person, no preamble, no quotation marks, no headers.\n\nIf the user provides a story concept, expand it into beats. If not, invent a small grounded scene from the anchor image.",
        "01-cinematic-shots.txt": "# Title: Cinematic Shots\n# Description: Describes each segment as a distinct camera shot or angle.\n\nYou are an expert cinematographer writing per-segment prompts for a Wan 2.2 video generation chain.\n\nRules:\n- Describe the camera work explicitly (e.g., 'A medium close-up, slow push-in', 'A wide tracking shot', 'Low-angle pan').\n- Focus on lighting, atmosphere, and lens characteristics (e.g., 'volumetric fog', 'lens flare', 'shallow depth of field', 'high-contrast chiaroscuro').\n- Maintain chronological continuity of the action, but feel free to change the camera perspective between segments if appropriate.\n- Output ONLY the prompt text. No preamble, no headers.",
        "02-dynamic-action.txt": "# Title: Dynamic Action\n# Description: High-energy sequence with escalating motion and physical impact.\n\nYou are writing action-oriented per-segment prompts for a Wan 2.2 video generation chain.\n\nRules:\n- Focus on kinetic energy, weight, and momentum.\n- Each segment should escalate the action from the previous one.\n- Describe physical impacts, debris, dynamic lighting changes (sparks, explosions, fast shadows), and fast camera movements (whip pans, rapid zooms).\n- Do not use abstract words like 'epic' or 'awesome'; instead describe *what makes it epic* (e.g., 'concrete shatters as the vehicle drifts sideways, kicking up a massive cloud of glowing dust').\n- Output ONLY the prompt text. No preamble.",
        "03-wan-enhance.txt": "# Title: Wan Enhance\n# Description: Rewrites prompts to follow Wan 2.2 best practices.\n\nYou are an expert prompt writer for Wan 2.2 video generation. You ENHANCE the user's existing prompts to follow Wan 2.2 best practices without changing their intent.\n\nWan 2.2 best practices:\n- Describe subject, setting, action, camera, lighting, mood, and visual style in concrete cinematic language.\n- Write visible action in temporal order.\n- Keep identity, wardrobe, location, and chronology stable across segments unless the user asked for a transition.\n- Use concrete physical action and cinematic detail. Avoid generic filler ('beautiful', 'amazing', 'epic').\n- Preserve the user's original intent, characters, language, setting, spoken words, and ending. Do not invent a different story.\n\nOutput ONLY the rewritten prompt(s). No preamble."
    }
    for _filename, _content in _default_presets.items():
        _filepath = _SYSTEM_PROMPTS_DIR / _filename
        if not _filepath.exists():
            _filepath.write_text(_content, encoding="utf-8")
except Exception as e:
    log.warning(f"[WanLooperDesigner] Failed to create default system prompts: {e}")


# ===========================================================================
# Image loading from filename
# ===========================================================================

def _load_image_from_input(filename: str) -> Optional[torch.Tensor]:
    if not filename or folder_paths is None:
        return None
    try:
        path = os.path.join(folder_paths.get_input_directory(), filename)
    except Exception:
        return None
    if not os.path.isfile(path):
        return None
    try:
        import numpy as np
        from PIL import Image
        img = Image.open(path).convert("RGB")
        arr = np.asarray(img, dtype="float32") / 255.0
        return torch.from_numpy(arr).unsqueeze(0)  # (1, H, W, 3)
    except Exception as e:
        return None


# ===========================================================================
# Seed resolution
# ===========================================================================

def _resolve_seed(base_seed: int, policy: str, seg_idx: int, override: Optional[int]) -> int:
    if override is not None:
        return int(override)
    if policy == "fixed_global":
        return base_seed
    if policy == "increment_per_segment":
        return base_seed + seg_idx
    if policy == "random_per_segment":
        import random
        return random.getrandbits(64)
    return base_seed


# ===========================================================================
# Main node class
# ===========================================================================

class WanLooperDesigner:
    """Multi-segment Wan 2.2 I2V looper for Kijai's WanVideoWrapper."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model_high": ("WANVIDEOMODEL", {"tooltip": "Wan 2.2 high-noise expert. FOR WANANIMATE/EVERANIMATE: Put the Wan2_2-Animate-14B model here."}),
                "vae": ("WANVAE", {"tooltip": "Kijai's WanVideoVAE."}),
                "t5": ("WANTEXTENCODER", {"tooltip": "Wan T5 text encoder."}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xFFFFFFFFFFFFFFFF, "control_after_generate": True}),
            },
            "optional": {
                "model_low": ("WANVIDEOMODEL", {"tooltip": "Wan 2.2 low-noise expert. FOR WANANIMATE/EVERANIMATE: Leave EMPTY (auto-ignored if pose_images are wired)."}),
                "anchor_image": ("IMAGE", {"tooltip": "Persistent SVI 2.2 Pro anchor image."}),
                "anchor_samples": ("LATENT", {"tooltip": "Pre-encoded persistent anchor."}),
                "reference_image": ("IMAGE", {"tooltip": "Multi-anchor donor for segment 1 ONLY."}),
                "memory_images": ("IMAGE", {"tooltip": "StoryMem frames."}),
                "memory_latents": ("LATENT", {"tooltip": "Pre-encoded StoryMem frames."}),
                
                # --- NEW: WanAnimate / EverAnimate Inputs ---
                "pose_images": ("IMAGE", {"tooltip": "Pose video/images for WanAnimate / EverAnimate."}),
                "face_images": ("IMAGE", {"tooltip": "Face video/images for WanAnimate / EverAnimate."}),
                "bg_image": ("IMAGE", {"tooltip": "Optional background image for WanAnimate / EverAnimate."}),
                
                # ===== GUI-managed hidden widgets (Designer panel state) =====
                "width": ("INT", {"default": 832, "min": 64, "max": 4096, "step": 16}),
                "height": ("INT", {"default": 480, "min": 64, "max": 4096, "step": 16}),
                
                # Defaulted to LightX2V distill settings
                "steps": ("INT", {"default": 6, "min": 1, "max": 200}),
                "split_step": ("INT", {"default": 3, "min": 1, "max": 199}),
                "cfg_high": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 30.0, "step": 0.1}),
                "cfg_low": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 30.0, "step": 0.1}),
                "scheduler": (_fetch_sampler_combo_options("scheduler", _SCHEDULER_FALLBACK), {"default": "euler"}),
                "shift": ("FLOAT", {
                    "default": 4.0, "min": 0.0, "max": 1000.0, "step": 0.01,
                    "tooltip": "Flow-matching timestep shift. Distill/Lightning typically uses 4.0."
                }),

                "seed_policy": (["fixed_global", "increment_per_segment", "random_per_segment"], {"default": "increment_per_segment"}),
                
                "continue_frames_count": ("INT", {"default": 5, "min": 0, "max": 20}),
                "svi_motion_strength": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.05}),
                "augment_empty_frames": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 2.0, "step": 0.01}),
                "everanimate_mode": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "Enable EverAnimate latent hack (N=4 anchor latents). "
                               "Bypasses the need for Kijai's unmerged PR. ONLY toggle "
                               "ON when using the EverAnimate LoRA."
                }),
                "reference_strength": ("INT", {"default": 4, "min": 1, "max": 40, "step": 1}),
                "stitch_policy": (["linear_blend", "svi_overlap_drop", "cut", "ease_in_out", "filmic_crossfade"], {"default": "linear_blend",
                    "tooltip": "linear_blend (default) = per-segment decode + image-space crossfade "
                               "via KJ ImageBatchExtendWithOverlap, mirroring the proven subgraph "
                               "workflow. svi_overlap_drop/cut = pure latent hard cut. Latent SAMPLES "
                               "outputs are ALWAYS a pure hard-cut concat regardless of this setting; "
                               "blending only ever happens in decoded image space."}),
                "overlap_blend_frames": ("INT", {"default": 5, "min": 0, "max": 30}),
                "overlap_side": (["source", "new_images"], {"default": "source"}),
                "startup_trim": ("INT", {"default": 0, "min": 0, "max": 20}),
                "decode_per_segment": (["final_only", "always", "never"], {"default": "final_only"}),
                "color_correction": ("BOOLEAN", {"default": False}),
                "anchor_frame_offset": ("INT", {"default": -5, "min": -50, "max": -1}),
                "spill_to_disk": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "Spill per-segment decoded images to disk "
                               "instead of keeping in RAM. Memory-saver for "
                               "low-RAM systems running many long segments "
                               "with decode_per_segment='always'. On the "
                               "lazy-decode-for-blending path it's a no-op. "
                               "Default OFF; only turn on if you've seen "
                               "out-of-memory errors during multi-segment runs."
                }),
                "rope_negative_offset": ("BOOLEAN", {"default": True}),
                "rope_negative_offset_frames": ("INT", {"default": 5, "min": 0, "max": 100}),
                "image_resize_mode": (
                    ["crop", "pad", "stretch"],
                    {"default": "crop",
                     "tooltip": "How to fit input images (anchor, reference, middle, end, "
                                "memory) to width x height. 'crop' (default) = resize-fill "
                                "then center-crop; 'pad' = letterbox with black bars; "
                                "'stretch' = non-uniform resize."},
                ),

                "segments_json": ("STRING", {"default": "[]", "multiline": True}),
                "global_prompt": ("STRING", {"default": "", "multiline": True}),
                "negative_prompt": ("STRING", {"default": "", "multiline": True}),

                "anchor_image_filename": ("STRING", {"default": ""}),
                "ollama_model": ("STRING", {"default": ""}),
                "ollama_url": ("STRING", {"default": "http://127.0.0.1:11434"}),
                "ollama_story_concept": ("STRING", {"default": "", "multiline": True}),
                "ollama_custom_direction": ("STRING", {"default": "", "multiline": True}),
                "ollama_system_prompt": ("STRING", {"default": "", "multiline": True}),
                "ollama_temperature": ("FLOAT", {"default": 0.9, "min": 0.0, "max": 2.0, "step": 0.05}),
                "ollama_ctx": ("INT", {"default": 8192, "min": 2048, "max": 131072, "step": 1024}),
                "ollama_use_frame": ("BOOLEAN", {"default": False}),
                "ollama_unload_after_gen": ("BOOLEAN", {"default": False}),
                "ollama_side_panel": ("BOOLEAN", {"default": False}),
                "ollama_per_segment": ("BOOLEAN", {"default": False}),
                "ollama_enhance": ("BOOLEAN", {"default": False}),
                "system_prompt_preset_filename": ("STRING", {"default": ""}),
                "auto_generate_on_queue": ("BOOLEAN", {"default": False}),
                "reroll_on_queue": ("BOOLEAN", {"default": False}),
                "svipro_motion_latent_count": ("INT", {
                    "default": 1, "min": 1, "max": 8,
                    "tooltip": "How many latents from the previous clip's tail "
                               "are fed into SVI 2.2 Pro's motion-conditioning slot. "
                               "Kijai's default and Jason's prod workflow value is 1 "
                               "(= 4 image frames of overlap context). Higher values "
                               "give the model more seam-bridging context but cost "
                               "more compute. Also bounds the maximum latent-space "
                               "seam crossfade width (you can't blend wider than the "
                               "motion bridge actually generated)."
                }),
                "rope_function": (_fetch_sampler_combo_options("rope_function", _ROPE_FUNCTION_FALLBACK), {
                    "default": "comfy",
                    "tooltip": "RoPE implementation. Pulled dynamically from "
                               "WanVideoSampler so new options Kijai adds appear "
                               "automatically. 'comfy' is the default Kijai uses "
                               "in his current example workflows."
                }),
                "nag_enabled": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "Apply Normalized Attention Guidance using the "
                               "negative_prompt as the NAG context. Primary use "
                               "case: distilled/Lightning/LightX2V models running "
                               "at CFG=1 where regular negative prompting is "
                               "ineffective. NAG operates in attention space so "
                               "negative guidance bites even without a real CFG "
                               "uncond pass. Requires Kijai's WanVideoApplyNAG "
                               "node (ships with WanVideoWrapper main branch)."
                }),
                "nag_scale": ("FLOAT", {
                    "default": 12.0, "min": 0.0, "max": 100.0, "step": 0.5,
                    "tooltip": "Strength of the NAG push-away from the "
                               "negative prompt's attention features. "
                               "Kijai's example WF uses 12.0; lower (5-8) for "
                               "subtler effect, higher (15-20) when CFG=1 "
                               "isn't biting hard enough against problem terms."
                }),
                "nag_tau": ("FLOAT", {
                    "default": 4.0, "min": 0.1, "max": 10.0, "step": 0.1,
                    "tooltip": "Tau clamping threshold. Caps how far NAG can "
                               "drag attention features off-manifold before "
                               "being pulled back. Kijai's example WF uses 4.0; "
                               "the NAG paper recommends 2.5 as the safer "
                               "starting point if you see artifacts."
                }),
                "nag_alpha": ("FLOAT", {
                    "default": 0.40, "min": 0.0, "max": 1.0, "step": 0.01,
                    "tooltip": "Alpha blend between NAG-guided attention "
                               "(alpha) and the original positive attention "
                               "(1-alpha). 0.0 = no NAG effect (passthrough); "
                               "1.0 = full NAG with no positive blend. "
                               "Kijai's example WF uses 0.40; the NAG paper "
                               "uses 0.25."
                }),
                "nag_apply_to": (["both", "high_only", "low_only"], {
                    "default": "both",
                    "tooltip": "Which sampler phase gets the NAG-enriched "
                               "text embeds. 'both' (default) matches Kijai's "
                               "typical i2v setup where ApplyNAG sits before "
                               "the embeds feed both high and low samplers. "
                               "'high_only' applies NAG to the structural "
                               "pass only; 'low_only' applies it to the "
                               "refinement pass only. Use single-phase modes "
                               "if NAG is over-correcting one stage."
                }),
            },
            "hidden": {
                "unique_id": "UNIQUE_ID",
                "prompt": "PROMPT",
                "extra_pnginfo": "EXTRA_PNGINFO",
            },
        }

    RETURN_TYPES = ("IMAGE", "LATENT", "LATENT", "INT", "STRING", "STRING")
    RETURN_NAMES = ("images", "samples", "per_segment_samples", "num_segments", "segments_json", "global_prompt")
    FUNCTION = "execute"
    CATEGORY = "WanLooperDesigner"

    def execute(
        self,
        model_high, vae, t5,
        width, height, steps, split_step,
        cfg_high, cfg_low, scheduler, seed, seed_policy,
        continue_frames_count, svi_motion_strength, augment_empty_frames,
        everanimate_mode, reference_strength,
        stitch_policy, overlap_blend_frames, overlap_side, startup_trim,
        decode_per_segment, color_correction, anchor_frame_offset,
        spill_to_disk, segments_json, global_prompt, negative_prompt,
        anchor_image_filename="",
        ollama_model="", ollama_url="http://127.0.0.1:11434",
        ollama_story_concept="", ollama_custom_direction="",
        ollama_system_prompt="",
        ollama_temperature=0.9, ollama_ctx=8192, ollama_use_frame=False,
        ollama_unload_after_gen=False, ollama_side_panel=False,
        ollama_per_segment=False, ollama_enhance=False,
        system_prompt_preset_filename="",
        auto_generate_on_queue=False, reroll_on_queue=False,
        model_low=None,
        anchor_image=None, anchor_samples=None,
        reference_image=None,
        memory_images=None, memory_latents=None,
        pose_images=None, face_images=None, bg_image=None,
        unique_id=None, prompt=None, extra_pnginfo=None,
        rope_negative_offset=True, rope_negative_offset_frames=5,
        svipro_motion_latent_count=1,
        image_resize_mode="crop",
        shift=5.0,
        rope_function="comfy",
        nag_enabled=False,
        nag_scale=12.0,
        nag_tau=4.0,
        nag_alpha=0.40,
        nag_apply_to="both",
    ):
        segments = _parse_segments(segments_json)
        if not segments:
            raise ValueError("[WanLooperDesigner] segments_json is empty. Author at least one segment.")

        if width % 16 != 0 or height % 16 != 0:
            raise ValueError(f"[WanLooperDesigner] width and height must be multiples of 16.")

        SamplerCls = _try_import_wrapper_class("WanVideoSampler")
        EncoderCls = _try_import_wrapper_class("WanVideoTextEncode")
        WanVideoDecodeCls = _try_import_wrapper_class("WanVideoDecode")

        if SamplerCls is None or EncoderCls is None:
            raise RuntimeError("[WanLooperDesigner] Could not locate WanVideoWrapper modules.")
        
        _patch_kijai_multitalk_uninit(SamplerCls)
        
        SVIProEmbedsCls = _try_import_wrapper_class("WanVideoSVIProEmbeds")
        AddStoryMemLatentsCls = _try_import_wrapper_class("WanVideoAddStoryMemLatents")
        use_svipro_path = SVIProEmbedsCls is not None
        
        sampler_instance = SamplerCls()
        encoder_instance = EncoderCls()
        decoder_instance = WanVideoDecodeCls() if WanVideoDecodeCls else None

        # Inline decode function targeting Kijai's actual WanVideoDecode node to guarantee identical math
        def _decode_latent_to_image(lat_tensor):
            if decoder_instance is not None:
                lat_dict = {"samples": lat_tensor.unsqueeze(0) if lat_tensor.dim() == 4 else lat_tensor}
                res = _call_wrapper(
                    decoder_instance,
                    ("decode", "process"),
                    vae=vae,
                    samples=lat_dict,
                    enable_vae_tiling=False,
                    tile_x=272, tile_y=272, tile_stride_x=144, tile_stride_y=128,
                    normalization="default"
                )
                img = res[0] if isinstance(res, tuple) else res
                return img
            else:
                return _wrapper_vae_decode(vae, lat_tensor)

        raw_anchor_image = None
        if anchor_samples is not None:
            persistent_anchor = anchor_samples["samples"]
            if persistent_anchor.dim() == 5:
                persistent_anchor = persistent_anchor[0]
            persistent_anchor = persistent_anchor.to(_DEVICE)
            persistent_anchor_frame_count = persistent_anchor.shape[1]

            spatial_stride = getattr(vae, "upsampling_factor", 8)
            target_lat_h = height // spatial_stride
            target_lat_w = width // spatial_stride
            actual_lat_h = persistent_anchor.shape[2]
            actual_lat_w = persistent_anchor.shape[3]
            if (actual_lat_h, actual_lat_w) != (target_lat_h, target_lat_w):
                actual_img_h = actual_lat_h * spatial_stride
                actual_img_w = actual_lat_w * spatial_stride
                log.info(
                    f"[WanLooperDesigner] anchor_samples shape "
                    f"{actual_img_w}x{actual_img_h} != requested {width}x{height}; "
                    f"decoding -> resize ({image_resize_mode}) -> re-encoding to conform."
                )
                anchor_lat_t1 = persistent_anchor[:, :1]
                decoded = _decode_latent_to_image(anchor_lat_t1)
                if decoded.dim() == 4:
                    anchor_for_resize = decoded[:1]
                else:
                    anchor_for_resize = decoded.unsqueeze(0)
                anchor_norm = _resize_and_normalize(anchor_for_resize, width, height, image_resize_mode)
                persistent_anchor = _wrapper_vae_encode(vae, anchor_norm)
                persistent_anchor_frame_count = 1
            
            if anchor_image is not None:
                raw_anchor_image = anchor_image
        elif anchor_image is not None:
            anchor_norm = _resize_and_normalize(anchor_image[:1], width, height, image_resize_mode)
            persistent_anchor = _wrapper_vae_encode(vae, anchor_norm)
            persistent_anchor_frame_count = 1
            raw_anchor_image = anchor_image
        elif anchor_image_filename:
            gui_anchor = _load_image_from_input(anchor_image_filename)
            if gui_anchor is None:
                raise ValueError(f"[WanLooperDesigner] Could not load '{anchor_image_filename}'")
            anchor_norm = _resize_and_normalize(gui_anchor, width, height, image_resize_mode)
            persistent_anchor = _wrapper_vae_encode(vae, anchor_norm)
            persistent_anchor_frame_count = 1
            raw_anchor_image = gui_anchor
        else:
            raise ValueError("[WanLooperDesigner] No persistent anchor wired or loaded.")

        if reference_image is not None:
            reference_image_norm = _resize_and_normalize(reference_image[:1], width, height, image_resize_mode)
        else:
            reference_image_norm = None

        global_memory_latents = None
        if memory_latents is not None:
            global_memory_latents = memory_latents["samples"]
            if global_memory_latents.dim() == 5:
                global_memory_latents = global_memory_latents[0]
            global_memory_latents = global_memory_latents.to(_DEVICE)
        elif memory_images is not None:
            mem_resized = _resize_only(memory_images, width, height, image_resize_mode)
            global_memory_latents = _wrapper_vae_encode_batch(vae, mem_resized)

        rope_offset_effective = rope_negative_offset_frames if rope_negative_offset else 0

        _base_empty = not (global_prompt or "").strip()
        _need_ollama = bool(reroll_on_queue) or (bool(auto_generate_on_queue) and _base_empty)
        if _need_ollama:
            anchor_for_llm = raw_anchor_image
            if anchor_for_llm is None and ollama_use_frame and persistent_anchor is not None:
                try:
                    one = persistent_anchor[:, :1] if persistent_anchor.dim() == 4 else persistent_anchor
                    decoded = _decode_latent_to_image(one)
                    if decoded.dim() == 4:
                        anchor_for_llm = decoded[:1]
                    else:
                        anchor_for_llm = decoded.unsqueeze(0)
                except Exception as _e:
                    pass

            new_base, new_segments = _ollama_generate_prompts_server_side(
                anchor_image_bhwc=anchor_for_llm,
                segments=segments,
                base_prompt=global_prompt,
                ollama_url=ollama_url,
                model=ollama_model,
                system_prompt=ollama_system_prompt,
                story=ollama_story_concept,
                direction=ollama_custom_direction,
                per_segment=bool(ollama_per_segment),
                enhance=bool(ollama_enhance),
                use_frame=bool(ollama_use_frame),
                temperature=float(ollama_temperature),
                num_ctx=int(ollama_ctx),
                unload_after=bool(ollama_unload_after_gen),
            )
            if new_base is not None:
                global_prompt = new_base
            if new_segments is not None:
                segments = new_segments
            if new_base is not None or new_segments is not None:
                _push_applied_prompts_to_gui(unique_id, new_base, new_segments)

        # --- METADATA INJECTION ---
        if unique_id is not None:
            try:
                if prompt is not None and str(unique_id) in prompt:
                    prompt[str(unique_id)]["inputs"]["global_prompt"] = global_prompt
                    prompt[str(unique_id)]["inputs"]["segments_json"] = json.dumps(segments, indent=2)
                if extra_pnginfo is not None and "workflow" in extra_pnginfo:
                    for n in extra_pnginfo["workflow"].get("nodes", []):
                        if str(n.get("id")) == str(unique_id):
                            w_vals = n.get("widgets_values", [])
                            if w_vals:
                                seg_json_str = json.dumps(segments, indent=2)
                                for vi, v in enumerate(w_vals):
                                    if isinstance(v, str) and v.strip().startswith("[") and "frames" in v:
                                        w_vals[vi] = seg_json_str
                                        if vi + 1 < len(w_vals):
                                            w_vals[vi + 1] = global_prompt
                                        break
                            break
            except Exception as e:
                log.debug(f"[WanLooperDesigner] Metadata injection: {e}")

        ref_mean = ref_std = None
        if color_correction and raw_anchor_image is not None:
            initial_anchor_img = common_upscale(
                raw_anchor_image[:1, ..., :3].movedim(-1, 1),
                width, height, "bilinear", "center",
            ).movedim(1, -1)
            ref_mean, ref_std = _capture_color_stats(initial_anchor_img)
        elif color_correction:
            color_correction = False

        neg_embeds = _call_wrapper(
            encoder_instance,
            ("process", "encode"),
            t5=t5,
            positive_prompt="",
            prompt="",
            text="",
            negative_prompt=negative_prompt,
            negative_text=negative_prompt,
            force_offload=True,
        )
        neg_text_embed_only = neg_embeds[0] if isinstance(neg_embeds, tuple) else neg_embeds

        seg_dir = None
        if spill_to_disk and decode_per_segment in ("always", "final_only"):
            try:
                base_temp = folder_paths.get_temp_directory() if folder_paths else tempfile.gettempdir()
                os.makedirs(base_temp, exist_ok=True)
                seg_dir = tempfile.mkdtemp(prefix="wan_looper_", dir=base_temp)
            except OSError as e:
                spill_to_disk = False

        per_segment_latents: List[torch.Tensor] = []
        prev_latent_samples = None
        segments_count = len(segments)

        _blending_policy = stitch_policy not in ("cut", "svi_overlap_drop")
        _do_interleaved_decode = _blending_policy or decode_per_segment == "always"
        running_image_batch = None

        def _emit_progress(seg_idx: int, phase: str):
            try:
                from server import PromptServer
                PromptServer.instance.send_sync(
                    "wld_segment_progress",
                    {
                        "node_id": str(unique_id) if unique_id is not None else "",
                        "seg_idx": int(seg_idx),
                        "total": int(segments_count),
                        "phase": phase,
                    },
                )
            except Exception:
                pass

        current_frame_start = 0

        # --- EverAnimate / WanAnimate detection (outside loop for efficiency) ---
        AnimateEmbedsCls = _try_import_wrapper_class("WanVideoAnimateEmbeds")
        use_animate_path = (pose_images is not None) and (AnimateEmbedsCls is not None)
        if pose_images is not None and AnimateEmbedsCls is None:
            log.warning("[WanLooperDesigner] pose_images wired but WanVideoAnimateEmbeds not found. Update Kijai's wrapper.")

        # SAFETY RAIL: WanAnimate is a monolithic model with no high/low split.
        # If pose_images are wired, auto-ignore model_low to prevent crashes.
        if use_animate_path and model_low is not None:
            log.warning("[WanLooperDesigner] WanAnimate/EverAnimate mode active. "
                        "Ignoring 'model_low' — WanAnimate is a single-pass model.")
            model_low = None

        # SVI Pro / vanilla WanAnimate = 1 anchor latent. EverAnimate = 4.
        is_everanimate = use_animate_path and everanimate_mode
        anchor_latent_count = 4 if is_everanimate else 1
        # Frames corresponding to anchor latents: 1 latent = 1 frame, 4 latents = 13 frames
        anchor_image_count = 1 + (anchor_latent_count - 1) * 4

        if is_everanimate:
            log.info(f"[WanLooperDesigner] EverAnimate mode ON: N={anchor_latent_count} anchor latents, "
                     f"{anchor_image_count} anchor frames per segment")

        try:
            for seg_idx, seg in enumerate(segments):
                seg_width = seg["width_override"] or width
                seg_height = seg["height_override"] or height
                seg_cfg_high = seg["cfg_high_override"] if seg["cfg_high_override"] is not None else cfg_high
                seg_cfg_low = seg["cfg_low_override"] if seg["cfg_low_override"] is not None else cfg_low
                seg_seed = _resolve_seed(seed, seed_policy, seg_idx, seg["seed_override"])
                seg_prompt = (seg["prompt"] or global_prompt or "").strip()
                seg_length = int(seg["frames"])

                seg_pose_images = _slice_video(pose_images, current_frame_start, seg_length)
                seg_face_images = _slice_video(face_images, current_frame_start, seg_length)

                seg_anchor_latent = persistent_anchor
                seg_anchor_frame_count = persistent_anchor_frame_count

                if seg["anchor_mode"] == "custom_override":
                    custom_img = _load_image_from_input(seg["anchor_image_filename"])
                    if custom_img is not None:
                        custom_norm = _resize_and_normalize(custom_img, seg_width, seg_height, image_resize_mode)
                        seg_anchor_latent = _wrapper_vae_encode(vae, custom_norm)
                        seg_anchor_frame_count = 1
                elif seg["anchor_mode"] == "previous_last_frame" and seg_idx > 0:
                    if prev_latent_samples is not None:
                        prev = prev_latent_samples
                        if prev.dim() == 5:
                            prev = prev[0]
                        offset_lat = max(1, abs(anchor_frame_offset) // 4 or 1)
                        offset_lat = min(offset_lat, prev.shape[1])
                        seg_anchor_latent = prev[:, -offset_lat:-offset_lat + 1].clone()
                        if seg_anchor_latent.shape[1] == 0:
                            seg_anchor_latent = prev[:, -1:].clone()
                        seg_anchor_latent = seg_anchor_latent.to(_DEVICE)
                        seg_anchor_frame_count = 1

                seg_middle_image = None
                if seg["middle_image_filename"]:
                    mid_img = _load_image_from_input(seg["middle_image_filename"])
                    if mid_img is not None:
                        seg_middle_image = _resize_and_normalize(mid_img, seg_width, seg_height, image_resize_mode)

                seg_end_image = None
                if seg["end_image_filename"]:
                    end_img = _load_image_from_input(seg["end_image_filename"])
                    if end_img is not None:
                        seg_end_image = _resize_and_normalize(end_img, seg_width, seg_height, image_resize_mode)

                seg_memory_latents = global_memory_latents
                seg_memory_images_raw = memory_images
                if seg["memory_image_filenames"]:
                    mem_imgs = []
                    for fn in seg["memory_image_filenames"]:
                        img = _load_image_from_input(fn)
                        if img is not None: mem_imgs.append(img)
                    if mem_imgs:
                        mem_batch = torch.cat(mem_imgs, dim=0)
                        mem_resized = _resize_only(mem_batch, seg_width, seg_height, image_resize_mode)
                        seg_memory_latents = _wrapper_vae_encode_batch(vae, mem_resized)
                        seg_memory_images_raw = mem_resized
                elif global_memory_latents is not None and memory_images is None:
                    seg_memory_images_raw = None
                elif memory_images is not None:
                    seg_memory_images_raw = _resize_only(memory_images, seg_width, seg_height, image_resize_mode)

                seg_reference = reference_image_norm if seg_idx == 0 and anchor_samples is None else None

                if use_animate_path:
                    # --- Animate Path (EverAnimate or vanilla WanAnimate) ---
                    anim_ref = reference_image if reference_image is not None else raw_anchor_image

                    animate_kwargs = {
                        # -- required by WanVideoAnimateEmbeds --
                        "vae": vae,
                        "width": seg_width,
                        "height": seg_height,
                        "num_frames": seg_length,
                        "force_offload": True,
                        "frame_window_size": seg_length,
                        "colormatch": "disabled",
                        "pose_strength": 1.0,
                        "face_strength": 1.0,
                        # -- optional --
                        "pose_images": seg_pose_images,
                    }
                    if anim_ref is not None:
                        animate_kwargs["ref_images"] = anim_ref
                    if seg_face_images is not None:
                        animate_kwargs["face_images"] = seg_face_images
                    if bg_image is not None:
                        animate_kwargs["bg_images"] = _slice_video(bg_image, current_frame_start, seg_length)

                    animate_node = AnimateEmbedsCls()
                    animate_method = getattr(AnimateEmbedsCls, "FUNCTION", "process")

                    result = _call_wrapper(
                        animate_node,
                        (animate_method, "process", "encode", "get_embeds"),
                        **animate_kwargs
                    )
                    image_embeds = result[0] if isinstance(result, tuple) else result

                    # --- THE EVERANIMATE INTERCEPTOR HACK ---
                    # Bypass the need for Kijai's unmerged PR. Intercept vanilla
                    # WanAnimate embeds and reconstruct ref_latent with the
                    # N=4 Anchor + M motion layout the EverAnimate LoRA expects.
                    # ref_latent is [20, T, h, w]: ch 0:4 = mask, ch 4:20 = latent.
                    if is_everanimate:
                        ref_lat = image_embeds["ref_latent"]  # [20, T, h, w]
                        old_mask = ref_lat[:4]                # [4, T, h, w]
                        old_y = ref_lat[4:]                   # [16, T, h, w]

                        new_y = torch.zeros_like(old_y)
                        new_mask = torch.zeros_like(old_mask)

                        base_anchor = old_y[:, :1, :, :]
                        tot_len = new_y.shape[1]

                        safe_N = min(anchor_latent_count, tot_len)

                        # Fill the N anchor latents (identity memory)
                        for i in range(safe_N):
                            new_y[:, i:i+1, :, :] = base_anchor
                            new_mask[:, i:i+1, :, :] = 1.0

                        # Fill M motion latents from previous segment's tail
                        if prev_latent_samples is not None and seg_idx > 0 and safe_N < tot_len:
                            safe_M = min(svipro_motion_latent_count, tot_len - safe_N)
                            motion_latent = prev_latent_samples[:, -safe_M:].to(new_y.device)

                            new_y[:, safe_N:safe_N + safe_M, :, :] = motion_latent
                            new_mask[:, safe_N:safe_N + safe_M, :, :] = 1.0

                        image_embeds["ref_latent"] = torch.cat([new_mask, new_y], dim=0)
                        log.info(f"[WanLooperDesigner] EverAnimate interceptor: rebuilt ref_latent "
                                 f"with N={safe_N} anchors + M={safe_M if prev_latent_samples is not None and seg_idx > 0 else 0} motion")

                elif use_svipro_path:
                    prev_seg_latent_for_svipro = (
                        prev_latent_samples if seg_idx > 0 else None
                    )
                    image_embeds = _build_embeds_via_svipro_node(
                        svipro_cls=SVIProEmbedsCls,
                        add_story_mem_cls=AddStoryMemLatentsCls,
                        vae=vae,
                        anchor_latent=seg_anchor_latent,
                        seg_memory_images_01=seg_memory_images_raw,
                        prev_seg_latent=prev_seg_latent_for_svipro,
                        seg_length=seg_length,
                        motion_latent_count=svipro_motion_latent_count,
                        rope_negative_offset=rope_negative_offset,
                        rope_negative_offset_frames=rope_negative_offset_frames,
                        augment_empty_frames=augment_empty_frames,
                    )
                else:
                    image_embeds = _build_embeds_for_segment(
                        vae=vae, width=seg_width, height=seg_height, length=seg_length,
                        anchor_latent=seg_anchor_latent, anchor_frame_count=seg_anchor_frame_count,
                        prev_latent_samples=prev_latent_samples, reference_image=seg_reference,
                        reference_strength=reference_strength, continue_frames_count=continue_frames_count,
                        svi_motion_strength=svi_motion_strength, augment_empty_frames=augment_empty_frames,
                        middle_image=seg_middle_image, end_image=seg_end_image,
                        memory_latents_tensor=seg_memory_latents, rope_negative_offset_frames=rope_offset_effective,
                    )

                pos_embeds = _call_wrapper(
                    encoder_instance,
                    ("process", "encode"),
                    t5=t5,
                    positive_prompt=seg_prompt,
                    prompt=seg_prompt,
                    text=seg_prompt,
                    negative_prompt=negative_prompt,
                    negative_text=negative_prompt,
                    force_offload=(seg_idx == segments_count - 1),
                )
                text_embeds = pos_embeds[0] if isinstance(pos_embeds, tuple) else pos_embeds

                text_embeds_high = text_embeds
                text_embeds_low = text_embeds
                if nag_enabled:
                    enriched = _apply_nag_to_embeds(
                        text_embeds,
                        t5,
                        encoder_instance,
                        negative_prompt,
                        nag_scale,
                        nag_tau,
                        nag_alpha,
                    )
                    if nag_apply_to in ("both", "high_only"):
                        text_embeds_high = enriched
                    if nag_apply_to in ("both", "low_only"):
                        text_embeds_low = enriched

                _emit_progress(seg_idx, "high")
                high_kwargs = dict(
                    model=model_high,
                    image_embeds=image_embeds,
                    wan_image_embeds=image_embeds,
                    text_embeds=text_embeds_high,
                    wan_text_embeds=text_embeds_high,
                    seed=seg_seed,
                    steps=steps,
                    cfg=seg_cfg_high,
                    shift=shift,
                    scheduler=scheduler,
                    rope_function=rope_function,
                    riflex_freq_index=0,
                    force_offload=True,
                    denoise_strength=1.0,
                    add_noise_to_samples=True,
                )
                if model_low is not None:
                    high_kwargs["start_step"] = 0
                    high_kwargs["end_step"] = split_step

                # WORKFLOW CRASH-CATCHER: Intercept motion_encoder errors
                # to give a clear message instead of a cryptic NoneType traceback
                try:
                    high_result = _call_wrapper(
                        sampler_instance,
                        ("process", "execute"),
                        **high_kwargs,
                    )
                except Exception as e:
                    err_str = str(e)
                    if "motion_encoder" in err_str or ("NoneType" in err_str and use_animate_path):
                        raise RuntimeError(
                            "\n\n[WanLooperDesigner] WORKFLOW ERROR:\n"
                            "You wired pose/face images (WanAnimate mode), but the model in\n"
                            "'model_high' lacks a motion_encoder (it's a standard I2V model).\n\n"
                            "FIX: Load 'Wan2_2-Animate-14B' into 'model_high'.\n"
                            "     Leave 'model_low' EMPTY (WanAnimate is single-pass).\n\n"
                        ) from e
                    raise
                high_samples = (
                    high_result[0] if isinstance(high_result, tuple) else high_result
                )

                if model_low is not None:
                    _emit_progress(seg_idx, "low")
                    low_kwargs = dict(
                        model=model_low,
                        image_embeds=image_embeds,
                        wan_image_embeds=image_embeds,
                        text_embeds=text_embeds_low,
                        wan_text_embeds=text_embeds_low,
                        samples=high_samples,
                        latents=high_samples,
                        wan_latents=high_samples,
                        seed=seg_seed,
                        steps=steps,
                        cfg=seg_cfg_low,
                        shift=shift,
                        scheduler=scheduler,
                        rope_function=rope_function,
                        riflex_freq_index=0,
                        force_offload=True,
                        denoise_strength=1.0,
                        add_noise_to_samples=False,
                        start_step=split_step,
                        end_step=steps,
                    )
                    low_result = _call_wrapper(
                        sampler_instance,
                        ("process", "execute"),
                        **low_kwargs,
                    )
                    final_samples = (
                        low_result[0] if isinstance(low_result, tuple) else low_result
                    )
                else:
                    final_samples = high_samples

                if isinstance(final_samples, dict):
                    final_samples_tensor = final_samples["samples"]
                else:
                    final_samples_tensor = final_samples
                if final_samples_tensor.dim() == 5:
                    final_samples_tensor = final_samples_tensor[0]

                per_segment_latents.append(final_samples_tensor.cpu().clone())
                prev_latent_samples = final_samples_tensor.to(_DEVICE)

                if seg["promote_anchor"]:
                    offset_lat = max(1, abs(anchor_frame_offset) // 4 or 1)
                    offset_lat = min(offset_lat, final_samples_tensor.shape[1])
                    new_anchor = final_samples_tensor[:, -offset_lat:-offset_lat + 1].clone()
                    if new_anchor.shape[1] == 0:
                        new_anchor = final_samples_tensor[:, -1:].clone()
                    persistent_anchor = new_anchor.to(_DEVICE)
                    persistent_anchor_frame_count = 1

                # Interleaved decode & blend
                if _do_interleaved_decode:
                    _emit_progress(seg_idx, "decode")
                    decoded_img = _decode_latent_to_image(final_samples_tensor.to(_DEVICE))
                    
                    if decoded_img.dtype != torch.float32:
                        decoded_img = decoded_img.to(torch.float32)
                    decoded_img = decoded_img.cpu()

                    if color_correction and ref_mean is not None and seg_idx > 0:
                        decoded_img = _renormalize_to_stats(decoded_img, ref_mean, ref_std)

                    if spill_to_disk and seg_dir:
                        seg_path = os.path.join(seg_dir, f"segment_{seg_idx:04d}.pt")
                        torch.save(decoded_img, seg_path)

                    if running_image_batch is None:
                        running_image_batch = decoded_img
                    else:
                        if stitch_policy in ("cut", "svi_overlap_drop"):
                            motion_latent_count = max(1, int(svipro_motion_latent_count))
                            drop_image_frames = 1 + (anchor_latent_count + motion_latent_count - 1) * 4
                            if decoded_img.shape[0] > drop_image_frames:
                                try:
                                    _pf = running_image_batch[-1:]
                                    _nf = decoded_img[drop_image_frames:drop_image_frames + 1]
                                    log.info(
                                        "[WanLooperDesigner] Seam %d->%d (hard cut): boundary frame "
                                        "mean %.4f -> %.4f (delta %+.4f)",
                                        seg_idx - 1, seg_idx, float(_pf.mean()), float(_nf.mean()),
                                        float(_nf.mean()) - float(_pf.mean()),
                                    )
                                except Exception:
                                    pass
                                running_image_batch = torch.cat([running_image_batch, decoded_img[drop_image_frames:]], dim=0)
                            else:
                                running_image_batch = torch.cat([running_image_batch, decoded_img], dim=0)
                        else:
                            overlap_inst = _resolve_kj_overlap()
                            if overlap_inst is None:
                                motion_latent_count = max(1, int(svipro_motion_latent_count))
                                drop_image_frames = 1 + (anchor_latent_count + motion_latent_count - 1) * 4
                                if decoded_img.shape[0] > drop_image_frames:
                                    running_image_batch = torch.cat([running_image_batch, decoded_img[drop_image_frames:]], dim=0)
                                else:
                                    running_image_batch = torch.cat([running_image_batch, decoded_img], dim=0)
                            else:
                                # Drop the redundant anchor frame(s) from the
                                # incoming segment BEFORE blending (v1.2.35 fix,
                                # generalized to N anchor latents for EverAnimate).
                                # Decoded SVI Pro segment structure:
                                #   frames [0 .. anchor_image_count-1] = anchor
                                #   next M*4 frames = motion bridge (temporal
                                #   duplicates of prev segment's tail)
                                #   remainder = new content
                                _drop_n = min(anchor_image_count, max(0, decoded_img.shape[0] - 1))
                                nxt_for_blend = decoded_img[_drop_n:] if decoded_img.shape[0] > _drop_n else decoded_img
                                eff_overlap = min(overlap_blend_frames, max(1, int(svipro_motion_latent_count)) * 4)
                                
                                frames_to_skip = (max(1, int(svipro_motion_latent_count)) * 4) - eff_overlap
                                if frames_to_skip > 0 and nxt_for_blend.shape[0] > frames_to_skip:
                                    nxt_for_blend = nxt_for_blend[frames_to_skip:]
                                    
                                safe_overlap = min(eff_overlap, running_image_batch.shape[0], nxt_for_blend.shape[0])
                                
                                if safe_overlap <= 0:
                                    running_image_batch = torch.cat([running_image_batch, nxt_for_blend], dim=0)
                                else:
                                    # Seam diagnostics: the bridge frames are the
                                    # model's regeneration of prev tail, so any
                                    # mean/std delta here IS the visible seam.
                                    try:
                                        _pt = running_image_batch[-safe_overlap:]
                                        _nh = nxt_for_blend[:safe_overlap]
                                        _pm, _ps = float(_pt.mean()), float(_pt.std())
                                        _nm, _ns = float(_nh.mean()), float(_nh.std())
                                        log.info(
                                            "[WanLooperDesigner] Seam %d->%d: prev tail mean/std "
                                            "%.4f/%.4f vs bridge %.4f/%.4f (delta mean %+.4f, "
                                            "delta std %+.4f) over %d blend frames",
                                            seg_idx - 1, seg_idx, _pm, _ps, _nm, _ns,
                                            _nm - _pm, _ns - _ps, safe_overlap,
                                        )
                                    except Exception:
                                        pass
                                    try:
                                        res = overlap_inst.imagesfrombatch(
                                            source_images=running_image_batch,
                                            overlap=safe_overlap,
                                            overlap_side=overlap_side,
                                            overlap_mode=stitch_policy,
                                            new_images=nxt_for_blend
                                        )
                                        running_image_batch = res[2] if len(res) >= 3 else res[0]
                                    except Exception as e:
                                        log.error(f"[WanLooperDesigner] crossfade blend failed: {e}. Falling back to concat.")
                                        running_image_batch = torch.cat([running_image_batch, nxt_for_blend[safe_overlap:]], dim=0)

                del image_embeds, high_samples
                if model_low is not None:
                    del low_result
                comfy.model_management.soft_empty_cache()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                gc.collect()
                _emit_progress(seg_idx, "done")
                
                # Temporal alignment: advance driving video cursor accounting for
                # both motion overlap AND anchor frames eaten by the N-slot memory
                motion_frames = int(svipro_motion_latent_count) * 4
                step_size = seg_length - motion_frames - anchor_image_count
                current_frame_start += max(1, step_size)

            _emit_progress(segments_count - 1, "all_done")

            # LATENT PURITY GUARANTEE: the samples outputs are ALWAYS a pure
            # SVI hard-cut concat (drop anchor + bridge latents, concatenate).
            # Latent-space crossfading was established (v1.2.29 sessions) to
            # produce worse seams than the model's own bridge, and blended
            # latents would poison any downstream continuation that feeds
            # these samples back in. Image-space blending above is the ONLY
            # place blending ever happens.
            _blend_latents = 0
            _blend_mode = "linear"

            if decode_per_segment == "never":
                images_out = torch.zeros(1, height, width, 3)
            elif _do_interleaved_decode:
                images_out = running_image_batch
            else:
                full_latent = _latent_seam_stitch(
                    [t.to(_DEVICE) for t in per_segment_latents],
                    svipro_motion_latent_count=svipro_motion_latent_count,
                    anchor_latent_count=anchor_latent_count,
                    blend_latents=_blend_latents,
                    blend_mode=_blend_mode,
                )
                images_out = _decode_latent_to_image(full_latent.to(_DEVICE))

            full_concat = _latent_seam_stitch(
                [t.to("cpu") for t in per_segment_latents],
                svipro_motion_latent_count=svipro_motion_latent_count,
                anchor_latent_count=anchor_latent_count,
                blend_latents=_blend_latents,
                blend_mode=_blend_mode,
            )
            full_samples_dict = {"samples": full_concat.unsqueeze(0)}

            if per_segment_latents:
                max_T = max(t.shape[1] for t in per_segment_latents)
                C, _, H_lat, W_lat = per_segment_latents[0].shape
                stacked = torch.zeros(len(per_segment_latents), C, max_T, H_lat, W_lat, dtype=per_segment_latents[0].dtype)
                for i, t in enumerate(per_segment_latents):
                    stacked[i, :, :t.shape[1]] = t
                per_seg_samples_dict = {"samples": stacked}
            else:
                per_seg_samples_dict = {"samples": torch.zeros(0)}

        finally:
            if seg_dir and os.path.isdir(seg_dir):
                try:
                    shutil.rmtree(seg_dir, ignore_errors=True)
                except Exception:
                    pass

        if isinstance(images_out, torch.Tensor) and images_out.dtype != torch.float32:
            images_out = images_out.to(torch.float32)

        if (
            startup_trim > 0
            and isinstance(images_out, torch.Tensor)
            and images_out.dim() == 4
            and images_out.shape[0] > startup_trim
        ):
            log.info(f"[WanLooperDesigner] startup_trim: dropping first {startup_trim} frames of image output.")
            images_out = images_out[startup_trim:]

        return (
            images_out, full_samples_dict, per_seg_samples_dict,
            segments_count, segments_json, global_prompt,
        )


NODE_CLASS_MAPPINGS = {"WanLooperDesigner": WanLooperDesigner}
NODE_DISPLAY_NAME_MAPPINGS = {"WanLooperDesigner": "Wan Looper Designer (Wrapper)"}
WEB_DIRECTORY = "./js"

# ===========================================================================
# Server-side Ollama proxy + system_prompts routes
# ===========================================================================
try:
    from server import PromptServer
    from aiohttp import web
    import aiohttp

    _routes = PromptServer.instance.routes

    @_routes.post("/wan_looper_designer/models")
    async def _wld_models(request):
        try: data = await request.json()
        except Exception: data = {}
        url = (data.get("ollama_url") or "http://127.0.0.1:11434").rstrip("/")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{url}/api/tags", timeout=aiohttp.ClientTimeout(total=10)) as r:
                    if r.status != 200:
                        text = await r.text()
                        return web.json_response({"error": f"Ollama HTTP {r.status}: {text[:200]}"}, status=502)
                    tags = await r.json()
            models = sorted([(m.get("name") or m.get("model") or "") for m in tags.get("models", []) if m])
            return web.json_response({"models": [m for m in models if m]})
        except Exception as e:
            return web.json_response({"error": f"failed to list: {type(e).__name__}: {e}"}, status=502)

    @_routes.post("/wan_looper_designer/generate")
    async def _wld_generate(request):
        try: data = await request.json()
        except Exception as e: return web.json_response({"error": f"invalid JSON: {e}"}, status=400)
        url = (data.get("ollama_url") or "http://127.0.0.1:11434").rstrip("/")
        model = data.get("model")
        if not model: return web.json_response({"error": "missing model"}, status=400)
        payload = {"model": model, "prompt": data.get("prompt", ""), "system": data.get("system", ""), "stream": False, "options": data.get("options") or {}}
        if "keep_alive" in data: payload["keep_alive"] = data["keep_alive"]
        if data.get("images"): payload["images"] = data["images"]
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(f"{url}/api/generate", json=payload, timeout=aiohttp.ClientTimeout(total=300)) as r:
                    if r.status != 200:
                        text = await r.text()
                        return web.json_response({"error": f"Ollama HTTP {r.status}: {text[:500]}"}, status=502)
                    resp = await r.json()
            return web.json_response({"response": (resp.get("response") or "").strip()})
        except Exception as e:
            return web.json_response({"error": f"failed: {type(e).__name__}: {e}"}, status=502)

    def _parse_preset_header(text):
        title = None
        description = ""
        lines = text.splitlines()
        body_start = 0
        for i, line in enumerate(lines):
            s = line.lstrip()
            if not s.startswith("#"):
                body_start = i
                break
            content = s.lstrip("#").strip()
            low = content.lower()
            if low.startswith("title:"): title = content.split(":", 1)[1].strip()
            elif low.startswith("description:"): description = content.split(":", 1)[1].strip()
        else: body_start = len(lines)
        body = "\n".join(lines[body_start:]).strip()
        return title, description, body

    @_routes.get("/wan_looper_designer/system_prompts")
    async def _wld_presets_list(request):
        try:
            items = []
            if _SYSTEM_PROMPTS_DIR.is_dir():
                for path in sorted(_SYSTEM_PROMPTS_DIR.glob("*.txt")):
                    try: text = path.read_text(encoding="utf-8")
                    except Exception: continue
                    title, description, _ = _parse_preset_header(text)
                    items.append({"filename": path.name, "title": title or path.stem, "description": description})
            return web.json_response({"presets": items})
        except Exception as e:
            return web.json_response({"error": f"list failed: {type(e).__name__}: {e}"}, status=500)

    @_routes.get("/wan_looper_designer/system_prompts/{name}")
    async def _wld_presets_read(request):
        name = request.match_info.get("name", "")
        if "/" in name or "\\" in name or not name.endswith(".txt"): return web.json_response({"error": "invalid preset name"}, status=400)
        path = (_SYSTEM_PROMPTS_DIR / name).resolve()
        try: path.relative_to(_SYSTEM_PROMPTS_DIR.resolve())
        except ValueError: return web.json_response({"error": "invalid preset name"}, status=400)
        if not path.is_file(): return web.json_response({"error": "preset not found"}, status=404)
        try:
            text = path.read_text(encoding="utf-8")
            title, description, body = _parse_preset_header(text)
            return web.json_response({"filename": path.name, "title": title or path.stem, "description": description, "content": body})
        except Exception as e:
            return web.json_response({"error": f"read failed: {type(e).__name__}: {e}"}, status=500)

    @_routes.post("/wan_looper_designer/upload_image")
    async def _wld_upload_image(request):
        if folder_paths is None: return web.json_response({"error": "folder_paths unavailable; cannot resolve input dir"}, status=500)
        try: reader = await request.multipart()
        except Exception as e: return web.json_response({"error": f"multipart parse failed: {e}"}, status=400)

        original_name = ""
        file_bytes = b""
        subdir = ""
        async for field in reader:
            if field is None: continue
            name = field.name
            if name == "image" or name == "file":
                original_name = field.filename or "anchor.png"
                file_bytes = await field.read(decode=False)
            elif name == "subfolder":
                subdir = (await field.text()).strip()

        if not file_bytes: return web.json_response({"error": "no file payload in 'image' field"}, status=400)

        safe_base = os.path.basename(original_name).replace("\\", "_")
        safe_base = "".join(ch for ch in safe_base if ch.isalnum() or ch in "._- ()[]").strip() or "anchor"
        stem, ext = os.path.splitext(safe_base)
        ext = ext.lower()
        if ext not in (".png", ".jpg", ".jpeg", ".webp", ".bmp"): ext = ".png"; safe_base = stem + ext

        input_dir = folder_paths.get_input_directory()
        target_dir = input_dir
        if subdir:
            safe_sub = "".join(ch for ch in subdir if ch.isalnum() or ch in "._- /").strip("/").replace("\\", "/")
            if safe_sub:
                target_dir = os.path.join(input_dir, safe_sub)
                try: os.makedirs(target_dir, exist_ok=True)
                except OSError as e: return web.json_response({"error": f"could not create subfolder: {e}"}, status=500)

        out_name = safe_base
        out_path = os.path.join(target_dir, out_name)
        suffix = 2
        stem, ext = os.path.splitext(safe_base)
        while os.path.exists(out_path):
            out_name = f"{stem}_{suffix}{ext}"
            out_path = os.path.join(target_dir, out_name)
            suffix += 1

        try:
            with open(out_path, "wb") as fh: fh.write(file_bytes)
        except OSError as e:
            return web.json_response({"error": f"failed to write file: {e}"}, status=500)

        rel_name = f"{subdir}/{out_name}".replace("\\", "/").lstrip("/") if subdir else out_name
        return web.json_response({"name": rel_name, "subfolder": subdir, "type": "input"})

except ImportError as _e:
    log.warning(f"[WanLooperDesigner] PromptServer/aiohttp not available; Ollama proxy routes not registered: {_e}")