# ComfyUI-WanLooperDesigner

Multi-segment Wan 2.2 I2V looper for Kijai's [ComfyUI-WanVideoWrapper](https://github.com/kijai/ComfyUI-WanVideoWrapper) with a Designer-style timeline GUI. Drives `WanVideoSampler` N times inside a single node, threading the SVI 2.2 Pro anchor and motion-latent continuation across segments. Outputs one stitched IMAGE batch plus per-segment and full-concatenated latents.

## Status: v1.2.50

Full Designer-style editor on a self-contained Wan 2.2 I2V looping engine targeting Kijai's WanVideoWrapper. SVI 2.2 Pro continuation, multi-anchor segment 1, FLF-style middle/end keyframes per segment, StoryMem, dual-pass high/low sampling, configurable latent-space or image-space stitching, color correction, disk spilling, anchor promotion, full Ollama prompter with system-prompt presets, per-segment JSON mode, enhance mode, vision-input "use frame", auto-fill on queue, hidden-widget persistence, collapsible Advanced panel.

### v1.2.50 changes

- `stitch_policy` defaults to `linear_blend` again (per-segment decode plus image-space crossfade through KJ's `ImageBatchExtendWithOverlap`, the path that mirrors the proven subgraph workflow). The `svi_overlap_drop` default was a regression that had been fixed once before in v1.2.24 and resurfaced on this branch. Note: workflows saved with an older version keep their saved value; the new default only applies to freshly added nodes.
- The latent `samples` outputs are now ALWAYS a pure SVI hard-cut concat (drop anchor and bridge latents, concatenate). Latent-space crossfading never happens anywhere, under any policy. Image-space blending is the only blending in the pack. This keeps the latent outputs safe to feed back into a continuation run.
- Anchor and memory image encoding now delegates to Kijai's `WanVideoEncode` node (with the old internal encode as fallback if the class is not importable), restoring byte-parity with hand-built workflows. Decode was already delegated to `WanVideoDecode`.
- Per-seam diagnostics: every segment boundary logs mean/std of the previous tail versus the incoming motion-bridge frames, so brightness or color mismatch at a seam shows up as hard numbers in the console.
- The anchor-frame drop before image-space blending is generalized from a hardcoded 1 frame to `anchor_image_count` (fixes 12 stale anchor frames leaking into the blend in EverAnimate mode).
- `augment_empty_frames` now logs a warning when set above 0 on the SVI Pro path: Kijai's current `WanVideoSVIProEmbeds` does not accept it and the padding stays pure zero latents per the SVI 2.2 Pro spec (the value was previously ignored silently).
- `startup_trim` was dead code; it now actually trims the leading frames of the image output.
- Version strings harmonized across `__init__.py`, the engine, and the JS editor (the previous zip shipped 1.2.40 / 1.2.47 mixed).

Next iterations will track as v1.1, v1.2 etc. as features land. The pieces currently authorable via JSON-only (no UI yet) are: per-segment memory_image_filenames, per-segment negative prompt, per-segment cfg/width/height overrides, chain-mode Ollama (prior-segment-aware), multi-frame VLM capture, save/load segment templates.

## Requirements

- [ComfyUI-WanVideoWrapper](https://github.com/kijai/ComfyUI-WanVideoWrapper) installed at `custom_nodes/ComfyUI-WanVideoWrapper/`. The looper resolves `WanVideoSampler` and `WanVideoTextEncode` at runtime from the wrapper.
- (Optional) [comfyui-kjnodes](https://github.com/kijai/ComfyUI-KJNodes) for the `linear_blend` / `ease_in_out` / `filmic_crossfade` image-space stitch policies. Without KJNodes those policies fall back to `cut`.
- (Optional) Ollama running at `http://127.0.0.1:11434` for the prompter panel.

No imports from those packs at module load. The looper is its own pack.

## Install

```
cd ComfyUI/custom_nodes
git clone https://github.com/copperpot5/ComfyUI-WanLooperDesigner
```

Restart ComfyUI. The node appears under **WanLooperDesigner**:

- **Wan Looper Designer (Wrapper)**

> The `js/` folder contains `wan_looper_designer.js`. Ensure that file is inside `js/`, not at the pack root. The `WEB_DIRECTORY = "./js"` line in `__init__.py` and `wan_looper_designer.py` points at that subfolder.

## Wiring

Required wired inputs (top of node):
- `model_high` (WANVIDEOMODEL) -- Wan 2.2 high-noise expert.
- `vae` (WANVAE) -- Kijai's WanVideoVAE.
- `t5` (WANTEXTENCODER) -- per-segment prompts are encoded inside the loop.

Optional wired inputs:
- `model_low` (WANVIDEOMODEL) -- low-noise expert. If unwired, sampling is single-pass on `model_high` only (and `split_step` is ignored).
- `anchor_image` (IMAGE) -- persistent SVI 2.2 Pro anchor. Encoded once. **Required** unless `anchor_samples` is wired. The editor's anchor preview pane mirrors this image.
- `anchor_samples` (LATENT) -- pre-encoded persistent anchor. Highest precedence -- overrides both `anchor_image` and the GUI anchor. Wire this if you've already encoded upstream, or wire the output of `SVIProMultiAnchorEncode` to get the [ref, start * N] multi-anchor structure.
- `reference_image` (IMAGE) -- multi-anchor donor for segment 1 only.
- `memory_images` (IMAGE) or `memory_latents` (LATENT) -- StoryMem frames applied to every segment.

## Using the Designer

1. **Wire models/vae/t5.** Add a `WanVideoModelLoader` for `model_high` (and optionally `model_low`), a `WanVideoVAELoader` for `vae`, and a `LoadWanVideoT5TextEncoder` for `t5`.
2. **Wire an anchor image.** Connect a `Load Image` (or any IMAGE source) to the `anchor_image` input. The editor's "Anchor Image Preview" pane mirrors whatever's wired so you can confirm at a glance which frame the run will start from and which frame the LLM will see for vision-grounded prompting.
3. **Author segments.** Hit "+ Add segment" to append. Drag the right edge of a segment tile to resize (auto-snaps to 4n+1). Right-click a tile for the segment menu: duplicate, split, delete, clear prompt, toggle promote-anchor, change anchor mode. Click a tile to select it; the sidebar shows that segment's editable fields.
4. **Write prompts.** Either type per-segment prompts in the sidebar, or use the Ollama panel:
   - Pick a model (click `refresh` to populate the list)
   - Write a story concept and optional custom direction (LoRA triggers etc.)
   - Optionally pick a system prompt preset from the dropdown
   - Toggle "Per-segment" for JSON-mode output (auto-distributes prompts across segments)
   - Toggle "Enhance existing" to rewrite the current prompts in Wan 2.2 style
   - Toggle "Use anchor frame" to send the anchor image as vision input (needs a vision-capable model)
   - Toggle "Unload after" to evict the LLM from VRAM right after generating
   - Click "Generate prompt(s)"
5. **Queue.** With "Auto-fill on queue" the LLM runs automatically when the base prompt is empty. With "Re-roll on queue" it runs every single time.

## Segments JSON schema (what the GUI manages)

The Designer writes `segments_json` for you, but you can also edit it directly (e.g. in a workflow JSON). Schema:

```json
[
  {
    "frames": 81,
    "prompt": "a woman in a red coat steps off the curb into the rain",
    "anchor_mode": "global",
    "promote_anchor": false,
    "seed_override": null,
    "cfg_high_override": null,
    "cfg_low_override": null,
    "width_override": null,
    "height_override": null,
    "anchor_image_filename": "",
    "middle_image_filename": "",
    "end_image_filename": "",
    "memory_image_filenames": []
  }
]
```

| Field | Type | Default | Meaning |
|---|---|---|---|
| `frames` | int | 81 | Number of output frames in this segment. Minimum 9, snapped to 4n+1. |
| `prompt` | string | `""` | Positive prompt. Empty falls back to the node's `global_prompt`. |
| `anchor_mode` | enum | `"global"` | `"global"` / `"previous_last_frame"` / `"custom_override"`. |
| `promote_anchor` | bool | `false` | This segment's anchor becomes the new persistent anchor for everything after. |
| `seed_override` | int or null | null | Override the global seed for this segment only. |
| `cfg_high_override` / `cfg_low_override` | float or null | null | Per-segment CFG. |
| `width_override` / `height_override` | int or null | null | Per-segment resolution (/16 divisible). |
| `anchor_image_filename` | string | `""` | Filename in `input/` directory. Used when `anchor_mode="custom_override"`. |
| `middle_image_filename` / `end_image_filename` | string | `""` | FLF-style keyframe injection. |
| `memory_image_filenames` | string[] | `[]` | Per-segment StoryMem memory frames. |
| `model_preset` | string or null | null | Reserved for v1.x (per-segment model selection). |

## Timeline badges

Each segment tile shows badges for at-a-glance state:
- **P** (blue) -- segment has a custom prompt
- **K** (yellow) -- anchor_mode is not `"global"` (i.e. `previous_last_frame` or `custom_override`)
- **\*** (orange) -- `promote_anchor` is on
- **M** (green) -- middle keyframe set
- **E** (pink) -- end keyframe set

## Stitch policies

`stitch_policy` widget controls how the per-segment outputs are joined:

- **`svi_overlap_drop`** (default): Latent-space overlap removal. Concatenates segment latents directly, dropping the leading overlap frames of each non-first segment. Decodes once at the end. Highest fidelity, no image-space color drift from VAE round-trips. Requires `decode_per_segment="final_only"` (auto-enforced).
- **`cut`**: Image-space hard concat with overlap removal. Requires `decode_per_segment="always"`.
- **`linear_blend`** / **`ease_in_out`** / **`filmic_crossfade`**: Image-space crossfade across `overlap_blend_frames` frames using KJNodes' `ImageBatchExtendWithOverlap`. Requires `decode_per_segment="always"` and KJNodes installed.

## Decode policy

- **`final_only`** (default): keep latents flowing segment-to-segment, decode the full concatenated latent once at the end. Best for color fidelity. Forces `stitch_policy="svi_overlap_drop"` semantics.
- **`always`**: decode each segment immediately after sampling. Required for image-space crossfade.
- **`never`**: skip decode entirely. The `images` output is a dummy 1x1 tensor; use the `samples` and `per_segment_samples` LATENT outputs.

## Color correction

When `color_correction=True` (image-space modes only): captures the mean/std of the start anchor and renormalizes each non-first segment's frames to match. Helps with gradual color shift accumulated over many decode/encode cycles. No effect in `final_only` mode where latents never leave latent space.

## SVI 2.2 Pro defaults

- `continue_frames_count=5` -- image-frame overlap. The motion latent count is `((c-1)//4)+1`, and the matching leading overlap is dropped at stitch time. Default 5 matches WanUltimateI2V.
- `svi_motion_strength=1.0` -- scale motion latents. Values <1 calm motion; >1 amplify.
- `augment_empty_frames=0.0` -- PainterI2V-style motion push. Try 0.05 subtle, 0.15 strong.

## Outputs

- `images` (IMAGE): final stitched video frames in [0,1].
- `samples` (LATENT): full concatenated latent across all segments (overlap removed).
- `per_segment_samples` (LATENT): batch of per-segment latents zero-padded to max segment length.
- `num_segments` (INT).
- `segments_json` (STRING): passthrough.
- `global_prompt` (STRING): passthrough.

## System-prompt presets

Drop `.txt` files into `system_prompts/`. Each starts with `# Title:` and `# Description:` header comments used for the dropdown UI; the body below is the actual system prompt text. Ships with four:

- `00-character-narrative.txt` -- one character, consistent across all segments, story arc with beats
- `01-cinematic-shots.txt` -- each segment as a film shot (size + camera + lighting + beat)
- `02-documentary-realistic.txt` -- naturalistic / fly-on-the-wall register, no genre flourish
- `03-wan-enhance.txt` -- rewrite mode for existing prompts

## Credits and lineage

- SVI 2.2 Pro embed construction is vendored verbatim from [ComfyUI-WanUltimateI2V](https://github.com/copperpot5/ComfyUI-WanUltimateI2V) v3.3 (with the v3.1 multi-anchor mask fix preserved).
- The image-space crossfade stitch policies and color-correction pattern mirror semantics from [BarleyFarmer/ComfyUI-WanLooper](https://github.com/BarleyFarmer/ComfyUI-WanLooper), reimplemented for Kijai's wrapper.
- The Designer GUI architecture (timeline canvas, segment editor, Ollama panel with system_prompts presets, hidden-widget pattern) is adapted from [ComfyUI-LTXRetakeDesigner](https://github.com/copperpot5/ComfyUI-LTXRetakeDesigner) v44, reshaped for segments-as-tiles instead of regions-over-source-video.
